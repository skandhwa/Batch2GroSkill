package LoopingandControlFlowStatements;

public class WhileLoopEx {

	public static void main(String[] args) {
		
		int i=5;
		
		while(i<10)//// 5<10//6<10
			
		{
			
			System.out.print(i+"  ");
			
			
			i++;
		}
		
		

	}

}
