package PolymorphismEx;

class Student2
{
	int roll;
	String name;
	float fee;
	int section;
	static String address;
	
	Student2(int roll,String name,float fee,String address)
	{
		this.roll=roll;
		this.name=name;
		this.fee=fee;
		this.address=address;
	}
	
	Student2(int roll,String name,float fee,int section)
	{
		this(roll,name,fee);
		this.section=section;
	}
	
	void display()
	{
		System.out.println(roll+" "+name+" "+fee+"  "+section);
	}
	
}



public class ThisToReuseConstructor {

	public static void main(String[] args) {
		
		Student2 obj=new Student2(1234,"Saurabh",96000f);
		obj.display();
		

	}

}
