package PolymorphismEx;

class E1
{
	final int sum(int x,int y)
	{
		return x+y;
	}
}

class E2 extends E1
{
	int sum(int x,int y)
	{
		return x+y;
	}
}


public class FinalforMethod {

	public static void main(String[] args) {
		

	}

}
