package PolymorphismEx;

public class MainMethodOverloading {
	
	
	public static int main(int x,int y)
	{
		return x+y;
	}
	

	public static void main(String[] args) {
		
	System.out.println(MainMethodOverloading.main(4,5));	
		
		System.out.println("Hello");

	}

}
