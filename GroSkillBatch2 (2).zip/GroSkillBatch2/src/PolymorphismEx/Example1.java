package PolymorphismEx;

public class Example1 {
	
//	void display()
//	{
//		System.out.println("Hello");
//	}
//	
//	void display()
//	{
//		System.out.println("Hi");
//	}
	
	
	
	

	public static void main(String[] args) {
		

	}

}
