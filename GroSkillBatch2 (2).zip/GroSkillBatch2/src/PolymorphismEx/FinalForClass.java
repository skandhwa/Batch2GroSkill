package PolymorphismEx;

final class E3
{
	void display()
	{
		System.out.println("Hello");
	}
}

class E4 extends E3
{
	void message()
	{
		System.out.println("Hi");
	}
}

public class FinalForClass {

	public static void main(String[] args) {
		
		E4 obj=new E4();
		obj.display();
		obj.message();
		

	}

}
