package ProtectedEx1;

  public class PrExample1 
  {
	
	protected void display()
	{
		System.out.println("Hello");
		
		
		
	}
	

	public static void main(String[] args) {
		
		PrExample1 obj=new PrExample1();
		obj.display();
		
		

	}

}
