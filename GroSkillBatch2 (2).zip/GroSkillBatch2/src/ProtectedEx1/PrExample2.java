package ProtectedEx1;

public class PrExample2 {

	public static void main(String[] args) {
		
		PrExample1 obj=new PrExample1();
		obj.display();
		
		
	}

}
