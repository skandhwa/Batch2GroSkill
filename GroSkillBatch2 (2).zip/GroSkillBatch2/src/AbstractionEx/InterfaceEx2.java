package AbstractionEx;

interface Y1
{
	void display();
}

interface Y2 extends Y1
{
	void test();
}

class C15 implements Y2
{
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Welcome");
	}
}
public class InterfaceEx2 {

	public static void main(String[] args) {
		
		Y2 ref=new C15();
		ref.test();
		ref.display();
		
		
		
		
		

	}

}
