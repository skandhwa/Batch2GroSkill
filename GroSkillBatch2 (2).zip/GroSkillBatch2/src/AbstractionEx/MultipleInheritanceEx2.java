package AbstractionEx;

interface Y5
{
	void test();
}

interface Y6 
{
	void display();
	
}

class C20 implements Y5,Y6
{
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Welcome");
	}
}




public class MultipleInheritanceEx2 {

	public static void main(String[] args) {
		
		C20 obj=new C20();
		obj.test();
		obj.display();
		

	}

}
