package PublicExample;

public class PbExample1 {
	
	public void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		
		

	}

}
