package MyPractice1;

class T7
{
	int sum(int a,int b)
	{
		return a+b;
	}
}


public class MethodEx2 {

	public static void main(String[] args) {
		
		T7 obj=new T7();
	System.out.println(obj.sum(12, 67));	
		
		

	}

}
