package MyPractice1;

class C5
{
	void test()
	{
		System.out.println("Hello");
	}
	
	void display()
	{
		System.out.println("Hi");
	}
	
	void sum(int x,int y)
	{
		int sum=x+y;
		System.out.println(sum);
		
	}
	
	int diff(int c,int d)
	{
		return c-d;
	}
	
	
}



public class MethodInJava {

	public static void main(String[] args) {
		
		C5 obj=new C5();
		obj.test();
		obj.display();
		obj.sum(23,66);
		
		System.out.println(obj.diff(45, 12));
		

	}

}
