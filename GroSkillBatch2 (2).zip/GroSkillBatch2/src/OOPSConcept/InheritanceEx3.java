package OOPSConcept;


class B3
{
	void display()
	{
		System.out.println("Hello");
	}
}

class B5 extends B3
{
	void test()
	{
		System.out.println("Hi");
	}
}

class B7 extends B3
{
	void message()
	{
		System.out.println("Welcome");
	}
}

public class InheritanceEx3 {

	public static void main(String[] args) {
		
		B5 obj=new B5();
		obj.test();
		
		obj.display();
		
		B7 obj1=new B7();
		obj1.message();
		
		obj1.display();
		
		
		
		
		
		

	}

}
