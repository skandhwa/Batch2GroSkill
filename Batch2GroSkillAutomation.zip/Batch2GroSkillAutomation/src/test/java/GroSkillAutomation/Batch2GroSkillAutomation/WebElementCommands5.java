package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) throws InterruptedException {
		 
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		String labelVal="";
		
		WebElement ele=driver.findElement(By.xpath("//a[@aria-label='Gmail ']"));
		if(ele.isDisplayed()==true && ele.isEnabled()==true)
		{
		 labelVal=	ele.getText();
		}
		
		System.out.println(labelVal);

	}

}
