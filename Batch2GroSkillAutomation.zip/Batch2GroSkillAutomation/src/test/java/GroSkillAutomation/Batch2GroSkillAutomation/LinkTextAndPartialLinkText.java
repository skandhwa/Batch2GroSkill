package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkTextAndPartialLinkText {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/link.html");
		Thread.sleep(3000);
	WebElement ele=	driver.findElement(By.partialLinkText("click here "));
		if(ele.isDisplayed()==true && ele.isEnabled()==true)
		{
			ele.click();
		}

	}

}
