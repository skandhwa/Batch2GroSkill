package GroSkillAutomation.Batch2GroSkillAutomation;



import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands7 {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.id("firstName"));
String TagName=	ele.getTagName();

System.out.println("TagName is "+TagName);

Dimension d=ele.getSize();

System.out.println("Height of element is "+d.height );
System.out.println("Width of element is "+d.width );



Point p=ele.getLocation();

System.out.println("X coordinate is "+p.getX());
System.out.println("Y coordinate is "+p.getY());


	

	}

}
