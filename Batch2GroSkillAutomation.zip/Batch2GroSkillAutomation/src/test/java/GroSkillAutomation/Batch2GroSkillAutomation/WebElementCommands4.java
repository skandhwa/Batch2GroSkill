package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands4 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
	WebElement ele=	driver.findElement(By.xpath("//input[@id='checkbox1']"));
		Thread.sleep(5000);
	boolean flag=ele.isSelected();
	
	if(flag==false)
	{
		ele.click();
	}
		

	}

}
