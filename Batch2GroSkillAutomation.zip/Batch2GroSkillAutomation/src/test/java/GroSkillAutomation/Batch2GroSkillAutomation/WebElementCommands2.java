package GroSkillAutomation.Batch2GroSkillAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands2 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
	List<WebElement> li=	driver.findElements(By.tagName("a"));
int x=	li.size();	

System.out.println("The total number of links in webpage is "+x);
	
	
		
		

	}

}
