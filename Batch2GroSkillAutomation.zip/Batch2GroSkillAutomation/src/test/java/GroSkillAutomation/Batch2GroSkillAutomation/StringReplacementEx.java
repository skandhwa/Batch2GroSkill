package GroSkillAutomation.Batch2GroSkillAutomation;

public class StringReplacementEx {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder();
		
		
		 String str="India";
		 char []s=str.toCharArray();
		 for(int i=1;i<s.length-1;i=i+1)
		 {
			 sb.setCharAt(i, '*');
		 }
		 
		 System.out.println(sb.toString());
		

	}

}
