package AlertsEx;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		///Simple Alert
		
//	WebElement ele=	driver.findElement(By.xpath("//button[@class='btn btn-danger']"));
//    if(ele.isDisplayed()==true && ele.isEnabled()==true)
//    {
//    	ele.click();
//    }
//    
//    Thread.sleep(3000);
//    driver.switchTo().alert().accept();
//	
//	
//	}
		
		
		///Confirmation Alert
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		driver.switchTo().alert().dismiss();
//String Value=		driver.findElement(By.xpath("//p[@id='demo']")).getText();
//		System.out.println(Value);
//		if(Value.contains("Cancel"))
//		{
//			System.out.println("Test case passed");
//		}
//		else
//		{
//			System.out.println("Test case failed");
//		}
		
	
		
		///Prompt Alert
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Alert alert=driver.switchTo().alert();
		alert.sendKeys("Sachin Tendulkar");
		alert.accept();
		
	String Value=	driver.findElement(By.xpath("//p[@id='demo1']")).getText();
	System.out.println(Value);
	
	
	
	
	

}
}
