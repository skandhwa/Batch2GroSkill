package NewTestJanbask;

public class MissingNumbersEx {

	public static void main(String[] args) {
		
		int []a= {1,2,3,4,6};
		
		
		int x=a.length+1;
		
		int expected_sum=(x*(x+1))/2;
		
		int actual_sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			actual_sum=actual_sum+a[i];
		}
		
		
		int num=expected_sum-actual_sum;
		
		System.out.println("Missing number is "+num);
		

	}

}
