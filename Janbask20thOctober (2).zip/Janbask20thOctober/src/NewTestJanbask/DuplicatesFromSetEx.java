package NewTestJanbask;

import java.util.HashSet;
import java.util.Set;

public class DuplicatesFromSetEx {

	public static void main(String[] args) {
		
		String str="Tip tap toe tip tip toe";
		
		str=str.toLowerCase();
		
		String []s1=str.split(" ");
		
		Set<String> st1=new HashSet<String>();
		Set<String> st2=new HashSet<String>();
		
		for(String x:s1)
		{
			if(st1.contains(x))
			{
				st2.add(x);
			}
			
			else
			{
				st1.add(x);
			}
		}
		
		for(String y:st2)
		{
			System.out.println(y);
		}
		
		
		
		
		
		

	}

}
