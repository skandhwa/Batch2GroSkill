package NewTestJanbask;

import java.util.HashSet;

public class DuplicatesEx {

	public static void main(String[] args) {
		
		
		        int[] array = {2, 4, 5, 6, 2, 3, 5, 5};

		        
		        HashSet<Integer> duplicates = new HashSet<>();
		        
		        HashSet<Integer> visited = new HashSet<>();

		        for (int num : array) {
		            if (visited.contains(num)) {
		                // If already visited, it's a duplicate
		                duplicates.add(num);
		            } else {
		                // Add to visited set
		                visited.add(num);
		            }
		        }

		        // Print all duplicates
		        System.out.println("Duplicate elements in the array are:");
		        for (int duplicate : duplicates) {
		            System.out.println(duplicate);
		        }
		    }
		}