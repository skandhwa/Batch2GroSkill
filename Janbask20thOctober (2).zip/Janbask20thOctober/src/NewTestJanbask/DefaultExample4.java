package NewTestJanbask;

public class DefaultExample4 {

	public static void main(String[] args) {
		
		AB obj=new AB();
		obj
		

	}

}
