package NewTestJanbask;

import java.util.Stack;

public class ValidParenthesis {

    // Function to check if the parentheses are valid
    public static boolean isValidParenthesis(String s) {
        // Create a stack to hold the opening parentheses
        Stack<Character> stack = new Stack<>();

        // Loop through the string
        for (char ch : s.toCharArray()) {
            // If the character is an opening parenthesis, push it to the stack
            if (ch == '(' || ch == '[' || ch == '{') {
                stack.push(ch);
            } 
            // If the character is a closing parenthesis, check the stack
            else if (ch == ')' || ch == ']' || ch == '}') {
                // If stack is empty, or the top of the stack is not a matching opening parenthesis, return false
                if (stack.isEmpty()) {
                    return false;
                }
                char top = stack.pop();
                // Check if the popped parenthesis matches the current closing parenthesis
                if ((ch == ')' && top != '(') || 
                    (ch == ']' && top != '[') || 
                    (ch == '}' && top != '{')) {
                    return false;
                }
            }
        }

        // If the stack is empty, all parentheses are matched
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        // Test cases
        String test1 = "()[]{}";  // Expected output: true
        String test2 = "([)]";    // Expected output: false
        String test3 = "{[}";     // Expected output: false
        String test4 = "{[]}";    // Expected output: true
        
        System.out.println(isValidParenthesis(test1)); // Output: true
        System.out.println(isValidParenthesis(test2)); // Output: false
        System.out.println(isValidParenthesis(test3)); // Output: false
        System.out.println(isValidParenthesis(test4)); // Output: true
    }
}