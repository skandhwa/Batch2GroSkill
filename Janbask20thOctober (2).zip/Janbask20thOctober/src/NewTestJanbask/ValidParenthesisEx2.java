package NewTestJanbask;

import java.util.Scanner;
import java.util.Stack;

class Test3
{
	public static boolean isValid(String str)
	{
		char []s1=str.toCharArray();
		Stack<Character> stk=new Stack<Character>();
		for(int i=0;i<s1.length;i++)
		{
			if(s1[i]=='(' || s1[i]=='{' || s1[i]=='[')
			{
				stk.push(s1[i]);
			}
			
			else if(s1[i]==')'|| s1[i]=='}' || s1[i]==']')
			{
				char top=stk.pop();
				if(s1[i]==')' && top!='(' || s1[i]=='{' && top!='}'
						|| s1[i]=='[' && top!=']' )
				{
					return false;
				}
				
			}
		}
		
		return stk.isEmpty();
		
		
	}
	
			
}			
				
			


public class ValidParenthesisEx2 {

	public static void main(String[] args) {
		
		System.out.println("Enter a String");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		
		System.out.println(Test3.isValid(str));
		
		
		
		
		
		

	}

}
