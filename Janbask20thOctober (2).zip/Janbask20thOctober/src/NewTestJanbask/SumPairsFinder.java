package NewTestJanbask;

import java.util.HashSet;

public class SumPairsFinder {
    public static void findPairsWithSum(int[] arr, int targetSum) {
        HashSet<Integer> seenNumbers = new HashSet<>();
        boolean found = false;
        
        System.out.println("Pairs that sum to " + targetSum + ":");
        for (int num : arr) {
            int complement = targetSum - num;
            if (seenNumbers.contains(complement)) {
                System.out.println("(" + num + ", " + complement + ")");
                found = true;
            }
            seenNumbers.add(num);
        }
        
        if (!found) {
            System.out.println("No pairs found.");
        }
    }
    
    public static void main(String[] args) {
        int[] numbers = {1, 4, 7, 2, 5, 3, 9, 8};
        int target = 10;
        findPairsWithSum(numbers, target);
    }
}
