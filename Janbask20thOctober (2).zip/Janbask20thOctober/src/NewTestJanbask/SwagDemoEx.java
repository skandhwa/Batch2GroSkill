package NewTestJanbask;

public class SwagDemoEx {

	public static void main(String[] args) {
		
		  int [] arr = new int [] {1, 2, 3, 4, 5};   
	        
	        int n = 3;  
	        int l=arr.length;
	        int j, last;  
	          
	       
	          
	        
	        for(int i = 0; i < n; i++){  
	            
	            
	            last = arr[l-1];  
	          
	            for(j = l-1; j > 0; j--){  
	               
	                arr[j] = arr[j-1];  
	            }  
	           
	            arr[0] = last;  
	        }  
	      
	       
	          
	      
	        System.out.println("Array after right rotation: ");  
	        for(int i = 0; i< l; i++){  
	            System.out.print(arr[i] + " ");  
	        }  
		

	}

}
