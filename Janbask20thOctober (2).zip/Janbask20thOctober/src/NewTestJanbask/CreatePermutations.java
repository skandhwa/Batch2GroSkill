package NewTestJanbask;

class Test
{
	public static void generatePermutations(String str,int start,int end)
	{
		if(start==end)
		{
			System.out.println(str);
		}
		
		else
		{
			for(int i=start;i<=end;i++)
			{
				str=swap(str,start,i);
			
			
			generatePermutations( str,start+1,end);
			str=swap(str,start,i);
			}
			
		}
	}


public static String swap(String str,int i,int j)
{
	char []strarray=str.toCharArray();
	char temp=strarray[i];
	strarray[i]=strarray[j];
	strarray[j]=temp;
	return String.valueOf(strarray);
	
}

}





public class CreatePermutations {

	public static void main(String[] args) {
		
		String str="ABC";
		int x=str.length();
		
		Test.generatePermutations( str,0,x-1);
		
		

	}

}
