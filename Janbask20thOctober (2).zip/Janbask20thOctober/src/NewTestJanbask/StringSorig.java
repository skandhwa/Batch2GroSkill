package NewTestJanbask;

import java.util.Arrays;

class T4
{
	public static String sortedString(String str)
	{
		char []ch=str.toCharArray();
		Arrays.sort(ch);
		return new String(ch);
	}
}


public class StringSorig {

	public static void main(String[] args) {
		
		String str="Apple";
		str=str.toLowerCase();
	String str2=	T4.sortedString(str);
	System.out.println(str2);
		
	}

}
