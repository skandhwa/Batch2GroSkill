package TestJanbask;

abstract class A1
{
	void test()
	{
		System.out.println("I am test method");
	}
	
	abstract void message();
}

class A2 extends A1
{
	void message()
	{
		System.out.println("I am message method");
	}
	
}
public class AbstractionEx2 {

	public static void main(String[] args) {
		
		A2 obj=new A2();
		obj.message();
		obj.test();
		
		
		

	}

}
