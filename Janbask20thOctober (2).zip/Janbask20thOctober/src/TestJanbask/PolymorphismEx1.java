package TestJanbask;

class student2
{
	int marks(int x,int y)
	{
		return x+y;
	}
	
	int marks(int x,int y,int z)
	{
		return x+y+z;
	}
	
	float marks(float x,float y)
	{
		return x+y;
	}
	
}public class PolymorphismEx1 {

	public static void main(String[] args) {
		
		student2 obj=new student2();
	System.out.println(obj.marks(23, 15));	
	
	System.out.println(	obj.marks(23.5f, 67.5f));
	
	System.out.println(	obj.marks(45, 67, 99));
		
		
	}

}
