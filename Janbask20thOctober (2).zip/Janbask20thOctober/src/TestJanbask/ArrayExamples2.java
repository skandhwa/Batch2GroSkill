package TestJanbask;

public class ArrayExamples2 {

	public static void main(String[] args) {
		
//		int []a= {23,45,67,88};
//		
//		int [][]c={{1,2,3},{4,5,6}};
//		
//		System.out.println(c[2][1]);
//		
//		int []b=a;
//		
//		for(int x:b)
//		{
//			System.out.println(x);
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
