package TestJanbask;

public class LogicalOperator {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		int c=40;
		
		if(a>b || b<c || b<a)///
		{
			System.out.println("true");
		}
		
		else
		{
			System.out.println("false");
		}
		
		

	}

}
