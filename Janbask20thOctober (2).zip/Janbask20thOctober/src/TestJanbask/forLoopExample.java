package TestJanbask;

public class forLoopExample {

	public static void main(String[] args) {
		
		
		for(int i=1;i<=5;)///i=1,1<=5//i=2,2<=5
		{
			System.out.println(i);///1///2
			i++;
		}
		

	}

}
