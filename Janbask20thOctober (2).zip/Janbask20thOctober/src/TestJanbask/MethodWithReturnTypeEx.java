package TestJanbask;

public class MethodWithReturnTypeEx {
	
	static double area(int x)
	{
		double area= 3.14*x*x;
		return area;
		
		
		
	}
	
	public static void main(String[] args) {
		
	System.out.println(MethodWithReturnTypeEx.area(4));	
	System.out.println(MethodWithReturnTypeEx.area(6));		
	System.out.println(MethodWithReturnTypeEx.area(9));	

	}

}
