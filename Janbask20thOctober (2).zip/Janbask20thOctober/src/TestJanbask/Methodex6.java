package TestJanbask;


class Example4
{
	void display()
	{
		int x=20;
		int y=30;
		int z=x+y;
		System.out.println(z);
	}
}
public class Methodex6 {

	public static void main(String[] args) {
		
		Example4 obj=new Example4();
		obj.display();

	}

}
