package TestJanbask;

public class methodEx5 {
	
	static double area(int x,int y)
	{
		double area=3.14*x*x*y;
		return area;
		
	}
	
	public static void main(String[] args) {
		
	System.out.println(methodEx5.area(5, 2));	
	System.out.println(methodEx5.area(6, 3));
	System.out.println(methodEx5.area(9, 4));

	}

}
