package TestJanbask;

public class MySecond {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		int c=60;
		
		int z=a+b+c;
		
		System.out.println(z);
		
		
		

	}

}
