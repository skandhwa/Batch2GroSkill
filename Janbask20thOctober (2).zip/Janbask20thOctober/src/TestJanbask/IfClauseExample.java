package TestJanbask;

public class IfClauseExample {

	public static void main(String[] args) {
		
		int x=20;
		if(x>=19)///20>=19
		{
			System.out.println("Yes I am true");
		}
		
		else
			
		{
			System.out.println("I am false");
		}
		
		
		

	}

}
