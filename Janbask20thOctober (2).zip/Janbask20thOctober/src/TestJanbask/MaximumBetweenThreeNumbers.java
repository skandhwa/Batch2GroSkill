package TestJanbask;

public class MaximumBetweenThreeNumbers {

	public static void main(String[] args) {
		
		int a=20,b=40,c=30,d=15,e=61;
		
		if(a>b && a>c && a>d && a>e)//
		{
			System.out.println("Maximum is a");
		}
		
		else if(b>a && b>c && b>d && b>e)
		{
			System.out.println("Maximum is b");
		}
		else if(c>a && c>b && c>d && c>e)
		{
			System.out.println("Maximum is c");
		}
		
		else if(d>a && d>b && d>c && d>e)
		{
			System.out.println("Maximum is d");
		}
		
		else
		{
			System.out.println("Maximum is e");
		}
		
		
		

	}

}
