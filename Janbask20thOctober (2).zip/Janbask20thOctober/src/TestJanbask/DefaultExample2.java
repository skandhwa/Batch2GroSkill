package TestJanbask;

class AB
{
	void display()
	{
		int x=10;
		int y=x+20;
		System.out.println(y);
	}
	
}

public class DefaultExample2 {

	public static void main(String[] args) {
		
		AB obj=new AB();
		obj.display();
		

	}

}
