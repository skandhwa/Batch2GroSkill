package TestJanbask;

public class NestedIfExample {

	public static void main(String[] args) {
		
		int x=10;
		int y=20;
		
		if(x<y)//10<20
		{
			if(x>=5)///10>=5
			{
				if(x<=8)///10<=8
				{
					System.out.println("Hello I am true");
				}
				else
				{
					System.out.println("Hello I am false 1");
				}
			}
		}
		
		else
		{
			System.out.println("I am false 2");
		}
		
		

	}

}
