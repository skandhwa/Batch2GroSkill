package TestJanbask;

public class dowhileExample3 {

	public static void main(String[] args) {
		
		
		int x=5;
		
		do
		{
			System.out.println(x);
			x--;
		}
		
		while(x>=2);
		

	}

}
