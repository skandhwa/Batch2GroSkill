package TestJanbask;

public class DivideANumberbyZero {

	public static void main(String[] args) {
		
		try
		{
		
		int x=10;
		int y=x/0;
		System.out.println(y);
		}
		
		catch(Exception v)
		{
			System.out.println("Caught with" +v);
		}
		
		int z=30+10;
		System.out.println(z);
		
		
		
		

	}

}
