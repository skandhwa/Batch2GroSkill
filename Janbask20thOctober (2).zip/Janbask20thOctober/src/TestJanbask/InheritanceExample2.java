package TestJanbask;

class Car
{
	void brake()
	{
		System.out.println("I am brake method");
	}
}

class Honda extends Car
{
	void accelerate()
	{
		System.out.println("I am accelerate method");
	}
}

public class InheritanceExample2 {

	public static void main(String[] args) {
		
		Honda obj=new Honda();
		obj.accelerate();
		obj.brake();
		
		

	}

}
