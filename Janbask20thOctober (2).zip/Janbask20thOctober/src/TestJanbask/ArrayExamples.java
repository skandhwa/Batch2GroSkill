package TestJanbask;

public class ArrayExamples {

	public static void main(String[] args) {
		
		int []a= {5,7,12,34,56};
		
		
		int m=a.length;
		System.out.println("The length of the array is "+m);
		
		
		for(int x:a)
		{
			System.out.print(x+" ");
		}
		
		System.out.println();
		
		System.out.println(a[2]);
		
		
		
		String []b= {"UFT","Selenium","Parasoft","LoadRunner"};
		
		char []c= {'A','B','C','D'};
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
