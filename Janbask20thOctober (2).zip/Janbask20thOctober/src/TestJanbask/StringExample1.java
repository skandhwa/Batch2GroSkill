package TestJanbask;

public class StringExample1 {

	public static void main(String[] args) {
		
		String str="Saurabh";
		System.out.println(str);
		
		
		String str1="1234";
		
		String str2="A";
		
		String str3="@$%&";
		
		
		String []languages={"Java","C","C++","Pyhton"};
		
		for(String x:languages)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
