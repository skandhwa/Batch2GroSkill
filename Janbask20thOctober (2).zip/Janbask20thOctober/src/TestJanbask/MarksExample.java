package TestJanbask;

class Example9
{
	static void marks(int x)
	{
		if(x>400)
		{
			System.out.println("Grade A");
			
		}
		
		if(x>300)
		{
			System.out.println("Grade B");
		}
		if(x>200)
		{
			System.out.println("Grade C");
		}
	}
}



public class MarksExample {

	public static void main(String[] args) {
		
		Example9.marks(400);
		
		

	}

}
