package TestJanbask;

interface test1
{
	 void display();
	 void test();
}

class test2 implements test1
{
	public void display()
	{
		System.out.println("I am display method");
	}
	
	public void test()
	{
		System.out.println("I am test method");
	}
}

public class InterfaceEx1 {

	public static void main(String[] args) {
		
       test2 obj=new test2();
       obj.display();
       obj.test();
		
		
	}

}
