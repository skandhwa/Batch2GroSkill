package TestJanbask;

public class CharacterMethodsEx {

	public static void main(String[] args) {
		
		char ch='p';
		
	//	System.out.println(Character.isLetter(ch));
		
	//	System.out.println(Character.isDigit(ch));
		
		
		System.out.println(Character.isUpperCase(ch));

	}

}
