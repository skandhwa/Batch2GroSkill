package TestJanbask;

public class doWhileLoopExample {

	public static void main(String[] args) {
		
		int i=1;
		
		do
		{
			System.out.println(i);///1///2///3
			i++;//2//3
		}
		
		while(i<=3);///2<=3//3<=3
		
		

	}

}
