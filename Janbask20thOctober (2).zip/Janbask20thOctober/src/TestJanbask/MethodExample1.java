package TestJanbask;

public class MethodExample1 {
	
	void add()
	{
		int x=10;
		int y=20;
		int z=x+y;
		System.out.println(z);
	}
	
	

	public static void main(String[] args) {
		
		MethodExample1 obj=new MethodExample1();
		obj.add();

	}

}
