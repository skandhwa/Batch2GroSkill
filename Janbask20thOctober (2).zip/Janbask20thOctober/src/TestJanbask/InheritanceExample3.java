package TestJanbask;

class diagram
{
	static int add(int x,int y)
	{
		return x+y;
	}
}

class circle extends diagram
{
	static int sub(int x,int y)
	{
		return x-y;
	}
}

public class InheritanceExample3 {

	public static void main(String[] args) {
		
	System.out.println(circle.sub(23, 15));	
	System.out.println(	circle.add(12,45));
		

	}

}
