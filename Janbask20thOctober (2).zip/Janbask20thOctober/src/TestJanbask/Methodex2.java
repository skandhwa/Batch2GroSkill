package TestJanbask;

public class Methodex2 {
	
	float multiply()
	{
		int x=30;
		int y=45;
		float z=x*y;
		return z;
	}
	

	public static void main(String[] args) {
		
		Methodex2 obj=new Methodex2();
	System.out.println(obj.multiply());	
		

	}

}
