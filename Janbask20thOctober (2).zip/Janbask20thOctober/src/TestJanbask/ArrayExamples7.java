package TestJanbask;

import java.util.Arrays;

public class ArrayExamples7 {

	public static void main(String[] args) {
		
		String []a= {"Selenium","UFT","Python","Java"};
		int x=a.length;
		System.out.println(x);
		
	String str1=	Arrays.toString(a);
	
	System.out.println(str1);
	
	boolean p=Arrays.asList(a).contains("java");
	System.out.println(p);
	
	
	
		
		
		

	}

}
