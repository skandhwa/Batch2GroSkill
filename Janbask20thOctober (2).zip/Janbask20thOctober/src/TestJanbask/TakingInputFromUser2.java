package TestJanbask;

import java.util.Scanner;

public class TakingInputFromUser2 {

	public static void main(String[] args) {
		
		System.out.println("Enter a Character of your choice");
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		System.out.println("The Value entered by you is "+ch);
		
		System.out.println("Enter a very large value");
		long x=sc.nextLong();
		System.out.println("The large value entered by you is "+x);
		
		
		
		
		
		
		

	}

}
