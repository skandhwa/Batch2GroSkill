package TestJanbask;

import java.util.LinkedHashMap;
import java.util.Map;

public class StringCompareMethod {

	public static void main(String[] args) {
		
		String str="Java";
		str=str.toLowerCase();
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		char []ch=str.toCharArray();
		
		for(int i=0;i<ch.length;i++)
		{
			if(!mp.containsKey(ch[i]))
			{
				mp.put(ch[i],1);
			}
			else
			{
			i=	mp.get(ch[i]);
			}
		}
		
		
		
		
		
		

	}

}
