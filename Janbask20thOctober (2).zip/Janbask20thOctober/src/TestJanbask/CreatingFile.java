package TestJanbask;

import java.io.File;
import java.io.IOException;

public class CreatingFile {

	public static void main(String[] args) throws IOException {
		
		File obj=new File("E:\\Test28October\\TestNew2.txt");
	boolean flag=	obj.createNewFile();
	System.out.println(flag);
	
boolean flag2=	obj.delete();
System.out.println(flag2);
		

	}

}
