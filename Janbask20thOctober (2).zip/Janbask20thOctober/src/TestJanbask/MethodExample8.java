package TestJanbask;

public class MethodExample8 {
	
	String test(String x)
	{
		return x;
	}
	

	public static void main(String[] args) {
		
		MethodExample8 obj=new MethodExample8();
		obj.test("Saurabh");
		

	}

}
