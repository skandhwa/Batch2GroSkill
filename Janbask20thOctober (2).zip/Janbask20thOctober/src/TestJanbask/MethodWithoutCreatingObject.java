package TestJanbask;

public class MethodWithoutCreatingObject {
	
	static void display()
	{
		int x=20;
		int y=30;
		int z=x+y;
		System.out.println(z);
	}
	
	

	public static void main(String[] args) {
		
		MethodWithoutCreatingObject.display();
		
		

	}

}
