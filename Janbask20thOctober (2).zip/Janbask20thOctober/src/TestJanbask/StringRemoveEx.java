package TestJanbask;

public class StringRemoveEx {

	public static void main(String[] args) {
		
		String str="He&*%$#)(*llo World";
		
		str=str.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(str);
		

	}

}
