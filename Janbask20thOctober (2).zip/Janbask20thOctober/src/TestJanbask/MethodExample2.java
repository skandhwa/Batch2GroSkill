package TestJanbask;

public class MethodExample2 {
	
	
	int add()
	{
		int x=10;
		int y=20;
		int z=x+y;
		return z;
		
	}
	

	public static void main(String[] args) {
		
		MethodExample2 obj=new MethodExample2();
		 System.out.println(obj.add());    
		
		

	}

}
