package TestJanbask;

public class SwitchExample2 {

	public static void main(String[] args) {
		
		
		char grade='A';
		
		switch(grade)
		{
		
		case 'A':
			System.out.println("You have scored A");
			break;
			
		case 'B':
			System.out.println("You have scored B");
			break;
			
			
		case 'C':
			System.out.println("You have scored C");
			break;
			
		default:
			System.out.println("Not in any of these");
			
			
			
			
		}
		
		
		
		

	}

}
