package TestJanbask;

public class StringComparision {

	public static void main(String[] args) {
		
		String str1="Test";
		String str2="test";
		
	//System.out.println(str1==str2);	
	
	System.out.println(str1.equalsIgnoreCase(str2));
	
	 
	
	
	
		
		

	}

}
