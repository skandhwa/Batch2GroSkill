package TestJanbask;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int i=5;///initialization
		
		while(i<=10)////condition checking
		{
			System.out.println(i);
			i++;////increment/decrement
		}
		
		
		
		

	}

}
