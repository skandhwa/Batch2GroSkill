package TestJanbask;

public class StringComparasionMethods4 {

	public static void main(String[] args) {
		
//		String str1="India";
//		String str2="india";
//		
//		
//	boolean x=	str1.equalsIgnoreCase(str2);
//	System.out.println(x);
		
		String str1="Saurabh";
		String str2="Kandhway";
		
	String str3=	str1.concat(str2);
	System.out.println(str3);
	
	String str4="Ramani";
	String str5=str4.toUpperCase();
	System.out.println(str5);
	
	String str6="italy";
	String str7=str6.toUpperCase();
	System.out.println(str7);
	
	String str8="BRAZIL";
	String str9=str8.toLowerCase();
	System.out.println(str9);
	
	
	
	char ch=str4.charAt(5);
	System.out.println(ch);
		
		

	}

}
