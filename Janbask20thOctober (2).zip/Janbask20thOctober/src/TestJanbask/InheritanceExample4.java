package TestJanbask;

class animal
{
	void eat()
	{
		System.out.println("Animals eat");
	}
}

class mammal extends animal
{
	void drink()
	{
		System.out.println("Mammals drink");
	}
}

class human extends mammal
{
	void sleep()
	{
		System.out.println("Humans sleep");
	}
}
public class InheritanceExample4 {

	public static void main(String[] args) {
		
		human obj=new human();
		obj.eat();
		obj.sleep();
		obj.drink();
		
	}

}
