package TestJanbask;

public class StringException {

	public static void main(String[] args) {
		
		try
		{
		
		String str=null;
		int x=str.length();
		System.out.println(x);
		
		}
		
		catch(Exception b)
		{
			System.out.println("caught with  "+b);
		}
		
		try
		{
		
int[] b=new int[5];
		
      
		
		b[0]=23;
		b[1]=65;
		b[2]=78;
		b[3]=66;
		b[4]=89;
		b[5]=61;
		
		for(int y:b)
		{
			System.out.println(y);
		}
		}
		
		catch(Exception t)
		{
			System.out.println("caught with "+t);
		}
		
		
		
		int z=10;
		int y=z+10;
		System.out.println(y);
		
		

	}

}
