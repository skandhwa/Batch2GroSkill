package TestJanbask;

public class MethodWithReturntypes {
	
	void subtract()
	{
		int x=10;
		int y=5;
		int z=x-y;
		System.out.println(z);
	}
	
	public static void main(String[] args) {
		
		MethodWithReturntypes obj=new MethodWithReturntypes();
		obj.subtract();
	}

}
