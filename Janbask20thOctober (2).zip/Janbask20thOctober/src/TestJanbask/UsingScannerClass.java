package TestJanbask;

import java.util.Scanner;

public class UsingScannerClass {

	public static void main(String[] args) {
		
		System.out.println("Enter The String as Input");
		
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		System.out.println("Your Name is "+name);
		
		System.out.println("Enter your Number ");
		int num=sc.nextInt();
		System.out.println("The entered number is "+num);
		
		

	}

}
