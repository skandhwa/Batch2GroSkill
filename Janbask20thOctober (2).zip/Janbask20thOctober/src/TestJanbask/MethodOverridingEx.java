package TestJanbask;

class Bank
{
	void rateofIntrest()
	{
		System.out.println("The rate of intrest is 8");
	}
}

class SBI extends Bank
{
	void rateofIntrest()
	{
		System.out.println("The rate of intrest is 10");
	}
}

class StanC extends Bank
{
	void rateofIntrest()
	{
		System.out.println("The rate of intrest is 12");
	}
	
}
public class MethodOverridingEx {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.rateofIntrest();
		
		Bank obj1=new Bank();
		obj1.rateofIntrest();
		
		StanC obj2=new StanC();
		obj2.rateofIntrest();
		
		
		

	}

}
