package TestJanbask;

class Example7
{
	static int add(int x,int y)
	{
		return x+y;
		
	}
}
public class Staticanotherclass {

	public static void main(String[] args) {
		
	System.out.println(Example7.add(45, 67));	

	}

}
