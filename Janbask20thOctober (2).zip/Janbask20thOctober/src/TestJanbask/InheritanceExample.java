package TestJanbask;

class Inh1
{
	void display()
	{
		System.out.println("I am inheritance 1");
	}
}

class Inh2 extends Inh1
{
	void test()
	{
		System.out.println("I am inh2");
	}
}

public class InheritanceExample {

	public static void main(String[] args) 
	{
		Inh2 obj=new Inh2();
		obj.display();
		obj.test();
		

	}

}
