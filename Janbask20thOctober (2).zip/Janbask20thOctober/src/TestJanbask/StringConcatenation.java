package TestJanbask;

public class StringConcatenation {

	public static void main(String[] args) {
		
		String str1="Apple";
		String str2="iPhones";
		
//		String str3=str1+str2;
//		System.out.println(str3);
		
		String str4=str1+(1+1);
		System.out.println(str4);
		
		String str5=str1+"1"+(1+3);
		System.out.println(str5);
		
		

	}

}
