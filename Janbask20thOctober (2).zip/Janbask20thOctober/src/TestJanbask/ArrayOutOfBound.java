package TestJanbask;

public class ArrayOutOfBound {

	public static void main(String[] args) {
    
		try
		{
		
		int[] b=new int[5];
		
      
		
		b[0]=23;
		b[1]=65;
		b[2]=78;
		b[3]=66;
		b[4]=89;
		b[5]=61;
		
		for(int y:b)
		{
			System.out.println(y);
		}
		
		}
		
		catch(Exception e)
		{
			System.out.println("Caught with "+e);
		}
		
		
		int z=30+10;
		System.out.println(z);
		

	}

}
