package TestJanbask;

public class StringExamples8 {

	public static void main(String[] args) {
		
//		String str="Africa";
//		
//	String str4=	str.substring(3,5);
//	System.out.println(str4);
		
		
//		String str="Africa and Europe";
//	boolean a=	str.endsWith("urope");
//	System.out.println(a);
//	
//	
//	String str2="Argentina";
//	int x=str2.length();
//	System.out.println(x);
	
	
	int m=89;
	int n=89;
	Integer p=m;
	Integer q=n;
	
//int z=	p.compareTo(q);
//System.out.println(z);

boolean t=p.equals(q);
System.out.println(t);

double a=10;
 System.out.println(Math.abs(a));   
 
 
 double k=34.499999;
 System.out.println(Math.round(k));
 
 
 int v=934;
 int r=678;
 
 int max=Math.min(v, r);
 System.out.println(max);
 
 System.out.println(Math.min(v,r));
 
	
	
	
	
		
	
	
	
	
	
	
	
		
		
		
		

	}

}
