package TestJanbask;

public class RelationalOperatosExample {

	public static void main(String[] args) {
		
		int a=11;
		int b=10;
		
		System.out.println(a!=b);
		

	}

}
