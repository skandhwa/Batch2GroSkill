package TestJanbask;

import java.io.File;

public class CreateAFolder {

	public static void main(String[] args) {
		
		File obj=new File("D:\\Test22ndJune\\MyNew");
		obj.mkdir();
		System.out.println("Folder created");
		//boolean x=obj.delete();
		//System.out.println(x);
		
		
		
		

	}

}
