package TestJanbask;
import java.math.*;



public class BuitInMethods {

	public static void main(String[] args) {
		
		int x=225;
		double y=Math.sqrt(x);
		
		
		

	}

}
