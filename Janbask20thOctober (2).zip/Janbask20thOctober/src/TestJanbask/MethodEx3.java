package TestJanbask;

public class MethodEx3 {
	
	int add(int x,int y,int z)
	{
		return x+y+z;
	}
	
	
	public static void main(String[] args) 
	{
		MethodEx3 obj=new MethodEx3();
	System.out.println(obj.add(34, 45,56));	

	}

}
