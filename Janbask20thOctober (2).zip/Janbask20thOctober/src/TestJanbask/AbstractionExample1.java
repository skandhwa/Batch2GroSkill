package TestJanbask;

abstract class T1
{
	abstract void test();
	void display()
	{
		System.out.println("I am display method");
	}
}

class T2 extends T1
{
	void test()
	{
		System.out.println("I am test method");
	}
}

public class AbstractionExample1 {

	public static void main(String[] args) {
		
		T2 obj=new T2();
		obj.test();
		obj.display();
		

	}

}
