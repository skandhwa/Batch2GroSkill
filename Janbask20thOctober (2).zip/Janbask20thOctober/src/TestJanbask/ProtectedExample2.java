package TestJanbask;

public class ProtectedExample2 {

	public static void main(String[] args) {
		
		AC obj1=new AC();
		obj1.display();
		
		
		
		

	}

}
