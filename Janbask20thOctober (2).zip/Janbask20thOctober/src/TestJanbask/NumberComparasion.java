package TestJanbask;

public class NumberComparasion {

	public static void main(String[] args) {
		
		int a=30;
		int b=40;
		
		if(a>b)///30>40
		{
			System.out.println("Maximum is a");
		}
		else
		{
			System.out.println("Maximum is b");
			
		}
		
		

	}

}
