package TestJanbask;

public class StringExamples7 {

	public static void main(String[] args) {
		
		String str="     India       ";
		System.out.println(str);
		
	String str2=	str.trim();
	System.out.println(str2);
		
		
	}

}
