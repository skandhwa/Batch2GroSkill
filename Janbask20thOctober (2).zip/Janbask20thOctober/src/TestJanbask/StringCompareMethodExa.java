package TestJanbask;

public class StringCompareMethodExa {

	public static void main(String[] args) {
		
		String str1="Test";
		String str2="Test";
		
	int x=	str1.compareTo(str2);
	System.out.println(x);
 
	
	if(str1==str2)
	{
		System.out.println("true");
	}
	else
	{
		System.out.println("false");
	}
	
	
	
	
		

	}

}
