package TestJanbask;

public class forLoopExample2 {

	public static void main(String[] args) {
		
		for(int x=10;x>=5;)
		{
			System.out.println(x);
			x--;
		}
		

	}

}
