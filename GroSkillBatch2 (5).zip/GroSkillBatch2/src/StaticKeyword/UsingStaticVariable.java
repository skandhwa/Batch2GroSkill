package StaticKeyword;

class C4
{
	int id;
	String name;
	static  String companyName="CTS";
	float salary;
	
	static void change()
	{
		companyName="Infosys";
	}
	
	
	C4(int i,String n)
	{
		id=i;
		name=n;
		
	}
	
	C4(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
		
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+companyName+"  "+salary);
	}
	
	
}

public class UsingStaticVariable {

	public static void main(String[] args) {
		
		C4 obj=new C4(1234,"Rohit");
		obj.display();
		
		C4 obj1=new C4(2234,"Mohit");
		obj1.display();
		
		C4 obj2=new C4(9234,"Sukrit");
		obj2.display();
		
		C4 obj3=new C4(9234,"Sukrit",76000f);
		obj3.display();
		
		

	}

}
