package StaticKeyword;

class C6

{
	static  void test()
	{
		System.out.println("Hello");
	}
}


public class StaticMethodsEx {

	public static void main(String[] args) {
		
		C6.test();
		

	}

}
