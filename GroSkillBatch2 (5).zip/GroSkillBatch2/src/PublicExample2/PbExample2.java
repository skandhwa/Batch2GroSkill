package PublicExample2;

import PublicExample.PbExample1;

public class PbExample2 {

	public static void main(String[] args) {
		
		
		PbExample1 obj=new PbExample1();
		obj.display();

	}

}
