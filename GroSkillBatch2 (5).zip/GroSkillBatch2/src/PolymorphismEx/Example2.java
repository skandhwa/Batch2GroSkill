package PolymorphismEx;

class C10
{
	int sum(int x,int y)
	{
		return x+y;
	}
	
	int sum(int x,int y,int z)
	{
		return x+y+z;
	}
	
	float sum(int x,float y)
	{
		return x+y;
	}
}


public class Example2 {

	public static void main(String[] args) {
		
		C10 obj=new C10();
	System.out.println(obj.sum(12, 14));	
	System.out.println(	obj.sum(12, 14,99));
	System.out.println(	obj.sum(13, 99.76f));
		

	}

}
