package PolymorphismEx;

class C9
{
	int id;
	String name;
	float salary;
	
	C9(int id,String name,float salary)
	{
	this.id=id;
	this.	name=name;
	this.	salary=salary;
	}
	
	void display()
	{
		System.out.println(id+" "+name+"  "+salary);
	}
	
}


public class ThisKeywordExample {

	public static void main(String[] args) {
		
		C9 obj=new C9(1234,"Saurabh",96000f);
		obj.display();
		
		

	}

}
