package SetExample;

import java.util.HashSet;
import java.util.Set;

public class HashSetEx1 {

	public static void main(String[] args) {
		
		Set<Integer> s=new HashSet<Integer>();
		s.add(54);
		s.add(89);
		s.add(65);
		s.add(76);
		
		for(Integer x:s)
		{
			System.out.println(x);
		}
		

	}

}
