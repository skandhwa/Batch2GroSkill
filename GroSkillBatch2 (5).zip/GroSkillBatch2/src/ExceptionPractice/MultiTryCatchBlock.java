package ExceptionPractice;

public class MultiTryCatchBlock {

	public static void main(String[] args) {
		
		try
		{
		
		
		
		
		String str=null;
		int y=str.length();
		System.out.println("Length of string is  "+y);
		
//		int x=9/0;
//		System.out.println(x);
		}
		
		
//		catch(NullPointerException e)
//		{
//			System.out.println("caught with "+e);
//		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
//		catch(ArithmeticException e)
//		{
//			System.out.println("caught with "+e);
//		}
		
//		catch(NullPointerException e)
//		{
//			System.out.println("Caught with "+e);
//		}
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		
		
		
		

	}

}
