package ExceptionPractice;


class Test
{
	public void display() throws InterruptedException
	{
		Thread.sleep(5000);
	}
}


public class ThrowsExample {

	public static void main(String[] args) throws InterruptedException {
		
		
		Test obj=new Test();
		obj.display();
		
		
		

	}

}
