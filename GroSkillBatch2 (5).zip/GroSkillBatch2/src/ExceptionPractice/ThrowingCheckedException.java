package ExceptionPractice;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowingCheckedException {
	
	public static void AccessToFile(boolean flag) throws FileNotFoundException
	{
		if(flag==true)
		{
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Class_Area.txt");
		BufferedReader br=new BufferedReader(f);
		System.out.println("You are elligible");
		}
		else
		{
			throw new FileNotFoundException("You are not elligible to view the file");
		}
			
		
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		
		
		ThrowingCheckedException.AccessToFile(true);
		

	}

}
