package ExceptionPractice;

class VotingProcess
{
	public static void elligible(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException ("Invalid age");
		}
		else
		{
			System.out.println("You are elligible to vote");
		}
	}
}

public class ThrowKeywordEx {

	public static void main(String[] args) {
		
		VotingProcess.elligible(13);
		

	}

}
