package ExceptionPractice;

public class ExceptionEx2 {

	public static void main(String[] args) {
		
		try
		{
		
		String str=null;
		int x=str.length();
		System.out.println("Length of string is  "+x);
		
		}
		
		catch(NullPointerException e)
		{
			System.out.println("Exception caught "+e);
		}
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);

	}

}
