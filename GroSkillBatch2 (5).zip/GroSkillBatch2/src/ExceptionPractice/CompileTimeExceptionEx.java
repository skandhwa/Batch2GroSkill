package ExceptionPractice;

import java.io.File;

public class CompileTimeExceptionEx {

	public static void main(String[] args) throws InterruptedException {
		
		
		Thread.sleep(4000);
		
		
		

	}

}
