package ExceptionPractice;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsExample2 {

	public static void main(String[] args) throws FileNotFoundException {
		
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Class_Area.txt");
		BufferedReader br=new BufferedReader(f);
		

	}

}
