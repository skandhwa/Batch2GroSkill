package FileOperations;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteDataToFile {

	public static void main(String[] args) throws IOException {
		
		
		
		FileWriter fwrite=new FileWriter("E:\\DataFiles\\Test1234.txt");
		fwrite.write("Selenium is demanding ");
		fwrite.close();
		
		
		

	}

}
