package FileOperations;

import java.io.File;

public class DeleteDataFromFile {

	public static void main(String[] args) {
		
		
		File f=new File("‪E:\\DataFiles\\Test123.txt");
		
		boolean flag= f.delete();
		
		System.out.println("Is the file deleted "+flag);
	   
}
	
}
