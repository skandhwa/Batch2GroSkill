package FileOperations;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileAppendOperations {

	public static void main(String[] args) throws IOException {
		
		String fileName="E:\\DataFiles\\Test1234.txt";
		
        BufferedWriter b=new BufferedWriter(new FileWriter(fileName,true));
        
        b.write("Hello How are you");
        
        b.close();
		
		
	}

}
