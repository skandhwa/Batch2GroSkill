package FileOperations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Reader;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File f=new File("E:\\DataFiles\\Test1234.txt");
		Scanner s=new Scanner(f);
		
		while(s.hasNextLine())
		{
			String data=s.nextLine();
			System.out.println(data);
			
		}
		
		s.close();
		
		

	}

}
