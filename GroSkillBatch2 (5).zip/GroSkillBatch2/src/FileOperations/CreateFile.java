package FileOperations;

import java.io.File;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) throws IOException {
		
		File f=new File("E:\\DataFiles\\Test1234.txt");
	boolean flag=	f.createNewFile();
	
	System.out.println(flag);
	
boolean flag2=	f.exists();
System.out.println("Is the file exists "+flag2);


String Path=f.getAbsolutePath();
System.out.println("Absolute path of file is  "+Path);


boolean flag3=f.canRead();
System.out.println("Is the file Readable "+flag3);

boolean flag4=f.canWrite();
System.out.println("Is the file Writable "+flag4);

long x=f.length();
System.out.println("Length of file is  "+x);

if(x==0)
{
boolean flag5=	f.delete();

System.out.println("Is the File Deleted "+flag);
}

else
{
	System.out.println("The file contains data ?Ary you sure you want to delete");
}

}

		

	}

}
