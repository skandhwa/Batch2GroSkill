package StringPractice;

public class StringMethods7 {

	public static void main(String[] args) {
		
		
		String str="India is a great country with people who are great";
	int x=	str.indexOf("great",16);
	
	System.out.println("Index of great is "+x);
	
	
	String str2="   India   Nation   ";
	System.out.println("Before trimming "+str2);
	str2=str2.trim();
	System.out.println("After trimming "+str2);
		
		
	}

}
