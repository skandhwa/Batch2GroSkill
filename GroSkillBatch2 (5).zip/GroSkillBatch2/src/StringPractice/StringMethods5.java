package StringPractice;

public class StringMethods5 {

	public static void main(String[] args) {
		
//		String str="National@India@Test";
//		
//	String []ch=	str.split("@");
//	
//	System.out.println(ch[2]);
		
		String str="India is a great country";
	String []s1=	str.split(" ");
	
	System.out.println(s1[2]);
		
		
		
		

	}

}
