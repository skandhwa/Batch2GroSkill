package StringPractice;

public class StringMethods9 {

	public static void main(String[] args) {
		
		String str="JAa";
		String str1="JKva";
		
	int x=	str.compareTo(str1);
	
	System.out.println(x);
	
	
	
	String str2="Java";
boolean flag=	str2.contains("a");

System.out.println("Does the string contains Java "+flag);


		

	}

}
