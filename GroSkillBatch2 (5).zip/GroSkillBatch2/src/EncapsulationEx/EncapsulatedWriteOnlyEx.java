package EncapsulationEx;

class Student5
{
	private int id;
	private String name;
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
}


public class EncapsulatedWriteOnlyEx {

	public static void main(String[] args) {
		
		Student5 obj=new Student5();
		obj.setId(1234);
		obj.setName("Harsh");
		

	}

}
