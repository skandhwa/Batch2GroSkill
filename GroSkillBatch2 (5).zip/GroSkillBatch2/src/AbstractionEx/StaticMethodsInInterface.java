package AbstractionEx;

interface Drawable2
{
	default void test()
	{
		System.out.println("Hello");
	}
	
	static int cube(int x)
	{
		return x*x*x;
	}
}

class C21 implements Drawable2
{
	public void test()
	{
		System.out.println("Hello world");
}
}




public class StaticMethodsInInterface {

	public static void main(String[] args) {
		
	System.out.println(Drawable2.cube(12));	
	
	Drawable2 ref=new C21();
	ref.test();
		
		

	}

}
