package AbstractionEx;






public class MarkerInterface {

	public static void main(String[] args) {
		

	}

}
