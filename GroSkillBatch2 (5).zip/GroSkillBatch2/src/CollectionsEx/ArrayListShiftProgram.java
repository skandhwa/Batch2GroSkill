package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListShiftProgram {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		ArrayList<Integer> li1=new ArrayList<Integer>();
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li.add(4);
		li.add(-3);
		li.add(2);
		li.add(7);
		li.add(-5);
		li.add(-10);
		li.add(1);
		li.add(-4);
		
		for(Integer x:li)
		{
			if(x>0)
			{
				li1.add(x);
			}
			else
			{
				li2.add(x);
				Collections.sort(li2);
				Collections.reverse(li2);
			}
		}
		
		li2.addAll(li1);
		System.out.println(li2);
		
		
		

	}

}
