package CollectionsEx;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue<Integer> q=new PriorityQueue<Integer>();
		q.add(32);
		q.add(45);
		q.add(65);
		q.add(98);
		
		System.out.println(q);
		
q.remove();
q.remove();

System.out.println(q);


		
		
	}

}
