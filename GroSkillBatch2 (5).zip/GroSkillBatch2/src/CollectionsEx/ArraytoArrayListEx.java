package CollectionsEx;

import java.util.Arrays;
import java.util.List;

public class ArraytoArrayListEx {

	public static void main(String[] args) {
		
		String []a= {"apple","banana","kiwi","melon"};
		
		List li=Arrays.asList(a);
		

	}

}
