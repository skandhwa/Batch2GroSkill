package CollectionsEx;

import java.util.ArrayList;

public class ArrayListethods4 {

	public static void main(String[] args) {
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");
		
		
ArrayList<String> li2=new ArrayList<String>();
		
		li2.add("Banana");
		li2.add("Kiwi");
		li2.add("Apple");
		li2.add("Pines");
		li2.add("Pineapple");
		
		
	boolean flag=	li.containsAll(li2);
	
	System.out.println("Does the first list contains all element of second list "+flag);

	}

}
