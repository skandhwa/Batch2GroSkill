package CollectionsEx;

import java.util.Stack;

public class StackExamples {

	public static void main(String[] args) {
		
		Stack<Integer> s=new Stack<Integer>();
		s.add(32);
		s.add(45);
		s.add(98);
		s.add(102);
		s.push(65);
		
		for(Integer x:s)
		{
			System.out.println(x);
		}
		
		s.pop();
		s.pop();
		
		System.out.println("After popping elements are");
		for(Integer x:s)
		{
			System.out.println(x);
		}
		
	int x=	s.peek();
	
	System.out.println("Element at top of stack is "+x);
		
		

	}

}
