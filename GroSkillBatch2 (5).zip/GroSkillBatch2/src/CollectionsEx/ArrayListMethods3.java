package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListMethods3 {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");
		
	boolean flag=	li.contains("Banana");
	
	System.out.println("Does the list contains banana "+flag);
	
	Collections.sort(li);
	System.out.println("After soring elements are "+li);
	
	Collections.reverse(li);
	System.out.println("After reverse soring elements are "+li);
	
	Collections.shuffle(li);
	System.out.println("After shuffling  elements are "+li);
		

	}

}
