package CollectionsEx;

import java.util.ArrayList;

public class ArrayListMethods1 {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");
		
		li.add(3, "Pineapple");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		li.set(4, "jackfruit");
		
		System.out.println("After using Set method");
		for(String x:li)
		{
			System.out.println(x);
		}
		
		li.clear();
		
		System.out.println("After clearing elemet");
		for(String x:li)
		{
			System.out.println(x);
		}
		

	}

}
