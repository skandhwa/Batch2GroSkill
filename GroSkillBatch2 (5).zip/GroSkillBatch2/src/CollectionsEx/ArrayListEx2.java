package CollectionsEx;

import java.util.ArrayList;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add(" ");
		li.add(null);
		li.add("Banana");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		
		

	}

}
