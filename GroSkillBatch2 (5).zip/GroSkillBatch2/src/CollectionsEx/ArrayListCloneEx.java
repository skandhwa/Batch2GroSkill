package CollectionsEx;

import java.util.ArrayList;

public class ArrayListCloneEx {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		ArrayList<String> cloneList=(ArrayList<String>) li.clone();
		
		System.out.println(cloneList);
		
		cloneList.removeAll(cloneList);
		System.out.println("After removing elements are  "+cloneList);
 
	}

}
