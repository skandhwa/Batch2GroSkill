package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListToArray {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");
		li.add("Kiwi");
		
		li.replaceAll(i ->i.toUpperCase());
		System.out.println(li);
		
		
	int p=	li.lastIndexOf("KIWI");
	
	System.out.println("Last index of Kiwi is "+p);
		
	String []arr=new String[li.size()];	
	
	li.toArray(arr);
	
	for(String x:li)
	{
		System.out.println(x);
		
		//Arrays.sort(arr);
		
	}
	
	
	
		

	}

}
