package CollectionsEx;

import java.util.ArrayList;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
ArrayList<String> li=new ArrayList<String>();
		
		li.add("Banana");
		li.add("Kiwi");
		li.add("Apple");
		li.add("Pines");
		li.add("Orange");

ArrayList<String> li2=new ArrayList<String>();
		
		li2.add("Brinjal");
		li2.add("Potato");
		li2.add("Onion");
		li2.add("Tomato");
		li2.add("Kiwi");
		
		
	li.addAll(li2);	
	
	System.out.println(li);
	
	
	li.retainAll(li2);
	
	System.out.println("After retaining elements are ");
	System.out.println(li);
	
	
	
	
	
			
		
		
	}

}
