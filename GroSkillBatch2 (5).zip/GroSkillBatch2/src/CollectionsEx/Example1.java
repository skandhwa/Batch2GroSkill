package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Example1 {

	public static void main(String[] args) {
		
	ArrayList<Integer> li=new ArrayList<Integer>();
	li.add(23);
	li.add(45);
	li.add(67);
	li.add(98);
	li.add(103);
	
	////Using for loop

	for(int i=0;i<li.size();i++)
	{
		System.out.println(li.get(i));
	}
	
	///for each loop
	System.out.println("Second way using for each loop");
	for(Integer x:li)
	{
		System.out.println(x);
	}
	
	//Iterator interface
	
	Iterator itr=li.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	
	
	
	
	
		

	}

}
