package Array;

public class DuplicateElementArray {

	public static void main(String[] args) {
		
		int a[]= {2,4,6,5,4,2,3,3};
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					System.out.println("Duplicate Element found "+a[i]);
				}
			}
		}
		

	}

}
