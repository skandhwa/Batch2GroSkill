package Array;

public class StringArrayEx {

	public static void main(String[] args) {
		
		
		String []a= {"Java","Selenium","Python"};
		
		for(String x:a)
		{
			System.out.println(x);
		}
		
		

	}

}
