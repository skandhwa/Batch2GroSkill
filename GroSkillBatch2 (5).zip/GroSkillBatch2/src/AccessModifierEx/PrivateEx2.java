package AccessModifierEx;

class P3
{
	private void display()
	{
		System.out.println("Hello");
		
		
	}
}



public class PrivateEx2 {

	public static void main(String[] args) {
		
		P3 obj=new P3();
		obj.display();
		
		

	}

}
