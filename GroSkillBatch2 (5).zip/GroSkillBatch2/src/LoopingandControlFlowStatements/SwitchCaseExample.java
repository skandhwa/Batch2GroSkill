package LoopingandControlFlowStatements;

public class SwitchCaseExample {

	public static void main(String[] args) {
		
		int num=10;
		
		switch(num)
		
		{
		case 50:
			System.out.println("50");
			break;
		
		case 40:
			System.out.println("40");
			break;	
			
			
		case 30:
			System.out.println("30");
			break;		
			
		case 20:
			System.out.println("20");
			break;	
			
		case 10:
			System.out.println("10");
			break;	
			
		default:
			System.out.println("No valid inputs");
		
		
		}
		

	}

}
