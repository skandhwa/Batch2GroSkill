package LoopingandControlFlowStatements;

public class ifElseStatement {

	public static void main(String[] args) {
		
		int a=200;
		int b=40;
		
		if(a>b)
		{
			System.out.println("Maximum is a");
		}
		else
		{
			System.out.println("Maximum is b");
		}
		
		

	}

}
