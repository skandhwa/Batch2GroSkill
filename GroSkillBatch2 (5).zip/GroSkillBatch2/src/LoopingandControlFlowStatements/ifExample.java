package LoopingandControlFlowStatements;

public class ifExample {

	public static void main(String[] args) {
		
		int age=18;
		char status='A';
		char idCardStatus='A';
		
		if(age>=18 && age<65)
		{
			if(status=='A')
			{
				if(idCardStatus=='A')
				{
					System.out.println("You are elligible to vote");
				}
			}
		}
		
		
		

	}

}
