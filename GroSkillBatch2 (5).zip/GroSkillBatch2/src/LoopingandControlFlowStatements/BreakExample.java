package LoopingandControlFlowStatements;

public class BreakExample {

	public static void main(String[] args) {
		
		for(int i=1;i<=10;i++)//i=1,1<=10...i=2,,2<=10...
		{
			if(i==5)
			{
				continue;
			}
			System.out.println(i);//1///2
		}
		
		

	}

}
