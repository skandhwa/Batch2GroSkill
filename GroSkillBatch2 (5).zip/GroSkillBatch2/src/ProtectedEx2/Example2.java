package ProtectedEx2;

import ProtectedEx1.PrExample1;

public class Example2 extends PrExample1 {

	public static void main(String[] args) {
		
		Example2 obj=new Example2();
		obj.display();
		

	}

}
