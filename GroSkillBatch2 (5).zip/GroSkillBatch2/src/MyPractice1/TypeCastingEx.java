package MyPractice1;

public class TypeCastingEx {

	public static void main(String[] args) {
		
		int x=10;
		long y=x;
		
		float z=y;
		
		
		long p=1443343L;
		int q=(int) p;
		
		System.out.println(q);
		
		
		
		
		

	}

}
