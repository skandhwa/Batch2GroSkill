package MyPractice1;

public class MyTest1 {

	public static void main(String[] a) {
		
		System.out.println("Hello");
		
		
		boolean flag=true;///1 bit
		
		byte x=-120;
		
		short y=21321;
		
		int k=231232311;
		
		long w=3243243232443452L;
		
		float p=23323231232131232432434233213.345435342434324343f;
		
		double q=32444444444444444444444545646456456546654654656546546546546564444444.343244444444444323423;
		
         char m='1';
	}

}
