package MyPractice1;

class T1
{
	int a=10;
	
	
	void display()
	{
		System.out.println("Hello");
		int b= a+20;
		System.out.println(b);
		
		
	}
	
	void test()
	{
		System.out.println("Hi");
		int c=a+40;
		int d= c+b+50;
		System.out.println(c);
		
	}
}


public class VariableExample {

	public static void main(String[] args) {
		
		T1 obj=new T1();
		
		obj.display();
		
		
		
		
		
		
		
		

	}

}
