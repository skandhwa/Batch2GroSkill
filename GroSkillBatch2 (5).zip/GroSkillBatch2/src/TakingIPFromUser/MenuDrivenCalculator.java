package TakingIPFromUser;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		
		char operator;
		double num1,num2,result;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an Operator");
		
		operator=sc.next().charAt(0);
		
		
		
		System.out.println("Enter the first number");
		
		num1=sc.nextDouble();
		
System.out.println("Enter the Second number");
		
		num2=sc.nextDouble();
		
		switch(operator)
		{
		case '+':
			result=num1+num2;
			System.out.println("The sum of numbers are "+result);
			break;
		
		case '-':
			result=num1-num2;
			System.out.println("The difference of numbers are "+result);
			break;
			
		case '*':
			result=num1*num2;
			System.out.println("The product of numbers are "+result);
			break;
		
		case '/':
			result=num1/num2;
			System.out.println("The division of numbers are "+result);
			break;
			
		default:
			System.out.println("You have entered an invalid input ");
		
		
		}
		
		
		sc.close();

	}

}
