package TestNgDemo;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgPriorityEx {
	
	@Test(priority='a')
	public void display7()
	{
		System.out.println("P 97");//3
		Reporter.log("This test is executed By Saurabh");
	}
	
	@Test(priority='A')
	public void display8()
	{
		System.out.println("P 65");//3
	}
	
	
	
	@Test(priority=0)
	public void display()
	{
		System.out.println("P 0");//3
	}
	
	
	@Test(priority=6)
	public void Bdisplay()
	{
		System.out.println("P 6 Bdis");//5
	}
	
	
	@Test(priority=-5)
	public void display2()
	{
		System.out.println("P -5");//1
	}
	
	@Test
	public void display3()
	{
		System.out.println("No Pr");//4
	}
	
	@Test(priority=-3)
	public void display4()
	{
		System.out.println("P -4");//2
	}
	
	@Test(priority=6)
	public void Adisplay()
	{
		System.out.println("P 6 ADis");//5
	}
	
	
	
	
	
	
	

}
