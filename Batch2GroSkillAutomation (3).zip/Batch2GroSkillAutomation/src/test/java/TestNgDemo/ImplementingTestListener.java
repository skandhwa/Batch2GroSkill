package TestNgDemo;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(UsingITestListener.class)

public class ImplementingTestListener {
	
	@Test(timeOut=5000)
	public void openGoogle() throws InterruptedException
	{
		DriverInitialization.initializeDriver().get("https://www.google.com");
		Thread.sleep(10000);
		String title=DriverInitialization.initializeDriver().getTitle();
		System.out.println("Title of webPage is  "+title);
	}
	
	
	
	
	

}
