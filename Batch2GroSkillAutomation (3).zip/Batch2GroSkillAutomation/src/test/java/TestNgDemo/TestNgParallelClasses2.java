package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgParallelClasses2 {
	
	@Test
	public void test2()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
	String title=	driver.getTitle();
	System.out.println("Title of page is  "+title);
	
	}

}
