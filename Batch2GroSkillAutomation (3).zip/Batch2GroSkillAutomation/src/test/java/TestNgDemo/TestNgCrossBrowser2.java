package TestNgDemo;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgCrossBrowser2 {
	
	@Parameters("browser")
	@Test
	public void display()
	{
		TestNgCrossBrowserEx.driver.get("https://www.flipkart.com");
		
	}
	
	

}
