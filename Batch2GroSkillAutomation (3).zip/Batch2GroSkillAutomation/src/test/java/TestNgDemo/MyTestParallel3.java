package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MyTestParallel3 {
	
	 WebDriver driver;

	    @BeforeMethod
	    public void setup() {
	        
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	    }

	    @Test
	    public void testBing() {
	        driver.get("https://www.bing.com");
	        System.out.println("Test3 - Title: " + driver.getTitle());
	    }

	    @AfterMethod
	    public void teardown() throws InterruptedException {
	    	
	    	Thread.sleep(4000);
	        driver.quit();
	
	

}
}
