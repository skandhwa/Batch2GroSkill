package TestNgDemo;

import org.testng.annotations.Test;

public class MyFirstTest {
	
	@Test
	public void display()
	{
		System.out.println("Hello"); 
	}
	
	

}
