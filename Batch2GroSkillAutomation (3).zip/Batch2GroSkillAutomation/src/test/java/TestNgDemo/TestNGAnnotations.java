package TestNgDemo;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGAnnotations {
	
	@AfterTest
	public void test1()
	{
		System.out.println("I am after Test ");//5
	}
	
	@BeforeTest
	public void test2()
	{
		System.out.println("I am before Test ");//1
	}
	
	@AfterSuite
	public void test3()
	{
		System.out.println("I am after suite ");//6
	}
	
	@BeforeMethod
	public void test4()
	{
		System.out.println("I am before method ");///3
	}
	
	@Test
	public void test5()
	{
		System.out.println("I am Test method ");//4
	}
	
	@BeforeClass
	public void test6()
	{
		System.out.println("I am Before class ");//2
	}
	
	

}
