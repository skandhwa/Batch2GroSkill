package TestNgDemo;

import org.testng.annotations.Test;

public class MultiDependsOn {
	
	@Test
	public void login()
	{
		int x=9/0;
		System.out.println(x );
		System.out.println("Login Successfull");
	}
	
	@Test(dependsOnMethods= {"login"})
	public void searchProduct()
	{
		System.out.println("Product search successfull");
	}
	
	
	@Test(dependsOnMethods= {"login","searchProduct"},alwaysRun=true)
	public void addtoCart()
	{
		System.out.println("Product added to cart");
	}
	
	@Test(dependsOnMethods= {"login","searchProduct","addtoCart"})
	public void paymentProcess()
	{
		System.out.println("Payment successfull");
	}
	
	
	
	@Test
	public void closeBrowser()
	{
		System.out.println("Browser closed");
	}
	
	
	

}
