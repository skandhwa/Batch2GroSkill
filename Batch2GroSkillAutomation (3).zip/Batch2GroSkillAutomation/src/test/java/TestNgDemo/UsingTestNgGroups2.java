package TestNgDemo;

import org.testng.annotations.Test;

public class UsingTestNgGroups2 {
	
	@Test(groups= {"regression"})
	public void test5()
	{
		System.out.println("This is reg test case 5");
	}
	
	@Test(groups= {"regression"})
	public void test6()
	{
		System.out.println("This is reg test case 6");
	}
	
	@Test(groups= {"sanity"})
	public void test7()
	{
		System.out.println("This is sanity test case 7");
	}
	
	@Test(groups= {"sanity"})
	public void test8()
	{
		System.out.println("This is sanity test case 8");
	}
	
	
	
	

}
