package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class UsingRetryAnalyzer {
	
	@Test(retryAnalyzer=TestNgDemo.TestNgRetryExecutionEx.class)
	public void display()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		System.out.println("Tite of web page is  "+title);
		Assert.assertEquals("Google123",title);
		
		
	}
	

}
