package TestNgDemo;

import org.testng.annotations.Test;

public class UsingTestNgGroups {
	
	@Test(groups= {"regression"})
	public void test1()
	{
		System.out.println("This is reg test case 1");
	}
	
	@Test(groups= {"regression"})
	public void test2()
	{
		System.out.println("This is reg test case 2");
	}
	
	@Test(groups= {"sanity"})
	public void test3()
	{
		System.out.println("This is sanity test case 3");
	}
	
	@Test(groups= {"sanity"})
	public void test4()
	{
		System.out.println("This is sanity test case 4");
	}
	

}
