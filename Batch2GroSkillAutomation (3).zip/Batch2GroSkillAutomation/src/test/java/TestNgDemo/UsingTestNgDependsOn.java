package TestNgDemo;

import org.testng.annotations.Test;

public class UsingTestNgDependsOn {
	
	@Test
	public void test1()
	{
		int x=9/0;
		System.out.println(x);
	}
	
	@Test(dependsOnMethods= {"test1"})
	public void test2()
	{
		System.out.println("Hi Java is intresting");
	}
	

}
