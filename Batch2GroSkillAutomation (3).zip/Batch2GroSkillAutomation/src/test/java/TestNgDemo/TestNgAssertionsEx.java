package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class TestNgAssertionsEx {
	
	@Test
	public void test()
	{
//		WebDriver driver=new ChromeDriver();
//		driver.get("https://www.google.com");
//		String Actual_Title="Google1";
//	String Expected_Title=	driver.getTitle();
	//Assert.assertEquals(Actual_Title, Expected_Title);
	//Assert.assertNotEquals(Actual_Title, Expected_Title);
	Assert.assertFalse(8==7);
	
	
	
	
	int a=10;
	int b=20;
	int c=a+b;
	
	System.out.println("sum is  "+c);
			
	
	
	
	}
	
	

}
