package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGParallelClasses3 {
	
	@Test
	public void test()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
	String title=	driver.getTitle();
	System.out.println("Title of page is  "+title);
	
	}

}
