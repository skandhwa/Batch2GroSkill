package TestNgDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDPEx1 {
	
	WebDriver driver;
	@DataProvider(name="DP1")
	public Object [][] m1()
	{
          return new Object [][]
        
        		  { {"Java"} ,{"Selenium"},{"TestNg"}
        		  
	
	};
	}
	
	@Test(dataProvider="DP1")
	
	public void searchValues(String v1) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
		ele.sendKeys(v1);
		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).click();
		Thread.sleep(5000)
	;
		driver.close();
		}
	
	
	

}
