package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNgParallelExecution {
	
	private ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    @BeforeMethod
    public void setup() {
        driver.set(new ChromeDriver());  // Initialize WebDriver for each test thread
    }

    @Test
    public void google() {
        driver.get().get("https://www.google.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }

    @Test
    public void flipkart() {
        driver.get().get("https://www.flipkart.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }

    @Test
    public void instagram() {
        driver.get().get("https://www.instagram.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }
    
    @Test
    public void facebook() {
        driver.get().get("https://www.facebook.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }
    
    @Test
    public void amazon() {
        driver.get().get("https://www.amazon.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }
   
    
    @Test
    public void twitter() {
        driver.get().get("https://www.twitter.com");
        String title = driver.get().getTitle();
        System.out.println("Title of webpage is: " + title);
    }
    
    
    
    @AfterTest
    public void tearDown() {
        if (driver.get() != null) {
            driver.get().quit();  // Close browser after test execution
            driver.remove();      // Remove driver instance
        }
	
	

}
}
