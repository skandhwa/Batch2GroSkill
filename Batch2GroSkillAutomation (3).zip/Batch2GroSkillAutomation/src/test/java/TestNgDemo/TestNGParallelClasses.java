package TestNgDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNGParallelClasses {
	
	@Test
	public void test()
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.google.com");
	String title=	driver.getTitle();
	System.out.println("Title of page is  "+title);
	
	}
	

}
