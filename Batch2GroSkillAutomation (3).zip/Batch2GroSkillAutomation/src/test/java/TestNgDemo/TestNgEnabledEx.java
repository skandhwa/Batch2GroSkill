package TestNgDemo;

import org.testng.annotations.Test;

public class TestNgEnabledEx {
	
	@Test
	public void display1()
	{
		System.out.println("Hello");
	}
	
	@Test(alwaysRun=true,enabled=false)
	public void test1()
	{
		System.out.println("Hi");
	}
	
	
	
	

}
