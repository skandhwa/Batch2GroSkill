package ActionClassEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ClickElement {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver  driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	WebElement ele1=	driver.findElement(By.xpath("//textarea[@rows=3]"));
		
	
	
		
		
		Actions act=new Actions (driver);
		
	WebElement ele=	driver.findElement(By.xpath("//input[@value='Male']"));
		Thread.sleep(3000);
	act.moveToElement(ele).click().perform();
	
	act.doubleClick(ele1).perform();
	
	Thread.sleep(3000);
	
	WebElement ele2=driver.findElement(By.xpath("//input[@placeholder='First Name']"));
	act.contextClick(ele2).perform();
		
		

	}

}
