package TakingScreenShotEx;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TakingScreenShotEx {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		
		TakesScreenshot srcShot=(TakesScreenshot)driver;
		File srcFile=srcShot.getScreenshotAs(OutputType.FILE);
		File destFile=new File("C:\\Users\\saura\\OneDrive\\Pictures\\MyScreenshot1\\Mypic.jpeg");
		FileUtils.copyFile(srcFile, destFile);
		
		
		
		
		
		
		
		
		

	}

}
