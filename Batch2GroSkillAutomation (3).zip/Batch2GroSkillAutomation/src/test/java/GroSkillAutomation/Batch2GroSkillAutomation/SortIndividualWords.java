package GroSkillAutomation.Batch2GroSkillAutomation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortIndividualWords {

	public static void main(String[] args) {
		
		String str="I love Java";
		str=str.toLowerCase();
		
		String []s=str.split(" ");
		
		StringBuilder sb=new StringBuilder();
		
		for(String x:s)
		{
			List<Character> li=new ArrayList<Character>();
			for(Character y:x.toCharArray())
			{
				
				li.add(y);
			}
			
			Collections.sort(li);
			
			StringBuilder word=new StringBuilder();
			for(Character z:li)
			{
				word.append(z);
			}
			sb=sb.append(word).append(" ");
			
			
			
			
		}
		
		System.out.println(sb.toString());
		
		
		
		

	}

}
