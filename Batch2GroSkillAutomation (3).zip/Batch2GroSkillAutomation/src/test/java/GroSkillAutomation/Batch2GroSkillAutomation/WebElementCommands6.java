package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands6 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		Thread.sleep(3000);
WebElement ele=		driver.findElement(By.xpath("//input[@id='name']"));
		
	String Attribute=	ele.getAttribute("placeholder");
	
	System.out.println("Attribute value is "+Attribute);

	}

}
