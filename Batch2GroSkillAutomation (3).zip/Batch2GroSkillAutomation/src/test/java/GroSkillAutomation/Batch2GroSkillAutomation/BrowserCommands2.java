package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands2 {

	public static void main(String[] args) throws InterruptedException {
		
		
		///  https://demo.automationtesting.in/Alerts.html
		
		WebDriver dr=new ChromeDriver();
		dr.get("https://demo.automationtesting.in/Windows.html");
		dr.manage().window().maximize();
		Thread.sleep(3000);
		dr.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
		Thread.sleep(3000);
		//dr.close();
		
		dr.quit();
		
		dr.getTitle();
		
		
		
		
		

	}

}
