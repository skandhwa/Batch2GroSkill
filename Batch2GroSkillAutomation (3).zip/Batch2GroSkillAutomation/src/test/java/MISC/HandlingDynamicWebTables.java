package MISC;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTables {

	public static void main(String[] args) {
		
//		System.out.println("Enter the name you want to select");
//		Scanner sc=new Scanner(System.in);
		//String str=sc.nextLine();
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C://Users//saura//Downloads//WebTable.html");
		
		
		
		
//		String before_xpath="//table/tbody/tr[";
//		String after_xpath="]/td[2]";
//		
//		String before_ch1="//table/tbody/tr[";
//		String after_ch1="]/td[1]/input";
//		
//		
//		List<WebElement> li=driver.findElements(By.xpath("//table/tbody/tr"));
//		int x=li.size();
//		System.out.println("Total number of rows are  "+li.size());
//		
//		
//		
//		for(int i=2;i<=x;i++)
//		{
//		String firstname=	driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText();
//		System.out.println(firstname);
//		
//		if(firstname.contains(str))
//		{
//			driver.findElement(By.xpath(before_ch1+i+after_ch1)).click();
//		}
//		
//		}
//		
//		
		////Using Xpath Axes
		
		driver.findElement(By.xpath("//td[text()='Will']//parent::td//preceding-sibling::td//input[@type='checkbox']")).click();
		
		

	}

}
