package MISC;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RobotClassEx {

	public static void main(String[] args) throws AWTException, InterruptedException {
		
		WebDriver driver=new ChromeDriver();
	driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		
		
		Robot rb=new Robot();
		
		Thread.sleep(3000);
		
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);
		
		Thread.sleep(3000);
		
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		rb.keyPress(KeyEvent.VK_UP);
		Thread.sleep(3000);
		
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.mouseWheel(4000);
		rb.mouseMove(20, 1000);
		

	}

}
