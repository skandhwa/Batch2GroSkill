package MISC;

public class CapitalizeString {

	public static void main(String[] args) {
		
		String str="i love java";
		StringBuilder sb=new StringBuilder();
		String []s1=str.split(" ");
		for(String x:s1)
		{
			sb.append(Character.toUpperCase(x.charAt(0))).append(x.substring(1)).append(" ");
		}
		
		System.out.println(sb.toString());
		
		
		
		
		

	}

}
