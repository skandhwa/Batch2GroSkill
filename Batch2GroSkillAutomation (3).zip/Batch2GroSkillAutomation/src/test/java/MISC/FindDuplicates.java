package MISC;

import java.util.HashSet;

public class FindDuplicates {

	public static void main(String[] args) {
		
		String str="Programming";
		
		str=str.toLowerCase();
		
		HashSet<Character> s1=new HashSet<Character>();
		HashSet<Character> s2=new HashSet<Character>();
		
		char []ch=str.toCharArray();
		
		for(Character x:ch)
		{
			if(s1.contains(x))
			{
				s2.add(x);
			}
			else
			{
				s1.add(x);
			}
		}
		
		for(Character y:s2)
		{
			System.out.println(y);
		}
		
		
		

	}

}
