package MISC;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.v127.network.model.Cookie;
import org.openqa.selenium.remote.DesiredCapabilities;

public class UsingChromeOptionsEx {

	public static void main(String[] args) {
//		
//		DesiredCapabilities cap=new DesiredCapabilities();
//		cap.setCapability("Key", "value");
//		
//		UIAutomator2Options opt=new UIAutomator2Options();
//		opt.setDeviceName("");
//		opt.setPlatformName("");
//		opt.platformVersion("");
		
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("start-maximized");
		opt.addArguments("incognito");
		opt.addArguments("disable-popup-blocking");
		opt.addArguments("version");
		opt.addArguments("--headless");
		
		
		WebDriver driver=new ChromeDriver(opt);
		driver.get("https://www.google.com");
	String title=	driver.getTitle();
	System.out.println("Title of web page is "+title);
	driver.manage().getCookieNamed("").getName();
	//driver.manage().addCookie(new Cookie("key", "value");
	
		
		
		
		

	}

}
