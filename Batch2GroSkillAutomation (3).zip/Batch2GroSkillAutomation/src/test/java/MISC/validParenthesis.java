package MISC;

import java.util.Stack;

class T4
{
	public static boolean isValid(String str)
	{
		char []s1=str.toCharArray();
		Stack<Character> stk=new Stack<Character>();
		for(int i=0;i<s1.length;i++)
		{
			if(s1[i]=='(' || s1[i]=='{' || s1[i]=='[')
			{
				stk.push(s1[i]);
			}
			
			else if(s1[i]==')' || s1[i]=='}' || s1[i]==']')
			{
				if(stk.isEmpty())
				{
					return false;
				}
				char top=stk.pop();
				if(s1[i]==')' && top!='(' || s1[i]=='}' && top!='{' || s1[i]==']'&& top!='['    )
				{
					return false;
				}
				
				
			}
		}
		
		return stk.isEmpty();
		
	}
}



public class validParenthesis {

	public static void main(String[] args) {
		
		String str="([)]";
		
		System.out.println(T4.isValid(str));
		
		
		

	}

}
