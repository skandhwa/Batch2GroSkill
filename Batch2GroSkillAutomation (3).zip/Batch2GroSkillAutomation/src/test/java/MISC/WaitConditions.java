package MISC;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitConditions {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//select[@id='continents']"));
		
	WebElement ele=	new WebDriverWait
			(driver,Duration.ofSeconds(5)).
			until(ExpectedConditions.
					elementToBeClickable
					(By.xpath("//select[@id='continents']"))
					
					
					
					);
	
	
	FluentWait wait=new FluentWait(driver);
	wait.withTimeout(Duration.ofSeconds(10));
	wait.pollingEvery(Duration.ofSeconds(2));
	wait.until(ExpectedConditions.elementToBeClickable(ele));
	wait.ignoring(NoSuchElementException.class);
	
	
	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		

	}

}
