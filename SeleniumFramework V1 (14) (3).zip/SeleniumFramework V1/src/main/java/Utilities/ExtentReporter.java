package Utilities;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReporter {
	/*public ExtentLoggerReporter logger;
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent;
	
	public void report(){
		Properties ppty=new Properties();
		ClassLoader basedir=this.getClass().getClassLoader();
		String htmlReport=ppty.getProperty("extent.reporter.html.out");
		String logReport=ppty.getProperty("extent.reporter.logger.out");
		htmlReporter = new ExtentHtmlReporter(htmlReport);
		logger = new ExtentLoggerReporter(logReport);
		extent = new ExtentReports();
		htmlReporter.config().setAutoCreateRelativePathMedia(true);
		htmlReporter.loadXMLConfig(basedir.getResource("logger-config.xml").getPath());
		extent.attachReporter(htmlReporter);
		extent.attachReporter(logger);
	}*/
}


