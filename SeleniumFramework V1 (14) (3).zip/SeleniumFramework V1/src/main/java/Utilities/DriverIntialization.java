
package Utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import Constants.Constants;
import io.cucumber.java.Scenario;
//import cucumber.api.Scenario;
//import cucumber.api.Scenario;

public class DriverIntialization {
	public static WebDriver driver;
	public static Properties ppty;
	public static Logger logger;
	//logger = LogManager.getLogger();
	public static Scenario messageHandler;
	public static ThreadLocal<WebDriver> TLdriver = new ThreadLocal<WebDriver>();

	public void intializeDriver(String drivernm) throws Exception {
		setWebDriver(driver, drivernm);
		System.out.println("initialise function");
	}

	public WebDriver setWebDriver(WebDriver driver, String drivernm) throws Exception {
		// Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		CommonFunctions.loadClassLoader();
	
		logger = LogManager.getLogger(DriverIntialization.class.getName());
		//logger = Logger.getLogger(DriverIntialization.class.getName());
		ppty = CommonFunctions.getObjDetails();
		drivernm = drivernm.toUpperCase();
		System.out.println("Browser: " + drivernm + " selected for execution");

		switch (drivernm) {

		case "CHROME":
			System.out.println("chrome case...");
			System.out.println("chrome path "+WebDriverManager.chromedriver().getDownloadedDriverPath());
			WebDriverManager.chromedriver().setup();
			
			//TLdriver.set(new ChromeDriver()); // Commented By Tarik
			
			//Added By Tarik
			//Create instance of ChromeOptions Class
			ChromeOptions handlingSSL = new ChromeOptions();
			//Using the accept insecure cert method with true as parameter to accept the untrusted certificate
			handlingSSL.setAcceptInsecureCerts(true);
			//Added By Tarik --
			
			TLdriver.set(new ChromeDriver(handlingSSL)); //Added By Tarik
		
			
			// driver = new ChromeDriver();
			// driver.get(ppty.getProperty("QA_url")); '
			break;

		case "IE":
			WebDriverManager.iedriver().setup();
			TLdriver.set(new InternetExplorerDriver());
			// driver.get(ppty.getProperty("QA_url"));
			break;

		case "FIREFOX":
			WebDriverManager.firefoxdriver().setup();
			TLdriver.set(new FirefoxDriver());
			// driver.get(ppty.getProperty("QA_url"));
			// FirefoxOptions firefoxOptions=new FirefoxOptions();
			break;

		default:
			throw new Exception("Driver " + drivernm + " Not Defined");
		}
		// TLdriver.set(driver);
		maximiseWindow();
		setUpImplicitWait();
		return getDriver();
	}

	public static WebDriver getDriver() {
		return TLdriver.get();
	}

	public void setUpImplicitWait() {

		getDriver().manage().timeouts().implicitlyWait(Constants.IMPLICITWAIT, TimeUnit.SECONDS);
	}

	public void maximiseWindow() {

		getDriver().manage().window().maximize();
	}
}

/*
 ** ==========~~~~~~~~~~==========~~~~~~~~~~==========~~~~~~~~~~==========
 ** Copyright (C) 2008-2019 Schlumberger,- All Rights Reserved Unauthorized
 * copying of this file, via any medium is strictly prohibited Proprietary and
 * confidential
 ** ==========~~~~~~~~~~==========~~~~~~~~~~==========~~~~~~~~~~==========
 */