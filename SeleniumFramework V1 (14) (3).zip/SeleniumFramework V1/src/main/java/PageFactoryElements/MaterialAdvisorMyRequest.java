package PageFactoryElements;
/**
 * @author Ethesh Gaur
 * page class for My Request Page
 * 
 */

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;

public class MaterialAdvisorMyRequest extends CommonFunctions {
	
	
	public MaterialAdvisorMyRequest(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	@FindBy (xpath="//input[@id='keyword']")
	WebElement searchResult;
	@FindBy (xpath="//div[@id='materialTypeId']")
	WebElement materialType;
	@FindBy (xpath="//div[@id='type']")
	WebElement requestType; 
	@FindBy (xpath="//input[@id='createdByUserId']")
	WebElement requester;
	@FindBy (xpath="//div[@id='isSmeValidation']")
	WebElement SMETest; 
	@FindBy (xpath="//button[contains(text(),'Clear All')]")
	WebElement clearAll;
	@FindBy (xpath="//a[contains(text(),'Create Request')]")
	WebElement createRequestBtn;
	@FindBy (xpath="//h2[contains(text(),'Notice')]")
	WebElement noticePopUp;
	@FindBy (xpath="//span[contains(text(),'Date')]")
	WebElement dateSort;
	@FindBy (xpath="//div[contains(text(),'Create Request')]")
	WebElement createRequestPage;
	@FindBy (xpath="//div[contains(text(),'Edit Request')]")
	WebElement editRequestPage;
	@FindBy (xpath="//input[@id='name']")
	WebElement requestName;
	@FindBy (xpath="//span[contains(text(), 'SME Validation')]")
	WebElement smeValidation;
	@FindBy (xpath="//input[@id='productLine']")
	WebElement productLine;
	@FindBy (xpath= "//div[@id='applicationName']")
	WebElement productApplication;
	@FindBy (xpath="//label[contains(text(),'Proposed Metallurgy*')]")
	WebElement proposedMetallurgy;
	@FindBy (xpath="//label[contains(text(),'Yield Strength,Min*')]")
	WebElement yieldStrength;
	@FindBy (xpath="//input[@id='elastomerFamily']")
	WebElement elastomerFamily;
	@FindBy (xpath="//input[@id='proposedMaterialDescription']")
	WebElement proposedMaterialDescription;
	@FindBy (xpath = "//*[name()='svg' and @role='img' and @class='svg-inline--fa fa-rotate-right icon-enabled']")
	WebElement resetButton;
	@FindBy (xpath = "//*[name()='svg' and @role='img' and @class='svg-inline--fa fa-pen-to-square icon-enabled']")
	WebElement editButton;
	@FindBy (xpath="//h2[@id='confirmation-dialog-title']")
	WebElement resetPopup;
	@FindBy(xpath="//button[contains(text(),'Ok')]")
	WebElement okButton;
	@FindBy(xpath="//div[contains(text(),'Ethesh is Reset')]")
	WebElement resetVerified;
	@FindBy(xpath="//button[text()='Next']")
	WebElement nextBtn;
	@FindBy(xpath="//a[contains(text(),'Specifications')][1]")
	List<WebElement> specificationBtn;
	@FindBy(xpath="//a[contains(text(),'Environment Data')][1]")
	List<WebElement> EnvironmentData;
	
	//function of elements

	public void searchResult(String text) throws InterruptedException, AWTException {

		CommonFunctions.waitVisibilityofElement(searchResult);
        
		searchResult.click();
		CommonFunctions.deleteText(searchResult);
        Thread.sleep(1000);
        searchResult.sendKeys(text);
		Thread.sleep(2000);
	}
	
   public void EnvironmentData() {
	 
	try {EnvironmentData.get(1).click();}
	catch (Exception e) {
		EnvironmentData.get(0).click();
	}
	}
	
	public void clickElastomerFamily() {
		
		elastomerFamily.click();
	}
	
	public void clickProposedMaterialDescription() {
		
		proposedMaterialDescription.click();
	}
	
	public void clicknextBtn() {
		CommonFunctions.waitVisibilityofElement(nextBtn);
		CommonFunctions.clickBySelenium(nextBtn);
	}
	
	public void resetVerified() throws InterruptedException {
		
		CommonFunctions.waitVisibilityofElement(resetVerified);
		if(resetVerified.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
	}

	public void okButton() {

		CommonFunctions.clickBySelenium(okButton);
	}

	public void verifyProdApp(List<Map<String, String>> dt) throws InterruptedException {

		
		for (Map<String, String> dataRow : dt) {
			productApplication.click(); 
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", (dataRow.get("Application"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()){
				Assert.assertTrue(true);
				ele.click();
			}else {
				Assert.assertTrue(false);
			}
		}

	}

	public void editButton() throws InterruptedException {
		Thread.sleep(2000);
		CommonFunctions.clickBySelenium(editButton);
	}
	
	public void elastomerTab() {
		By locator = By.xpath(String.format("//h5[contains(text(),'Elastomer')]"));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}
	
	public void clickSpecification() {
		
		CommonFunctions.waitVisibilityofElement(specificationBtn.get(1));
		specificationBtn.get(1).click();
	}

	public void resetpopup(String resetPopUpmessage) {
		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", resetPopUpmessage));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(resetPopup.isDisplayed() && el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void resetandeditbuttonEnable() {

		if(!resetButton.isEnabled() && editButton.isEnabled() ) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void clickResetButton() throws InterruptedException {

		CommonFunctions.clickBySelenium(resetButton);
		Thread.sleep(2000);
	}

	public void propossedMetaAndYieldStrength() {

		CommonFunctions.waitVisibilityofElement(proposedMetallurgy);
		if(proposedMetallurgy.isDisplayed() && yieldStrength.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void elastomerfamilyanddescription() {

		CommonFunctions.waitVisibilityofElement(elastomerFamily);
		if(elastomerFamily.isDisplayed() && proposedMaterialDescription.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void productLine() {

		productLine.click();
	}

	public void productApplication(String  name) {

		productApplication.click(); 
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", name));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void clickSMEVal() {

		smeValidation.click();
	}

	public void requestName(String name) throws InterruptedException, AWTException {
		Robot rb = new Robot();
		
		requestName.click();
		Thread.sleep(2000);
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_A);
		rb.keyRelease(KeyEvent.VK_A); 
		rb.keyRelease(KeyEvent.VK_CONTROL);
		requestName.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(1000);
		requestName.sendKeys(name);
	}

	public void reqAndMatType(String reqMatType) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", reqMatType));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void noteVerify(String note) {

		By locator = By.xpath(String.format("//div/strong[normalize-space(following-sibling::text()[1])='%s']", note));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void createRequestPage() {

		CommonFunctions.waitVisibilityofElement(createRequestPage);
		if(createRequestPage.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	public void editRequestPage() {

		CommonFunctions.waitVisibilityofElement(editRequestPage);
		if(editRequestPage.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void noticePopUp() {
		CommonFunctions.waitVisibilityofElement(noticePopUp);
		if(noticePopUp.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void dateSort() {

		CommonFunctions.waitVisibilityofElement(dateSort);
		dateSort.click();
	}

	public void createRequestBtn() {

		CommonFunctions.waitVisibilityofElement(createRequestBtn);
		createRequestBtn.click();
	}

	public void clickMaterialType() {

		materialType.click();
	}

	public void requestType() {

		requestType.click();
	}

	public void SMETest() {

		SMETest.click();
	}

	public void requester(String name) throws InterruptedException {

		requester.clear();
		Thread.sleep(2000);
		requester.sendKeys(name);

		requester.sendKeys(Keys.DOWN);
		requester.sendKeys(Keys.RETURN);
	}

	public void clearAll() {

		clearAll.click();
	}


	public void regularOrSMEVal(String name) throws InterruptedException {

		By locator = By.xpath(String.format("//button[contains(text(),'%s')]", name));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void verifyResult(String name) throws InterruptedException {

		By locator = By.xpath(String.format("//div[@class='MuiGrid-root css-rfnosa']/text()[normalize-space()='%s']/preceding-sibling::a[1] | //div[contains(text(),'%s')]", name, name));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		String text = el.getText();
		if(el.isDisplayed() || text.equalsIgnoreCase(name)) {
			Assert.assertTrue(true); 
		}else {
			Assert.assertTrue(false);
		}
	}	
	
	public void verifyDeletedRequest(String name) throws InterruptedException {
    
		try {
		By locator = By.xpath(String.format("//div[@class='MuiGrid-root css-rfnosa']/text()[normalize-space()='%s']/preceding-sibling::a[1] | //td[contains(text(),'%s')]", name, name));
		CommonFunctions.expWaitElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		String text = el.getText();
		el.isDisplayed(); 
        text.equalsIgnoreCase(name);
            Assert.assertTrue(false);
		} catch(Exception e) {
			Assert.assertTrue(true);
			 
		}
	}
	
	public void selectOption(String name) throws InterruptedException {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		Thread.sleep(2000);

	}

}
