package PageFactoryElements;
/**
 *@author Ethesh Gaur 
 **/

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Base64;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.MyTestResults;

public class MaterialAdvisorLoginPage extends CommonFunctions{

	static MyTestResults results = new MyTestResults();

	public static WebDriver driver;

	@FindBy(xpath="//input[@name='loginfmt']")
	WebElement emailEle;
	@FindBy(xpath="//input[@name ='passwd' or @name='Password']")
	WebElement passEle;
	@FindBy(xpath ="//input[@value ='Next']")
	WebElement nextBtnEle;
	@FindBy(xpath="//input[@id='submitButton' or @id='idSIButton9']")
	WebElement signInBtn;
	@FindBy(xpath="//input[@id='idSIButton9' or @id='signInButton']")
	WebElement signInVer;
	@FindBy(xpath="//div[contains(text(),'Approve a request on my Microsoft Authenticator app')]")
	WebElement auth;
	@FindBy(xpath="//input[@value='Yes']")
	WebElement yes;
	@FindBy(xpath="//div[@id='productLine']")
	WebElement productline;
	@FindBy(xpath="//input[@id='verificationCodeInput']")
	WebElement verCode;
	@FindBy(xpath="//input[@id='idSIButton9']")
	WebElement yesBtn;
	@FindBy(xpath="//button[contains(text(),'Material Selection & Validation')]")
	WebElement matSelVal;
	@FindBy(xpath="//h3[contains(text(),'No applications are available')]")
	WebElement noApps;
	@FindBy(xpath="//button[contains(text(),'Accept')]")
	WebElement acceptBtn;
	
	public MaterialAdvisorLoginPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	
    public void noApps() {
		
		
    	if(noApps.isDisplayed()) {
    		Assert.assertTrue(true);
		}else {
		}	
    	
	}
	
	

	
	public void addEmail(String email) throws InterruptedException {

		emailEle.sendKeys(email);

	}
	
   public void acceptBtn() {
		
		CommonFunctions.waitVisibilityofElement(acceptBtn);
		acceptBtn.click();
	}
	
	public void matSelVal() {
		
		CommonFunctions.waitVisibilityofElement(matSelVal);
		matSelVal.click();
	}

	public void selectApp(String apps) throws InterruptedException {
	 
		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", apps));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		CommonFunctions.clickBySelenium(el);
		
	}
	
	public void selectAppDisplayed(String apps) throws InterruptedException {
		 
		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", apps));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
		}
		
	}
	
	public void setVerCode(String code) throws InterruptedException
	{
		//verCode.clear();
		//verCode.sendKeys(code);
		Thread.sleep(2000);
		CommonFunctions.clickBySelenium(signInVer);
		//CommonFunctions.clickBySelenium(yesBtn);
	}
	 
	

	public void addPass(String pass) throws InterruptedException {
		Thread.sleep(3000);
		passEle.clear();
		byte[] encodedBytes =Base64.getEncoder().encode(pass.getBytes());
		System.out.println("encodedBytes "+ new String(encodedBytes));

		byte[] decodedBytes = Base64.getDecoder().decode(encodedBytes);
		System.out.println("decodedBytes "+ new String(decodedBytes));

		passEle.sendKeys(new String(decodedBytes));
   		
	
	}

	public void clickNext() throws InterruptedException, AWTException {

		CommonFunctions.clickBySelenium(nextBtnEle);
		Thread.sleep(10000);
		
		
		  Robot rb = new Robot();
		  
		  //Enter user name by ctrl-v 
			
			/*
		
			 * StringSelection username = new StringSelection("TCOEUSER10@slb.com");
			 * StringSelection pass = new StringSelection("PitcCMZ@@10");
			 * Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);
			 * rb.keyPress(KeyEvent.VK_CONTROL); rb.keyPress(KeyEvent.VK_V);
			 * rb.keyRelease(KeyEvent.VK_V); rb.keyRelease(KeyEvent.VK_CONTROL);
			 * Thread.sleep(2000);
			 */
			 
		  //tab to password entry field 
			/*
			 * rb.keyPress(KeyEvent.VK_TAB);
			 * 
			 * rb.keyRelease(KeyEvent.VK_TA  B); Thread.sleep(2000);
			 * Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pass, null);
			 * rb.keyPress(KeyEvent.VK_CONTROL); rb.keyPress(KeyEvent.VK_V);
			 * rb.keyRelease(KeyEvent.VK_V); rb.keyRelease(KeyEvent.VK_CONTROL);
			 */
		  
		  //press enter 
			/*
			 * rb.keyPress(KeyEvent.VK_ENTER); rb.keyRelease(KeyEvent.VK_ENTER);
			 */
		  
		  	  
			/*
			 * //String url= "https://" + "TCOEUSER10@slb.com" + ":" + "PitcCMZ@@10" + "@" +
			 * "app-2654-material-advisor-apps-web-evq.azurewebsites.net/"; //String
			 * pass="PitcCMZ@@10"; // getDriver().get(url); Thread.sleep(10000);
			 */		 
				
	}

	public void clickSignIn() throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(signInBtn);
		signInBtn.click();
	//	CommonFunctions.clickBySelenium(signInVer);
		Thread.sleep(4000);
		//CommonFunctions.clickBySelenium(auth);
		//CommonFunctions.clickBySelenium(yes);
	}
}
