package PageFactoryElements;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;

public class MaterialSelectionReportPage extends CommonFunctions{
	
	
	//Scroll page
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();

	public MaterialSelectionReportPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//div[@class='MuiAlert-message css-1w0ym84']")
	List<WebElement> warningElement;
	@FindBy(xpath="//div[@class='MuiGrid-root title css-rfnosa']")
	List<WebElement> slbConfidentialinfo;
	@FindBy(xpath="//h5[contains(text(),'My Requests')]")
	WebElement myReqButton;
	@FindBy(xpath="//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeLarge css-1w8s6so']//*[local-name() = 'svg']")
	WebElement threeDotsinRecom;
	
     public void confidentialMessage(String message) {
		
		for(WebElement list : slbConfidentialinfo) {
			String str= list.getText();
			str = str.replaceAll("Warning", "");
			str = str.replaceAll("\n", "").replaceAll("\r", " "); 
			System.out.println("Test test"+ str);
		if(str.equalsIgnoreCase(message)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}}
	}
    
     public void threeDotsinRecom() {
    	
    	 executor.executeScript("window.scrollBy(0,3000)");
    	 CommonFunctions.waitVisibilityofElement(threeDotsinRecom);
    	 threeDotsinRecom.click();
     }
     
     public void clickMyRequests() {
    	 
    	 myReqButton.click();
     }
     
     public void donotdiscloseMessage(String message) {
    	 
    	By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
 		CommonFunctions.expWaitAllElementToBePresent(locator);
 		WebElement ele = getDriver().findElement(locator); 
 		if(ele.isDisplayed()) {
 			Assert.assertTrue(true);
 		}else {
 			Assert.assertTrue(false);
 		}
     }
     
     public void clickButton(String message) throws InterruptedException {
    	try{
    	 Thread.sleep(2000);
     	By locator = By.xpath(String.format("//button[contains(text(),'%s')]", message));
  		CommonFunctions.expWaitAllElementToBePresent(locator);
  		WebElement ele = getDriver().findElement(locator); 
  		CommonFunctions.clickBySelenium(ele);
    	}catch (Exception e) {
    		
    	}
      }
	
	public void warningMessage(String message) {
		
		for(WebElement list : warningElement) {
			String str= list.getText();
			str = str.replaceAll("Warning", "");
			str = str.replaceAll("\n", "").replaceAll("\r", ""); 
			str = str.replaceAll("Reminder:", "");
			System.out.println("Test "+ str);
		if(str.equalsIgnoreCase(message)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}}
	}
	
	public void reportPage(String pageName) {

		By locator = By.xpath(String.format("//h6[contains(text(),'%s')]", pageName));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	
	//Converting DataTable into map key value pair
	@SuppressWarnings("rawtypes")
	public void verifyDataInMaterialRecomendation(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::tbody//tr//td[text()='%s']", pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				if(ele.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void verifyMaterialCondition(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//th[text()='%s']//following::tbody/tr//td//ul//li[text()='%s']", pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				if(ele.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}
	}
	
	
	
	@SuppressWarnings("rawtypes")
	public void verifyDataInReportPage(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//div[contains(text(),'%s')]//following::div[text()='%s']", pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				if(ele.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}
	}

	public void verifyNotes(List<Map<String, String>> dt) {

		for (Map<String, String> dataRow : dt) {

			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", dataRow.get("Notes")));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
}
