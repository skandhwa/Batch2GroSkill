package PageFactoryElements;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
/**
 * @author Ethesh Gaur
 * page class for My Request - Create Request page
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;

public class MyRequestCreateRequestPage extends CommonFunctions {

	public MyRequestCreateRequestPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath ="//div[@id='serviceType'] | //input[@id='serviceType']")	
	WebElement serviceType;
	@FindBy(xpath="//button[contains(text(),'Save')]")
	WebElement saveBtn;
	@FindBy(xpath="//input[@id='serviceLife']")
	WebElement intendedServiceLife;
	@FindBy(xpath="//div[@id='serviceLifeUnit']")
	WebElement serviceLifeUnit;
	@FindBy(xpath="//input[@id='customerId']")
	WebElement customerfield;
	@FindBy(xpath="//input[@id='countryCode']")
	WebElement countryfield;
	@FindBy(xpath="//input[@id='fieldName']")
	WebElement fieldName;
	@FindBy(xpath="//input[@id='completionRequest.tubingProductId']")
	WebElement productionTubing;
	@FindBy(xpath="//input[@id='completionRequest.tubingYieldMin']")
	WebElement specifiedtubingYieldMin;
	@FindBy(xpath="//div[@id='completionRequest.tubingCoat']")
	WebElement istubingCoat;
	@FindBy(xpath="//input[@id='completionRequest.tubingInsideDiameter']")
	WebElement tubingInsideDiameter;
	@FindBy(xpath="//div[@id='completionRequest.tubingInsideDiameterUnit']")
	WebElement tubingInsideDiaUnit;
	@FindBy(xpath="//input[@id='completionRequest.tubingWeight']")
	WebElement tubeWeight;
	@FindBy(xpath="//div[@id='completionRequest.tubingWeightUnit']")
	WebElement tubeWeightUnit;
	@FindBy(xpath="//input[@id='completionRequest.tubingInhibit']")
	WebElement tubingInhibitor;
	@FindBy(xpath="//input[@id='completionRequest.waterSource']")
	WebElement waterSource;
	@FindBy(xpath="//input[@id='completionRequest.disOxy']")
	WebElement disolvedOxygen;		
	@FindBy(xpath="//div[@id='completionRequest.disOxyUnit']")
	WebElement diOxyUnit;
	@FindBy(xpath="//input[@id='completionRequest.wiPh']")
	WebElement waterpH;
	@FindBy(xpath="//button[contains(text(),'Select')]")
	WebElement selectMaterialSpecs;
	@FindBy(xpath="//div[@id='completionRequest.wiTempUnit']")
	WebElement waterpHUnit;
	@FindBy(xpath="//div[@id='completionRequest.residualChlorine']")
	WebElement residualChlorine;
	@FindBy(xpath="//input[@id='completionRequest.wiFlowVelocity']")
	WebElement injectionFlow;
	@FindBy(xpath="//input[@id='completionRequest.wiTemp']")
	WebElement injectiontemp;
	@FindBy(xpath="//div[@id='completionRequest.wiFlowVelocityUnit']")
	WebElement velocityFlowUnit;
	@FindBy(xpath="//div[@id='completionRequest.wiTempUnit']")
	WebElement injectionTempUnit;
	@FindBy(xpath="//input[@id='complianceStandardIds']")
	WebElement industryStandards;
	@FindBy(xpath="//input[@id='completionRequest.bhpMax']")
	WebElement bottomHol;
	@FindBy(xpath="//div[@id='completionRequest.bhpMaxUnit']")
	WebElement bottomHoleUnit;
	@FindBy(xpath="//input[@id='completionRequest.bhtMax']")
	WebElement bottomHoleTemp;
	@FindBy(xpath="//div[@id='completionRequest.bhtMaxUnit']")
	WebElement bottomHoleTempUnit;
	@FindBy(xpath="//input[@id='completionRequest.siwhp']")
	WebElement shutInWellhead;
	@FindBy(xpath="//div[@id='completionRequest.siwhpUnit']")
	WebElement shutInWellheadUnit;
	@FindBy(xpath="//input[@id='completionRequest.whtMax']")
	WebElement wellhead;
	@FindBy(xpath="//div[@id='completionRequest.whtMaxUnit']")
	WebElement wellheadTempUnit;
	@FindBy(xpath="//input[@id='completionRequest.stempmin']")
	WebElement minServiceTemp;
	@FindBy(xpath="//div[@id='completionRequest.stempminUnit']")
	WebElement minSTempUnit;
	@FindBy(xpath="//input[@id='completionRequest.tvd']")
	WebElement verticalDepth;
	@FindBy(xpath="//div[@id='completionRequest.tvdUnit']")
	WebElement verticalDUnit;
	@FindBy(xpath="//input[@id='completionRequest.brineId']")
	WebElement brineDescription;
	@FindBy(xpath="//input[@id='proposedYieldStrengthMin']")
	WebElement proposedYieldStrengthMin;
	@FindBy(xpath="//input[@id='completionRequest.brineCheck']")
	WebElement brineinformation;
	@FindBy(xpath="//div[@id='completionRequest.brineCO2']")
	WebElement co2Contamination;
	@FindBy(xpath="//div[@id='completionRequest.brineH2S']")
	WebElement h2sContamination;
	@FindBy(xpath="//div[@id='completionRequest.brineOxy']")
	WebElement oxygenContamination;
	@FindBy(xpath="//input[@id='completionRequest.acidCheck']")
	WebElement acidInformation;
	@FindBy(xpath="//input[@id='completionRequest.acidId']")
	WebElement acidDescription;
	@FindBy(xpath="//div[@id='completionRequest.acidInhibit']")
	WebElement acidInhibitor;
	@FindBy(xpath="//input[@id='completionRequest.acidTime']")
	WebElement acidExpoTime;
	@FindBy(xpath="//div[@id='completionRequest.acidTimeUnit']")
	WebElement acidTimeUnit;
	@FindBy(xpath="//input[@id='completionRequest.hfCheck']")
	WebElement hydraulicFluidInfo;
	@FindBy(xpath="//div[@id='completionRequest.hfType']")
	WebElement fluidType;
	@FindBy(xpath="//input[@id='completionRequest.hfCoatingId']")
	WebElement materialCoating;
	@FindBy(xpath="//button[contains(text(),'Edit')]")
	WebElement editBtn;
	@FindBy(xpath="//button[contains(text(),'Equipment')]")
	WebElement equipment;
	@FindBy(xpath="//input[@id='equipmentId']")
	WebElement selectEquipment;
	@FindBy(xpath="//button[contains(text(),'Add')]")
	WebElement addBtn;
	@FindBy(xpath="//input[@id='componentId']")
	WebElement selectComponent;
	@FindBy(xpath="//input[@id='tstressMax']")
	WebElement maximumStress;
	@FindBy(xpath="//button[contains(text(),'Ok')]")
	WebElement oKBtn;
	@FindBy(xpath="//button[contains(text(),'General')]")
	WebElement generalTab;
	@FindBy(xpath="//button[contains(text(),'Test Submit')] | //button[contains(text(),'Test Workflow')]")
	WebElement testSubmit;
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	List<WebElement> submitBtn;
	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	WebElement cancelBtn;
	@FindBy(xpath="//input[@id='completionRequest.h2sMax']")
	WebElement h2sPartialPressure;
	@FindBy(xpath="//input[@id='completionRequest.co2Max']")
	WebElement co2PartialPressure;
	@FindBy(xpath="//input[@id='completionRequest.tubingYieldMin']")
	WebElement specifiedMinYield;
	@FindBy(xpath="//input[@id='proposedMaterialDescription']")
	WebElement proposedMetallurgy;
	@FindBy(xpath="//input[@id='proposedMaterialCoatingId']")
	WebElement proposedMaterialCoating;
	@FindBy(xpath="//div[@id='completionRequest.productionFluid']")
	WebElement primaryProductionFluid;
	@FindBy(xpath="//div[@id='completionRequest.liquidSystem']")
	WebElement liquidSystem;
	@FindBy(xpath="//input[@id='completionRequest.mudType']")
	WebElement mudType;
	@FindBy(xpath="//div[@id='completionRequest.amineInhibit']")
	WebElement amineBasedInhibitor;
	@FindBy(xpath="//div[@id='completionRequest.methanol']")
	WebElement mentholDry;



	//Scroll page
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();

	public void selectOption(String servicetype) {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", servicetype));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void amineBasedInhibitor() {
		executor.executeScript("window.scrollBy(0,2000)");
		amineBasedInhibitor.click();
	}

	public void mentholDry() {

		mentholDry.click();
	}

	public void clickMudType() {

		mudType.click();
	}

	public void clickPrimaryProductionFluid() {

		primaryProductionFluid.click();
	}

	public void clickliquidSystem() {

		liquidSystem.click();
	}


	public void selectMaterialSpecs() throws InterruptedException {

		Thread.sleep(1000);
		executor.executeScript("arguments[0].click();", selectMaterialSpecs);
		//	selectMaterialSpecs.click();

	}

	public void proposedMetarialCoating(String name) throws InterruptedException {

		
		CommonFunctions.expWaitElementToBeClickable(proposedMaterialCoating);
		try {
		proposedMaterialCoating.click();
		Thread.sleep(2000);
		executor.executeScript("window.scrollBy(0,3000)");
		proposedMaterialCoating.sendKeys(name);}
		catch(Exception e) {
			proposedMaterialCoating.click();
			Thread.sleep(2000);
			proposedMaterialCoating.sendKeys(name);	
		}
		
	}

	public void verifyDataonCreatePageForm(String name, String value) {

		By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::label[contains(text(),'%s')]", name, value));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else { 
			Assert.assertTrue(false);
		}
	}

	@SuppressWarnings("rawtypes")
	public void verifyDataonCreatePageForm(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::label[text()='%s']", pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				if(ele.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}
	}


	public void proposedMetallurgy(String name) throws InterruptedException, AWTException {
		
		try{
			proposedMetallurgy.click();
			Thread.sleep(2000);
			CommonFunctions.deleteText(proposedMetallurgy);
			proposedMetallurgy.sendKeys(name);
		}catch (Exception e) {
		CommonFunctions.deleteText(proposedMetallurgy);
		proposedMetallurgy.sendKeys(name);}
		
	}

	public void h2sPartialPressure(String value) {

		h2sPartialPressure.sendKeys(value);

	}


	public void cancelBtn() {

		cancelBtn.click();

	}
	public void specifiedMinYield(String value) {

		specifiedMinYield.sendKeys(value);

	}

	public void co2PartialPressure(String value) {

		co2PartialPressure.sendKeys(value);

	}

	public void verifySubmitMessage(String value, String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", value + " " +  message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		ele.isDisplayed();

	}

	public void testSubmit() throws InterruptedException {
		Thread.sleep(2000);
		CommonFunctions.expWaitElementToBeClickable(testSubmit);
		CommonFunctions.clickBySelenium(testSubmit);
	}

	public void submitBtn() throws InterruptedException {
		Thread.sleep(2000);
		try {
				submitBtn.get(0).click();}
		catch(Exception e) {
			submitBtn.get(1).click();	
		}
			
	}

	public void generalTab() {

		generalTab.click();
	}

	public void hydraulicFluidInfo() {
		executor.executeScript("window.scrollBy(0,3000)");
		hydraulicFluidInfo.click();
	}

	public void fluidType() {
		executor.executeScript("window.scrollBy(0,3000)");
		fluidType.click();
	}

	public void okButton() {
		oKBtn.click();
	}

	public void equipment() {
		executor.executeScript("window.scrollBy(0,-350)", "");
		equipment.click();
	}

	public void addBtn() throws InterruptedException {
		
		CommonFunctions.expWaitElementToBeClickable(addBtn);

		addBtn.click();
		Thread.sleep(4000);
	}

	public void editBtn() {
		executor.executeScript("window.scrollBy(0,-350)", "");
		editBtn.click();
	}

	public void acidTimeUnit() {

		acidTimeUnit.click();
	}

	public void acidInformation() {
		executor.executeScript("window.scrollBy(0,2500)");
		acidInformation.click();
	}

	public void acidInhibitor() {

		acidInhibitor.click();
	}

	public void oxygenContamination() {
		executor.executeScript("window.scrollBy(0,2000)");
		oxygenContamination.click();
	}

	public void h2sContamination() {
		executor.executeScript("window.scrollBy(0,2000)");
		h2sContamination.click();
	}

	public void co2Contamination() {
		executor.executeScript("window.scrollBy(0,3000)");
		co2Contamination.click();
	}

	public void brineinformation() {
		executor.executeScript("window.scrollBy(0,3000)");
		brineinformation.click();
	}

	public void verifySaveMessage(String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	
	public WebElement addEquipmentIfRequired() {

		By locator = By.xpath(String.format("//div[contains(text(),'Please select at least 1 component.')]"));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		return ele;
	}
	
	
	public void selectMaterialSpecicationFromPopup(String value) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]//preceding::th//span//input[@name='metal-selection' or @name='polymer-selection']", value));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		ele.click();
	}

	public void verifyPopUpMessage(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}


	@SuppressWarnings("rawtypes")
	public void verifyDataSelectMaterialSpecs(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::div[contains(text(),'%s')] | //div[contains(text(),'%s')]//following::div[contains(text(),'%s')]", pair.getKey(), pair.getValue(), pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				if(ele.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}
		
	}


	public void verifySaveMessageAfterComponentAdded(String message) {
		try {
			By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

		}catch (Exception e) {
			Assert.assertTrue(true);
		}
	}

	public void verticalDUnit() {
		executor.executeScript("window.scrollBy(0,2000)");
		verticalDUnit.click();
	}

	public void minSTempUnit() {

		minSTempUnit.click();
	}

	public void wellheadTempUnit() {

		wellheadTempUnit.click();
	}

	public void bottomHoleTempUnit() {

		bottomHoleTempUnit.click();
	}

	public void shutInWellheadUnit() {

		shutInWellheadUnit.click();
	}


	public void bottomHoleUnit() {
		executor.executeScript("window.scrollBy(0,2000)");
		bottomHoleUnit.click();
	}

	public void velocityFlowUnit() {

		velocityFlowUnit.click();
	}

	public void injectionTempUnit() {

		injectionTempUnit.click();
	}

	public void selectDiOxyUnit() {

		diOxyUnit.click();
	}

	public void residualChlorine() {

		residualChlorine.click();
	}
	public void waterpHUnit() {

		waterpHUnit.click();
	}

	public void materialCoating(List<Map<String, String>> dt) throws InterruptedException {
		executor.executeScript("window.scrollBy(0,1000)");
		CommonFunctions.waitVisibilityofElement(materialCoating);

		for (Map<String, String> dataRow : dt) {
			materialCoating.clear();
			materialCoating.sendKeys(dataRow.get("Material Coating"));
			materialCoating.sendKeys(Keys.DOWN);
			materialCoating.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
		}
	}

	public void selectEquipment(List<Map<String, String>> dt) throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(selectEquipment);

		for (Map<String, String> dataRow : dt) {
			selectEquipment.click();
			Thread.sleep(2000);
			selectEquipment.sendKeys(dataRow.get("Equipment"));
			Thread.sleep(2000);
			selectEquipment.sendKeys(Keys.DOWN);
			selectEquipment.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
		}
	}

	public void selectEquipmentOp(String dt) throws InterruptedException {
		selectEquipment.click();
		Thread.sleep(2000);
		selectEquipment.sendKeys(dt);
		Thread.sleep(3000);
		selectEquipment.sendKeys(Keys.DOWN);
		selectEquipment.sendKeys(Keys.RETURN);
		Thread.sleep(3000);
	}
	
	public void selectComponent(String dt) throws InterruptedException {

			selectComponent.click();
			Thread.sleep(2000);
			selectComponent.clear();

			selectComponent.sendKeys(dt);
			selectComponent.sendKeys(Keys.DOWN);
			selectComponent.sendKeys(Keys.RETURN);
			Thread.sleep(1000);
		
	}

	public void selectComponent(List<Map<String, String>> dt) throws InterruptedException {

		for (Map<String, String> dataRow : dt) {
			selectComponent.click();
			Thread.sleep(2000);
			selectComponent.clear();

			selectComponent.sendKeys(dataRow.get("Component"));
			selectComponent.sendKeys(Keys.DOWN);
			selectComponent.sendKeys(Keys.RETURN);
			Thread.sleep(1000);
		}
	}

	public void waterSource(List<Map<String, String>> dt) throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(waterSource);

		for (Map<String, String> dataRow : dt) {
			waterSource.clear();
			waterSource.sendKeys(dataRow.get("Water Source"));
			waterSource.sendKeys(Keys.DOWN);
			waterSource.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
		}
	}

	public void industryStandardData(List<Map<String, String>> dt) throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(industryStandards);

		for (Map<String, String> dataRow : dt) {
			industryStandards.clear();
			industryStandards.sendKeys(dataRow.get("Industry Standards"));
			industryStandards.sendKeys(Keys.DOWN);
			industryStandards.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
		}
	}

	
	public void acidDescriptionData(List<Map<String, String>> dt) throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(acidDescription);
		executor.executeScript("window.scrollBy(0,3000)");
		for (Map<String, String> dataRow : dt) {
			acidDescription.click();
			Thread.sleep(2000);
			acidDescription.sendKeys(dataRow.get("Acid Description"));
			Thread.sleep(2000);
			acidDescription.sendKeys(Keys.DOWN);
			acidDescription.sendKeys(Keys.RETURN);

		}
	}

	public void brineDescriptionData(List<Map<String, String>> dt) throws InterruptedException {

		CommonFunctions.waitVisibilityofElement(brineDescription);

		for (Map<String, String> dataRow : dt) {
			brineDescription.clear();
			brineDescription.sendKeys(dataRow.get("Brine Description"));
			brineDescription.sendKeys(Keys.DOWN);
			brineDescription.sendKeys(Keys.RETURN);
			Thread.sleep(2000);
		}
	}

	public void verticalDepth(String value) {

		verticalDepth.clear();
		verticalDepth.sendKeys(value);
		verticalDepth.sendKeys(Keys.TAB);
	}

	public void maxStress(String value) {

		maximumStress.clear();
		maximumStress.sendKeys(value);
	}


	public void acidExpoTime(String value) {

		acidExpoTime.clear();
		acidExpoTime.sendKeys(value);
	}

	public void minServiceTemp(String value) {

		minServiceTemp.clear();
		minServiceTemp.sendKeys(value);
		minServiceTemp.sendKeys(Keys.TAB);
	}

	public void bottomHole(String value) {

		bottomHol.clear();
		bottomHol.sendKeys(value);
		bottomHol.sendKeys(Keys.TAB);
	}

	public void wellheadTemp(String value) {

		wellhead.clear();
		wellhead.sendKeys(value);
		wellhead.sendKeys(Keys.TAB);
	}

	public void shutInWellhead(String value) {

		shutInWellhead.clear();
		shutInWellhead.sendKeys(value);
		shutInWellhead.sendKeys(Keys.TAB);
	}

	public void bottomHoleTemp(String value) {

		bottomHoleTemp.clear();
		bottomHoleTemp.sendKeys(value);
		bottomHoleTemp.sendKeys(Keys.TAB);
	}

	public void industryStandards(String value) {

		industryStandards.clear();
		industryStandards.sendKeys(value);
	}

	public void enterTubingInhibitor(String value) {

		tubingInhibitor.clear();
		tubingInhibitor.sendKeys(value);
	}

	public void injectiontemp(String value) {

		injectiontemp.clear();
		injectiontemp.sendKeys(value);
	}

	public void injectionFlow(String value) {

		injectionFlow.clear();
		injectionFlow.sendKeys(value);
	}

	public void waterpH(String value) {

		waterpH.clear();
		waterpH.sendKeys(value);
	}

	public void disolvedOxygen(String value) {

		disolvedOxygen.clear();
		disolvedOxygen.sendKeys(value);
	}


	public void verifyAcidExpoTimeErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		int i = 0;

		String acidExpoTimeVal = acidExpoTime.getAttribute("value");
		if(!acidExpoTimeVal.isEmpty()) {
			i=Integer.parseInt(acidExpoTimeVal);
		}

		if(i > 999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

		}
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
		}

	}

	public void verifyInjectionTempErrorMessage(DataTable dt) {

		List<String> data = dt.asList();

		String m = injectiontemp.getAttribute("value");
		int i=Integer.parseInt(m); 
		if(i < 0) {

			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);

		}
		if(i > 450) {

			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}

	}

	public void verifyverticalDepthErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		int i = 0;

		String verticalDepthVal = verticalDepth.getAttribute("value");
		if(!verticalDepthVal.isEmpty()) {
			i=Integer.parseInt(verticalDepthVal);
		}

		if(i > 50000) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

		}
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
		}

	}

	public void verifyMinServiceTempErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		int i = 0;

		String minServiceTempVal = minServiceTemp.getAttribute("value");
		if(!minServiceTempVal.isEmpty()) {
			i=Integer.parseInt(minServiceTempVal);
		}

		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

		}
		if(i<-100) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
		}

	}
	public void verifyAllErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		int i = 0;

		String bottomHoleVal = bottomHol.getAttribute("value");
		if(!bottomHoleVal.isEmpty()) {
			i=Integer.parseInt(bottomHoleVal);
		}

		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

		}
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
		}

	}

	public void verifyShutinWellheadErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		String m = shutInWellhead.getAttribute("value");
		int i=Integer.parseInt(m);
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();

			Assert.assertTrue(true);
		}
		if(i > 20000) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}

	}

	public void verifyErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		String m = disolvedOxygen.getAttribute("value");
		int i=Integer.parseInt(m);
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}
		if(i > 1000) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}

	}

	public void verifyInjectionFlowErrorMessage(DataTable dt) {

		List<String> data = dt.asList();
		String m = injectionFlow.getAttribute("value");
		int i=Integer.parseInt(m);
		if(i<0) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(1)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}
		if(i > 1000) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", data.get(2)));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator); 
			ele.isDisplayed();
			Assert.assertTrue(true);
		}

	}

	public void tubeWeightUnit() {

		tubeWeightUnit.click();
	}

	public void industryStandardsOptionRemove(String value) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::*[local-name() = 'svg']", value));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void deleteComponent(String value) {

		By locator = By.xpath(String.format("//td[text()='%s']//following::a//*[local-name() = 'svg']", value));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void clicktubingInsideDiaUnit() {

		tubingInsideDiaUnit.click();
	}

	public void clickIsTubingCoat() {
		istubingCoat.click();
	}

	public void tubingInsideDiameter(String value) throws InterruptedException {
		tubingInsideDiameter.sendKeys(Keys.BACK_SPACE);
		tubingInsideDiameter.sendKeys(Keys.BACK_SPACE);
		tubingInsideDiameter.sendKeys(Keys.BACK_SPACE);
		Thread.sleep(2000);
		tubingInsideDiameter.sendKeys(value);
		Thread.sleep(2000);
		tubingInsideDiameter.sendKeys(Keys.RETURN);
	}

	public void tubeWeight(String value) throws InterruptedException {
		
		executor.executeScript("window.scrollBy(0,700)");
		tubeWeight.sendKeys(Keys.BACK_SPACE);
		tubeWeight.sendKeys(Keys.BACK_SPACE);
		tubeWeight.sendKeys(Keys.BACK_SPACE);
		Thread.sleep(2000);
		tubeWeight.sendKeys(value);
		tubeWeight.sendKeys(Keys.RETURN);
	}


	public void fetchspecifiedtubingYieldMin(String value) {

		CommonFunctions.waitVisibilityofElement(specifiedtubingYieldMin);
		if(specifiedtubingYieldMin.getAttribute("Value").equalsIgnoreCase(value)) {
			Assert.assertTrue(true);

		}else {
			Assert.assertTrue(false);
		}		

	}

	public void clickServiceType() {

		serviceType.click();
	}

	public void filedName(String name) {

		fieldName.sendKeys(name);
	}

	public void productionTubing(String name) throws InterruptedException {
		Actions actions = new Actions(DriverIntialization.getDriver());
		actions.moveToElement(productionTubing);
		actions.perform();
		productionTubing.clear();
		CommonFunctions.clickBySelenium(productionTubing);
		Thread.sleep(2000);
		productionTubing.sendKeys(name);
		productionTubing.sendKeys(Keys.DOWN);
		productionTubing.sendKeys(Keys.RETURN);
	}

	public void enterCustName(String name) throws InterruptedException {

		customerfield.clear();
		CommonFunctions.clickBySelenium(customerfield);
		Thread.sleep(2000);
		customerfield.sendKeys(name);
		customerfield.sendKeys(Keys.DOWN);
		customerfield.sendKeys(Keys.RETURN);
	}

	public void setProposedYieldStrengthMin(String value) {

		proposedYieldStrengthMin.sendKeys(value);
	}

	public void verifyImportantNote(String note) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", note));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()){
			Assert.assertTrue(true);

		}else {
			Assert.assertTrue(false);
		}
	}


	public void countryfield(String name) throws InterruptedException {

		countryfield.clear();
		CommonFunctions.clickBySelenium(countryfield);
		Thread.sleep(2000);
		countryfield.sendKeys(name);
		countryfield.sendKeys(Keys.DOWN);
		countryfield.sendKeys(Keys.RETURN);
	}

	public void clickServLUnit() {

		CommonFunctions.clickBySelenium(serviceLifeUnit);
	}

	public void enterIntendedSerLife(String value) throws InterruptedException {

		intendedServiceLife.clear();
		Thread.sleep(2000);
		intendedServiceLife.sendKeys(value);

	}

	public void verifyComponentAdded(String comp) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", comp));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()){
			Assert.assertTrue(true);

		}else {
			Assert.assertTrue(false);
		}
	}

	public void verifyMandatoryMessage(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()){
			Assert.assertTrue(true);

		}else {
			Assert.assertTrue(false);
		}
	}

	public void clickSaveBtn() throws InterruptedException {
		try {
			CommonFunctions.clickBySelenium(saveBtn);
				Thread.sleep(3000);
		}
     catch(Exception e) {
			CommonFunctions.clickBySelenium(saveBtn);
 
     }
	
		
	}
}
