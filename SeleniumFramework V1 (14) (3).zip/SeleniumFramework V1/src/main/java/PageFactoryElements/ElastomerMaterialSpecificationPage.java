package PageFactoryElements;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;

public class ElastomerMaterialSpecificationPage extends CommonFunctions {
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();
	public ElastomerMaterialSpecificationPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//a[contains(text(),'Create Material Specification')]")
	WebElement createMatSpecBtn;
	@FindBy(xpath="//h5[contains(text(),'Create Material Specification')]")
	WebElement createMatSpecPage;
	@FindBy(xpath="//input[@id='specNumber']")
	WebElement matSpecificationNumber;
	@FindBy(xpath="//div[contains(text(),'Material Specification Number already exists')]")
	WebElement alreadyexitsMessage;	
	@FindBy(xpath="//input[@id='hardnessAvg']")
	WebElement hardnessNom;
	@FindBy(xpath="//input[@id='hardnessMin']")
	WebElement hardnessMin;
	@FindBy(xpath="//input[@id='hardnessMax']")
	WebElement hardnessMax;
	@FindBy(xpath="//input[@id='compressionSetTemp']")
	WebElement compressionSetTemp;
	@FindBy(xpath="//input[@id='compressionSetTime']")
	WebElement compressionSetTime;
	@FindBy(xpath="//input[@id='compressionSetMax']")
	WebElement compressionSetMax;
	@FindBy(xpath="//input[@id='materialDescriptions']")
	WebElement materialDescriptions;
	@FindBy(xpath="//input[@id='materialConditions']")
	WebElement materialConditions;
	@FindBy(xpath="//input[@id='productForms']")
	WebElement productForms;
	@FindBy(xpath="//div[@id='costIndex']")
	WebElement costIndex;
	@FindBy(xpath="//input[@id='complianceStandards']")
	WebElement complianceStandards;
	@FindBy(xpath="//button[contains(text(),'Manufacturer')]")
	WebElement manufacturerTab;
	@FindBy(xpath="//button[contains(text(),'Material Specification')]")
	WebElement materialSpecificationTab;
	@FindBy(xpath="//a[contains(text(),'Edit')]")
	WebElement editButton;
	@FindBy(xpath="//button[contains(text(),'Delete')]")
	List<WebElement> deleteButton;
	@FindBy(xpath="//textarea[@name='comment']")
	WebElement commentBox;
	@FindBy(xpath="//button[@aria-label='close']")
	WebElement closepopupMessage;
	@FindBy(xpath="//input[@id='keyword']")
	WebElement searchSpecifications;
	@FindBy(xpath="//div[@id='status']")
	WebElement status;
	@FindBy(xpath="//input[@id='materialSubclassId']")
	WebElement elastomerFamily;
	@FindBy(xpath="//input[@id='materialCommonName']")
	WebElement commonName;
	@FindBy(xpath="//input[@id='supplierId']")
	WebElement manufacturer;
	@FindBy(xpath="//button[contains(text(), 'Clear All')]")
	WebElement clearAll;
	@FindBy(xpath="//a[contains(text(),'Create Environmental Data Record')]")
	WebElement createEnvDataRecord;
	@FindBy(xpath="//input[@id='serviceLife']")
	WebElement serviceDuration;
	@FindBy(xpath="//input[@id='serviceType']")
	WebElement serviceType;	
	@FindBy(xpath="//input[@id='datasources']")
	WebElement datasources;	
	@FindBy(xpath="//input[@id='eedd.tempMin']")
	WebElement acceptableTempMin;
	@FindBy(xpath="//input[@id='eedd.tempMax']")
	WebElement acceptableTempMax;
	@FindBy(xpath="//div[@id='eedd.ecmAcceptable']")
	WebElement ECMAcceptable;
	@FindBy(xpath="//div[@id='eedd.steamAcceptable']")
	WebElement steamAcceptable;
	@FindBy(xpath="//div[@id='eedd.formationWaterAcceptable']")
	WebElement formationWaterAcceptable;
	@FindBy(xpath="//div[@id='eedd.formationWaterTempApplicable']")
	WebElement formationWaterTempApplicable;
	@FindBy(xpath="//input[@id='eedd.formationWaterTempMax']")
	WebElement formationWaterTempMax;
	@FindBy(xpath="//div[@id='eedd.seaWaterAcceptable']")
	WebElement seaWaterAcceptable;
	@FindBy(xpath="//div[@id='eedd.seaWaterTempApplicable']")
	WebElement seaWaterTempApplicable;
	@FindBy(xpath="//input[@id='eedd.seaWaterTempMax']")
	WebElement seaWaterTempMax;
	@FindBy(xpath="//div[@id='recordStatus']")
	WebElement recordStatus;
	


	public void setseaWaterTempMax(String value, String message) {

		seaWaterTempMax.sendKeys(value);
		seaWaterTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void seaWaterAcceptable(String value) {

		seaWaterAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(seaWaterAcceptable.getText().equalsIgnoreCase("Yes")) {
			seaWaterTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 
	}
	
	

	public void seaWaterTempApplicable(String value) {

		seaWaterTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(seaWaterTempApplicable.getText().equalsIgnoreCase("Yes")) {
			seaWaterTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 
	}

	public void setformationWaterTempMax(String value, String message) {

		formationWaterTempMax.sendKeys(value);
		formationWaterTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void closepopupMessage() {
		CommonFunctions.waitVisibilityofElement(closepopupMessage);
		closepopupMessage.click();
	}

	public void formationWaterTempAcceptable(String value) throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(formationWaterTempApplicable);
		formationWaterTempApplicable.click();
		Thread.sleep(4000);
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", el);
		if(formationWaterTempApplicable.getText().equalsIgnoreCase("Yes")) {
			formationWaterTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 
	}

	public void formationWaterAcceptable(String value) throws InterruptedException {
		executor.executeScript("window.scrollBy(0,500)");
		CommonFunctions.waitVisibilityofElement(formationWaterAcceptable);
		formationWaterAcceptable.click();
		Thread.sleep(3000);
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", el);
		if(formationWaterAcceptable.getText().equalsIgnoreCase("Yes")) {
			formationWaterTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 
	}

	public void ECMAcceptable() {

		ECMAcceptable.click();
	}

	public void steamAcceptable(String value) throws InterruptedException {
		try{ 
			
			steamAcceptable.click();
			Thread.sleep(2000);
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			el.click();}
		catch(Exception e) {
			CommonFunctions.waitVisibilityofElement(steamAcceptable);	
			steamAcceptable.click();
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			el.click();
		}
	}

	public void acceptableTempMax(String value) {

		acceptableTempMax.sendKeys(value);
		acceptableTempMax.sendKeys(Keys.RETURN);
	}

	public void acceptableTempMax(String value, String message) {

		acceptableTempMax.sendKeys(value);
		acceptableTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 600) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void acceptableTempMin(String value) {
		acceptableTempMin.sendKeys(value);
		acceptableTempMin.sendKeys(Keys.RETURN);
	}

	public void acceptableTempMin(String value, String message) {

		acceptableTempMin.sendKeys(value);
		acceptableTempMin.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void serviceDuration(String text) throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(serviceDuration);
		serviceDuration.sendKeys(text);
		serviceDuration.sendKeys(Keys.DOWN);
		serviceDuration.sendKeys(Keys.RETURN);

	}

	public void datasources(String text) throws InterruptedException {

		datasources.sendKeys(text);
		datasources.sendKeys(Keys.DOWN);
		datasources.sendKeys(Keys.RETURN);

	} 

	public void getServiceType() throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(serviceType);
		Thread.sleep(2000);
		String text = serviceDuration.getAttribute("value");
		if(text.equalsIgnoreCase("30 Years")) {
			Assert.assertEquals("Long-Term Service", serviceType.getAttribute("value"));
		}else {
			Assert.assertEquals("Short-Term Service", serviceType.getAttribute("value"));
		}
	}

	public void clickCreateEnvDataRecord() {

		createEnvDataRecord.click();
	}

	public void clearAll() {

		clearAll.click();
	}

	public void clickCreateMatSpciBtn() {
		CommonFunctions.waitVisibilityofElement(createMatSpecBtn);
		createMatSpecBtn.click();
	}

	public void searchResult(DataTable dt) {
		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::a[contains(text(),'%s')] | //span[contains(text(),'%s')]//following::td[contains(text(),'%s')]", pair.getKey(), pair.getValue(), pair.getKey(), pair.getValue()));
				CommonFunctions.waitVisibilityofElement(locator);
				WebElement el = getDriver().findElement(locator);
				if(el.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}	
	}


	public void manufacturer(String text) throws InterruptedException {
		Thread.sleep(3000);	
		manufacturer.sendKeys(text);
		manufacturer.sendKeys(Keys.DOWN);
		manufacturer.sendKeys(Keys.RETURN);
		Thread.sleep(2000);

	}
	
	public void recordStatus() throws InterruptedException {
		Thread.sleep(1000);	
		recordStatus.click();
		
	}

	public void elastomerFamily(String text) throws InterruptedException {
		Thread.sleep(3000);	
		elastomerFamily.sendKeys(text);
		elastomerFamily.sendKeys(Keys.DOWN);
		elastomerFamily.sendKeys(Keys.DOWN);
		elastomerFamily.sendKeys(Keys.RETURN);

	}

	public void commonName(String text) throws InterruptedException {
		Thread.sleep(3000);	
		commonName.sendKeys(text);
		commonName.sendKeys(Keys.DOWN);
		commonName.sendKeys(Keys.RETURN);

	}

	public void clickStatus() {
		status.click();
	}

	public void clickoption(String option) {
		try {
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", option));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			el.click();}
		catch(Exception e) {
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", option));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
		}
	}

	public void removeDataSources(String dataSources) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]/following::*[local-name() = 'svg']", dataSources));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void searchSpecifications(String keyword) throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(searchSpecifications);
		searchSpecifications.sendKeys(keyword);
		Thread.sleep(2000);
	}

	public void addComment(String message) {
		CommonFunctions.waitVisibilityofElement(commentBox);
		commentBox.sendKeys(message);;
	}

	public void clickeditButton() throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(editButton);
		Thread.sleep(14000);
		editButton.click();
	}

	public void deleteButton() {
		CommonFunctions.waitVisibilityofElement(deleteButton.get(1));
		deleteButton.get(1).click();
	}

	public void clickButtonOnPopup(String btn) {

		By locator = By.xpath(String.format("//button[contains(text(),'%s')]", btn));
		CommonFunctions.waitVisibilityofElement(locator);
		List<WebElement> el = getDriver().findElements(locator);
		el.get(1).click();
	}

	public void manufacturerOrChangeHistoryMessage(String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void manufacturerName(String name) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}	else {
			Assert.assertTrue(false);
		}
	}

	public void selectEDRfromEDRSummary(String edr, String option) {

		By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::th[contains(text(),'%s')]//following::a//*[local-name() = 'svg']", edr, option));
		CommonFunctions.waitVisibilityofElement(locator);
		List<WebElement> el = getDriver().findElements(locator);
		switch(edr) {
		case "EDD":
			el.get(0).click();
			break;
		case "BCD":
			el.get(1).click();
			break;
		case "ACD":
			el.get(2).click();
			break;
		case "HFCD":
			el.get(3).click();
			break;
		default:

		}

	}

	public void selectEDR(String edr) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::a//*[local-name() = 'svg'] | //span[contains(text(),'%s')]//following::a[starts-with(@href,'/material-specifications/')]", edr, edr));
		CommonFunctions.waitVisibilityofElement(locator);
		List<WebElement> el = getDriver().findElements(locator);
		try {
		switch(edr) {
		case "EDD":
			el.get(0).click();
			break;
		case "BCD":
			el.get(2).click();
			break;
		case "ACD":
			el.get(3).click();
			break;
		case "HFCD":
			Thread.sleep(3000);
			el.get(4).click();
			break;
		case "AGCD":
			el.get(0).click();
			break;	
		default:

		}}catch(Exception e) {
			logger.info("Exception is " + e);			
		}

	}
	
	public void selectEDR2(String edr) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::a//*[local-name() = 'svg'] | //span[contains(text(),'%s')]//following::a[starts-with(@href,'/material-specifications/')]", edr, edr));
		CommonFunctions.waitVisibilityofElement(locator);
		List<WebElement> el = getDriver().findElements(locator);
		try {
		switch(edr) {
		case "BCD":
			el.get(1).click();
			break;
		case "ACD":
			el.get(2).click();
			break;
		case "HFCD":
			Thread.sleep(3000);
			el.get(3).click();
			break;
		case "AGCD":
			el.get(0).click();
			break;	
		default:

		}}catch(Exception e) {
			logger.info("Exception is " + e);			
		}

	}
	
	public void navigateBack() {

		DriverIntialization.getDriver().navigate().back();
	}

	public void verifyTooltip(String tooltip) throws InterruptedException {
		try {
			Actions toolTip = new Actions(driver);
			By locator = By.xpath(String.format("//th[contains(text(),'EDD')]//following::*[local-name() = 'svg'] | //th[contains(text(),'AGCD')]//following::*[local-name() = 'svg']"));
			CommonFunctions.waitVisibilityofElement(locator);
			List<WebElement> el = getDriver().findElements(locator);
			toolTip.clickAndHold().moveToElement(el.get(0));
			toolTip.moveToElement(el.get(0)).build().perform();
			el.get(0).click();}
		catch(Exception e) {
			By locator = By.xpath(String.format("//th[contains(text(),'EDD')]//following::*[local-name() = 'svg'] | //th[contains(text(),'AGCD')]//following::*[local-name() = 'svg']"));
			CommonFunctions.waitVisibilityofElement(locator);
			List<WebElement> el = getDriver().findElements(locator);
			el.get(0).click(); 
		}
		Thread.sleep(5000);
		By locator2 = By.xpath(String.format("//div[contains(text(),'%s')]", tooltip));
		WebElement el2 = getDriver().findElement(locator2);
		if(el2.isDisplayed()){
			Assert.assertTrue(true);
		}	else {
			Assert.assertTrue(false);
		}

	}

	public void clickManufacturerName(String name) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]//following::a//*[local-name() = 'svg']", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void materialSpecificationTab() {

		materialSpecificationTab.click();
	}

	public void manufacturerTab() {

		manufacturerTab.click();
	}

	public void complianceStandards() {

		complianceStandards.click();
	}

	public void clickcostIndex() {

		costIndex.click();
	}

	public void messageTopRightCorner(String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void selectCostIndex(String number) {
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", number));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void clickButton(String button) throws InterruptedException {
		By locator = By.xpath(String.format("//button[contains(text(),'%s')]", button));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement el = getDriver().findElement(locator);
		Thread.sleep(13000);
		try {
			el.click();}
		catch(Exception e) {
			CommonFunctions.expWaitElementToBeClickable(locator);
			el.click();
		}
	}
	
	public void cancelMaterialDesc(String button) throws InterruptedException {
		By locator = By.xpath(String.format("//span[contains(text(), '%s')]//following::*[local-name() = 'svg']", button));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void clickMaterialDescriptions() {

		materialDescriptions.click();
		materialDescriptions.sendKeys(Keys.BACK_SPACE);
	}

	public void setproductForms(String value) {

		productForms.sendKeys(value);
	}

	public void setmaterialConditions(String value) {

		materialConditions.sendKeys(value);
	}

	public void setMatSpecNumber(String value) {

		matSpecificationNumber.sendKeys(value);
	}

	public void setcompressionSetMax(String value) {

		compressionSetMax.sendKeys(Keys.BACK_SPACE);
		compressionSetMax.sendKeys(Keys.BACK_SPACE);
		compressionSetMax.sendKeys(Keys.BACK_SPACE);
		compressionSetMax.sendKeys(Keys.BACK_SPACE);
		compressionSetMax.sendKeys(value);
		compressionSetMax.sendKeys(Keys.RETURN);
	}

	public void setcompressionSetTemp(String value) {

		compressionSetTemp.sendKeys(Keys.BACK_SPACE);
		compressionSetTemp.sendKeys(Keys.BACK_SPACE);
		compressionSetTemp.sendKeys(Keys.BACK_SPACE);
		compressionSetTemp.sendKeys(Keys.BACK_SPACE);
		compressionSetTemp.sendKeys(value);
		compressionSetTemp.sendKeys(Keys.RETURN);
	}

	public void setcompressionSetTime(String value) {

		compressionSetTime.sendKeys(Keys.BACK_SPACE);
		compressionSetTime.sendKeys(Keys.BACK_SPACE);
		compressionSetTime.sendKeys(Keys.BACK_SPACE);
		compressionSetTime.sendKeys(Keys.BACK_SPACE);
		compressionSetTime.sendKeys(value);
		compressionSetTime.sendKeys(Keys.RETURN);
	}

	public void setHardenssMin(String value) {

		hardnessMin.sendKeys(Keys.BACK_SPACE);
		hardnessMin.sendKeys(Keys.BACK_SPACE);
		hardnessMin.sendKeys(Keys.BACK_SPACE);
		hardnessMin.sendKeys(Keys.BACK_SPACE);
		hardnessMin.sendKeys(value);
		hardnessMin.sendKeys(Keys.RETURN);
	}

	public void setHardenssMax(String value) {

		hardnessMax.sendKeys(Keys.BACK_SPACE);
		hardnessMax.sendKeys(Keys.BACK_SPACE);
		hardnessMax.sendKeys(Keys.BACK_SPACE);
		hardnessMax.sendKeys(Keys.BACK_SPACE);
		hardnessMax.sendKeys(value);
		hardnessMax.sendKeys(Keys.RETURN);
	}
	public void setHardenssNom(String value) {

		hardnessNom.sendKeys(Keys.BACK_SPACE);
		hardnessNom.sendKeys(Keys.BACK_SPACE);
		hardnessNom.sendKeys(Keys.BACK_SPACE);
		hardnessNom.sendKeys(Keys.BACK_SPACE);
		hardnessNom.sendKeys(value);
		hardnessNom.sendKeys(Keys.RETURN);
	}

	public void pageDisplay(String page) {
		By locator = By.xpath(String.format("//div[contains(text(),'%s')] | //h5[contains(text(),'%s')] | //h6[contains(text(),'%s')]", page, page, page));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}



	public void selectionReportPage(String page) {
		By locator = By.xpath(String.format("//h4[contains(text(),'%s')]", page));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void generalInfo(String value) {
		By locator = By.xpath(String.format("//p[contains(text(),'General Information')]//following::span[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void removeMaterialCondition(String message) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::*[local-name() = 'svg']", message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		ele.click();
	}

	public void errorMessage(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator); 
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void alreadyExits(String page) {
		CommonFunctions.waitVisibilityofElement(alreadyexitsMessage);
		if(alreadyexitsMessage.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void dispalyCreateMatSpciPage() {
		CommonFunctions.waitVisibilityofElement(createMatSpecPage);
		if(createMatSpecPage.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
}
