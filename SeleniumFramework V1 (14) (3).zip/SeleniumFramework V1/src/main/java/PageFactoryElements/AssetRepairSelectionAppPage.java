package PageFactoryElements;
/**
 * 
 * @author Ethesh Gaur
 */

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import Utilities.IDataReader;

public class AssetRepairSelectionAppPage  extends CommonFunctions{



	@FindBy (xpath="//input[@id='coating.coatingName']")
	WebElement coatingName;
	@FindBy (xpath="//div[@id='coating-coatingSpecification']")
	WebElement coatingSpec;
	@FindBy(xpath="//input[@name='coating.coatingSpecification']")
	WebElement coatingSpeSelected;
	@FindBy(xpath="//input[@id='damageType']")
	WebElement damageType;
	@FindBy(xpath="//div[@id='damageSeverityId']")
	WebElement damageSeverity;
	@FindBy(xpath="//div[contains(text(),'ARSR')]")
	WebElement referenceNumber;
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	WebElement submitButton;
	@FindBy(xpath="//div[@id='repairSurface']")
	WebElement repairSurface;
	@FindBy(xpath="//div[@id='partFamily']")
	WebElement partFamily;
	@FindBy(xpath="//input[@id='repairArea']")
	WebElement specificRepairArea;
	@FindBy(xpath="//label[@id='materialRemovalAcceptable']//*[contains(text(),'Yes')]")
	WebElement materialRemovalAcceptableYES;
	@FindBy(xpath="//label[@id='materialRemovalAcceptable']//*[contains(text(),'No')]")
	WebElement materialRemovalAcceptableNO;
	@FindBy(xpath="//label[@id='postTreatmentAcceptable']//*[contains(text(),'Yes')]")
	WebElement postRepairTreatmentYES;
	@FindBy(xpath="//label[@id='postTreatmentAcceptable']//*[contains(text(),'No')]")
	WebElement postRepairTreatmentNo;
	@FindBy(xpath="//h6[contains(text(),'Post Repair Requirements')]//span//*[@fill='currentColor']")
	WebElement postRepairToolTip;
	@FindBy(xpath="//input[@id='damage.defectDepth']")
	WebElement defectDepth;
	@FindBy(xpath="//input[@id='damage.insideDiameterSurfaceDistance']")
	WebElement defectLocation;
	@FindBy(xpath="//input[@id='damage.insideDiameter']")
	WebElement insideDiameter;
	@FindBy(xpath="//input[@id='damage.crackLength']")
	WebElement crackLength;
	@FindBy(xpath="//input[@id='damage.wallThicknessLoss']")
	WebElement wallThicknessLoss;
	@FindBy(xpath="//a[contains(text(),'Materials Apps')]")
	WebElement matApp;
	
	

	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();

	public AssetRepairSelectionAppPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	
	
	public void setDefectDepth(String value) {
		
		defectDepth.sendKeys(value);
	}
	
    public void matApp() throws InterruptedException {
    	 CommonFunctions.expWaitElementToBeClickable(matApp);
	    matApp.click();
	    Thread.sleep(2000);
	}
	
    public void setWallThickness(String value) {
		
    	wallThicknessLoss.sendKeys(value);
	}
	
    public void setcrackLength(String value) {
		
    	crackLength.sendKeys(value);
	}

	public void setDefectLocation(String value) {
		
		defectLocation.sendKeys(value);
	}
	
    public void setinsideDia(String value) {
		
    	insideDiameter.sendKeys(value);
	}
	
	public void materialRemovalAcceptableYES() throws InterruptedException {
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		executor.executeScript(
	            "arguments[0].scrollIntoView();", materialRemovalAcceptableYES);
        CommonFunctions.expWaitElementToBeClickable(materialRemovalAcceptableYES);
        Thread.sleep(2000);
        CommonFunctions.clickRadioBTN(materialRemovalAcceptableYES);
        CommonFunctions.clickRadioBTN(materialRemovalAcceptableYES);
        materialRemovalAcceptableYES.click();
	}
	
	
	
	public String tooltipPostRepair(String message) {
		CommonFunctions.actions.moveToElement(postRepairToolTip).perform();
		return verifyTooltip(message).getText();
		
	}
	
	public WebElement verifyTooltip(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'Please indicate which of the following properties are desired for the repaired surface.')]", message));
		WebElement ele = getDriver().findElement(locator);
		return ele;
	}
	
	public void materialRemovalAcceptableNO() {

		CommonFunctions.clickRadioBTN(materialRemovalAcceptableNO);
	}
	
	public void postRepairTreatmentYES() {

		CommonFunctions.clickRadioBTN(postRepairTreatmentYES);
	}
	
	public void postRepairTreatmentNo() {

		CommonFunctions.clickRadioBTN(postRepairTreatmentNo);
	}
	
	public void clickDamageSeverity() {

		damageSeverity.click();
	}
	
	public void selectSpecificRepairArea(String options) throws InterruptedException {
		specificRepairArea.clear();
        Thread.sleep(2000);
		CommonFunctions.clickBySelenium(specificRepairArea);
		specificRepairArea.sendKeys(options);
		specificRepairArea.sendKeys(Keys.DOWN);
		specificRepairArea.sendKeys(Keys.ENTER);
	}

	public void partFamily() {

		partFamily.click();
	}

	public void clickRepairSurface() {

		repairSurface.click();
	}

	public void clickSubmitBtn() {
		CommonFunctions.expWaitElementToBeClickable(submitButton);
		submitButton.click();
	}
	
	public void selectPostRepairReqOptions(String option) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", option));
		WebElement ele = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", ele);
	}
	
	public void verifyName(String name) {

		By locator = By.xpath(String.format("//h6[contains(text(),'%s')]", name));
		WebElement ele = getDriver().findElement(locator);
        if(ele.isDisplayed()) {
        	Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}
	
	public void verifyComposition(String name) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", name));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
        

	}
	
	public void verifyTableInRecomm(String value) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", value));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
        

	}

	public void clickOption(String option) {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", option));
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void verifyMessage(String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	public void selectOptions(String option) {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", option));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void repairSurfaceinGeneral(String option) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", option));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void sectionsAssociatedWithBothandBaseMaterial(String name) {

		By locator = By.xpath(String.format("//h6[contains(text(),'%s')]", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public WebElement selectRepairSurfaceData(String option) {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", option));
		WebElement ele = getDriver().findElement(locator);
		return ele;
	}

	public void referenceNumberinPrint(String number) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", number));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void selectmultOptions(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	} 

	public void clickCurrentStage(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();

	} 

	public void coatingSpecList(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		ele.click();

	}


	public void verifyCoatingSpecInfo(String name, List<Map<String, String>> dataTable) throws InterruptedException {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", name));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()){
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
		for (Map<String, String> dataRow : dataTable) {
			By locator2 = By.xpath(String.format("//td[contains(text(),'%s')]//following::td[contains(text(),'%s')][1]", (dataRow.get("Fields")), (dataRow.get("Data"))));
			CommonFunctions.expWaitAllElementToBePresent(locator2);
			WebElement ele2 = getDriver().findElement(locator2);
			if(ele2.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}

		}

	}

	public void verifyDamageType(IDataReader dataTable) throws InterruptedException {

		List<Map<String, String>> data=dataTable.getAllRows();

		for(int i=0;i<data.size();i++) {

			damageType.clear();
			Thread.sleep(2000);
			damageType.click();
			damageType.sendKeys(data.get(i).get("Damage Type"));
			damageType.sendKeys(Keys.DOWN);
			damageType.sendKeys(Keys.RETURN);
		}
	}


	public void selectCoatingName(String option) {

		CommonFunctions.waitVisibilityofElement(coatingName);
		coatingName.click();
		coatingName.clear();
		coatingName.sendKeys(option);
		coatingName.sendKeys(Keys.DOWN);
		coatingName.sendKeys(Keys.RETURN);

	}

	public void setDamageType(String option) throws InterruptedException {

		damageType.clear();
		Thread.sleep(2000);
		damageType.click();
		damageType.sendKeys(option);
		damageType.sendKeys(Keys.DOWN);
		damageType.sendKeys(Keys.RETURN);
	}

	public void escCoatingSpecs() {

		coatingSpec.sendKeys(Keys.ESCAPE);

	}

	public void verifyAssetRepairRecommendation(String name) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}

	public String gettheReferenceNumber() {
		if(referenceNumber.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
		String[] parts = referenceNumber.getText().split("Test");
		String part1 = parts[0]; // 004
		part1 = part1.replaceAll("\\s", "");
		return part1;
	}
	
	public void coatingSpecsSelection(List<Map<String, String>> dataTable, String name) throws InterruptedException {

		for (Map<String, String> dataRow : dataTable) {
			selectCoatingName(name);
			coatingSpec.click();
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", dataRow.get("Coating Specification")));
			WebElement ele = getDriver().findElement(locator);
			ele.click();
			Thread.sleep(2000);
			if(coatingSpeSelected.getAttribute("value").equals(dataRow.get("Coating Specification"))) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
			escCoatingSpecs();
		}
		Thread.sleep(3000);

	}

}
