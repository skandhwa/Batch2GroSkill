package PageFactoryElements;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;

public class ElastomerHydraulicFluidCompatibilityDataPage extends CommonFunctions{

	
	public ElastomerHydraulicFluidCompatibilityDataPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@id='ehfcd.waterGlycolFluidAcceptable']")
	WebElement waterGlycolFluidAcceptable;
	@FindBy(xpath="//div[@id='ehfcd.mineralOilAcceptable']")
	WebElement mineralOilAcceptable;
	@FindBy(xpath="//div[@id='ehfcd.mineralOilTempApplicable']")
	WebElement mineralOilTempApplicable;
	@FindBy(xpath="//input[@id='ehfcd.mineralOilTempMax']")
	WebElement mineralOilTempMax;
	@FindBy(xpath="//div[@id='ehfcd.synthaticOilAcceptable']")
	WebElement synthaticOilAcceptable;
	@FindBy(xpath="//div[@id='ehfcd.synthaticOilTempApplicable']")
	WebElement synthaticOilTempApplicable;
	@FindBy(xpath="//input[@id='ehfcd.synthaticOilTempMax']")
	WebElement synthaticOilTempMax;
	@FindBy(xpath="//input[@id='ehfcd.waterGlycolFluidPhHighLimit']")
	WebElement waterGlycolFluidPhHighLimit;
	@FindBy(xpath="//div[@id='ehfcd.waterGlycolFluidPhHigherAcceptable']")
	WebElement waterGlycolFluidPhHigherAcceptable;
	@FindBy(xpath="//div[@id='ehfcd.waterGlycolFluidPhHigherTempApplicable']")
	WebElement waterGlycolFluidPhHigherTempApplicable;
	@FindBy(xpath="//input[@id='ehfcd.waterGlycolFluidPhHigherTempMax']")
	WebElement waterGlycolFluidPhHigherTempMax;
	@FindBy(xpath="//input[@id='ehfcd.waterGlycolFluidPhLowLimit']")
	WebElement waterGlycolFluidPhLowLimit;
	@FindBy(xpath="//div[@id='ehfcd.waterGlycolFluidPhLowerAcceptable']")
	WebElement waterGlycolFluidPhLowerAcceptable;
	@FindBy(xpath="//div[@id='ehfcd.waterGlycolFluidPhLowerTempApplicable']")
	WebElement waterGlycolFluidPhLowerTempApplicable;
	@FindBy(xpath="//input[@id='ehfcd.waterGlycolFluidPhLowerTempMax']")
	WebElement waterGlycolFluidPhLowerTempMax;
	
	
	public void waterGlycolFluidAcceptable() {

		waterGlycolFluidAcceptable.click();
		 
	}
	
	
	public void waterGlycolFluidPhLowerTempMax(String value, String message) {

		waterGlycolFluidPhLowerTempMax.sendKeys(value);
		waterGlycolFluidPhLowerTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	
	public void waterGlycolFluidPhHigherTempApplicable(String value) {

		waterGlycolFluidPhHigherTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(waterGlycolFluidPhHigherTempApplicable.getText().equalsIgnoreCase("Yes") && waterGlycolFluidPhHigherAcceptable.getText().equalsIgnoreCase("Yes")) {
			waterGlycolFluidPhHigherTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}
	
	
	
	public void waterGlycolFluidPhLowerTempApplicable(String value) {

		waterGlycolFluidPhLowerTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(waterGlycolFluidPhLowerTempApplicable.getText().equalsIgnoreCase("Yes") && waterGlycolFluidPhLowerAcceptable.getText().equalsIgnoreCase("Yes")) {
			waterGlycolFluidPhLowerTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}
	
	public void waterGlycolFluidPhLowerAcceptable(String value) {

		waterGlycolFluidPhLowerAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		
	}
	
	public void waterGlycolFluidPhLowLimit(String value, String message) {

		waterGlycolFluidPhLowLimit.sendKeys(value);
		waterGlycolFluidPhLowLimit.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	
	
	public void waterGlycolFluidPhHigherTempMax(String value, String message) {

		waterGlycolFluidPhHigherTempMax.sendKeys(value);
		waterGlycolFluidPhHigherTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void waterGlycolFluidPhHigherAcceptable(String value) {

		waterGlycolFluidPhHigherAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		
	}
	
	public void synthaticOilAcceptable(String value) {

		synthaticOilAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(synthaticOilAcceptable.getText().equalsIgnoreCase("Yes")) {
			synthaticOilTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}
	
	public void synthaticOilTempApplicable(String value) {

		synthaticOilTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(synthaticOilTempApplicable.getText().equalsIgnoreCase("Yes")) {
			synthaticOilTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}
	
	public void mineralOilAcceptable(String value) {

		mineralOilAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(mineralOilAcceptable.getText().equalsIgnoreCase("Yes") ) {
			mineralOilTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}
	
	public void mineralOilTempApplicable(String value) {

		mineralOilTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(mineralOilTempApplicable.getText().equalsIgnoreCase("Yes")) {
			mineralOilTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} }
	
	public void waterGlycolFluidPhHighLimit(String value, String message) {

		waterGlycolFluidPhHighLimit.sendKeys(value);
		waterGlycolFluidPhHighLimit.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void mineralOilTempMax(String value, String message) {

		mineralOilTempMax.sendKeys(value);
		mineralOilTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	
	public void synthaticOilTempMax(String value, String message) {

		synthaticOilTempMax.sendKeys(value);
		synthaticOilTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
}	
