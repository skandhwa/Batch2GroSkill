package PageFactoryElements;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import io.cucumber.datatable.DataTable;

public class SealLifePredictionAppPageClass extends CommonFunctions{

	@FindBy (xpath="//input[@id='reference']")
	WebElement reference;
	@FindBy (xpath="//*[contains(text(), 'Seal Life Prediction Requests')]")
	WebElement sealLifeReqPage;
	@FindBy (xpath="//h5[contains(text(),'Seal Life Prediction')]")
	WebElement sealLifePredPage;
	@FindBy (xpath="//a[@href]")
	List<WebElement> pdfClick;
	@FindBy(xpath="//input[@id='name']")
	WebElement trialName;
	@FindBy (xpath="//input[@id ='materialProfile.reference']")
	WebElement material;
	@FindBy (xpath="//img[@class ='image']")
	WebElement image;
	@FindBy(xpath="//input[@id='trialRuns[0].temperature']")
	WebElement temp;
	@FindBy(xpath="//input[@id='trialRuns[0].time']")
	WebElement time;
	@FindBy(xpath="//div[@id='trialRuns[0].fluidType']")
	WebElement fluidType;
	@FindBy(xpath="//input[@id='trialRuns[0].multiplier']")
	WebElement multiplier;


	public SealLifePredictionAppPageClass(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


    public void setTemp(String temperature) {
    	temp.sendKeys(temperature);
    }
    
    public void setTime(String hour) {
    	time.sendKeys(hour);
    }
    
    public void setMultiplier(String value) {
    	multiplier.sendKeys(value);
    }
    
    public void selectFluidType(String fluid) {
    	fluidType.click();
    	By locator = By.xpath(String.format("//li[@data-value='%s']", fluid));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.waitVisibilityofElement(locator);
		ele.click();
    }
    
    public void verifyMandatMessage(String message) {
    	
    	By locator = By.xpath(String.format("//div[contains(text(), '%s')]", message));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.waitVisibilityofElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
    }

	public void searchReference(String value) {

		reference.clear();
		reference.sendKeys(value);
	}

	public void setTrialName(String value) {

		trialName.clear();
		trialName.sendKeys(value);
	}

	public void setMaterial(String value) {

		material.clear();
		material.sendKeys(value);
		material.sendKeys(Keys.DOWN);
		material.sendKeys(Keys.ENTER);

	}

	public void verifyImage() {

		if(image.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void clickPDF() {
		pdfClick.get(3).click();
	}

	public void clearSearchRef() {

		reference.sendKeys(Keys.CONTROL + "A");
		reference.sendKeys(Keys.BACK_SPACE);

	}

	public void displaySealLifePrePage() {

		if(sealLifePredPage.isDisplayed()) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}

	}

	public void displaySealLifeReqPage() {

		if(sealLifeReqPage.isDisplayed()) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}

	}

	public void sealLifeReqPageClick() {

		sealLifeReqPage.click();

	}

	public void clickTempandProfile(String value) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", value));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.waitVisibilityofElement(locator);
		ele.click();
	}



	public void verifyReferenceData(DataTable dt) throws InterruptedException {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::td[contains(text(),'%s')]", pair.getKey(), pair.getValue()));	
				CommonFunctions.waitVisibilityofElement(locator);
				WebElement el = getDriver().findElement(locator);
				if(el.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}	
	}


	public void verifyReferenceDataonRequestPage(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				By locator = By.xpath(String.format("//td[contains(text(),'%s')]//following::td[contains(text(),'%s')]", pair.getKey(), pair.getValue()));				CommonFunctions.waitVisibilityofElement(locator);
				WebElement el = getDriver().findElement(locator);
				if(el.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}	
	}

	
	public void verifyMaterialData(DataTable dt) {

		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				String val = (String) pair.getValue();
				material.clear();
				material.sendKeys(val);
				material.sendKeys(Keys.DOWN);
				material.sendKeys(Keys.ENTER);
			}
		}	
	}

	public void verifyReference(String value) {

		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", value));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.waitVisibilityofElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}
	}

	public void openReference(String value) {

		try {
			By locator = By.xpath(String.format("//a[contains(text(),'%s')]", value));
			WebElement ele = getDriver().findElement(locator);
			CommonFunctions.waitVisibilityofElement(locator);
			if(ele.isDisplayed()) {
				CommonFunctions.clickBySelenium(ele);}
		}catch (Exception e) {
			System.out.println("Exeption e " + e);
		}
	}
}
