package PageFactoryElements;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;

public class ElastomerBrineCompatibilityDataRecordPage extends CommonFunctions{
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();


	public ElastomerBrineCompatibilityDataRecordPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//input[@id='ebcd.brinePhHighLimit']")
	WebElement brinePhHighLimit;
	@FindBy(xpath="//div[@id='ebcd.brinePhHigherAcceptable']")
	WebElement brinePhHigherAcceptable;
	@FindBy(xpath="//input[@id='ebcd.brinePhLowLimit']")
	WebElement brinePhLowLimit;
	@FindBy(xpath="//div[@id='ebcd.brinePhLowerAcceptable']")
	WebElement brinePhLowerAcceptable;
	@FindBy(xpath="//div[@id='ebcd.cabr2Acceptable']")
	WebElement cabr2Acceptable;
	@FindBy(xpath="//div[@id='ebcd.cabr2TempApplicable']")
	WebElement cabr2TempApplicable;
	@FindBy(xpath="//input[@id='ebcd.cabr2TempMax']")
	WebElement cabr2TempMax;
	@FindBy(xpath="//div[@id='ebcd.znbr2Acceptable']")
	WebElement znbr2Acceptable;
	@FindBy(xpath="//div[@id='ebcd.znbr2TempApplicable']")
	WebElement znbr2TempApplicable;
	@FindBy(xpath="//input[@id='ebcd.znbr2TempMax']")
	WebElement znbr2TempMax;

	public void clickBrinePhHigherAcceptable() {
		brinePhHigherAcceptable.click();
	}
	
	public void clickbrinePhLowerAcceptable() {
		brinePhLowerAcceptable.click();
	}
	
	
	public void znbr2TempMax(String value, String message) {
		znbr2TempMax.clear();
		znbr2TempMax.sendKeys(value);
		znbr2TempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void cabr2TempMax(String value, String message) {
		cabr2TempMax.clear();
		cabr2TempMax.sendKeys(value);
		cabr2TempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void openRecordUID(String value) throws InterruptedException {
		
		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", el);
	}
	
	public void znbr2TempApplicable(String value) {

		znbr2TempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(znbr2TempApplicable.getText().equalsIgnoreCase("Yes")) {
			znbr2TempMax.isDisplayed();
			Assert.assertTrue(true);
		} 
	}
	
	public void cabr2TempApplicable(String value) {
     try {
	
		cabr2TempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();}
        catch(StaleElementReferenceException e) {
        	By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
    		CommonFunctions.waitVisibilityofElement(locator);
    		WebElement el = getDriver().findElement(locator);
    		el.click();
        }
		if(cabr2TempApplicable.getText().equalsIgnoreCase("Yes")) {
			cabr2TempMax.isDisplayed();
			Assert.assertTrue(true);
		} 
	}
	
	public void cabr2Acceptable(String value) throws InterruptedException {

		try {
			
			cabr2Acceptable.click();
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			el.click();}
	        catch(StaleElementReferenceException e) {
	        	By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
	    		CommonFunctions.waitVisibilityofElement(locator);
	    		WebElement el = getDriver().findElement(locator);
	    		el.click();
	        }
		if(cabr2Acceptable.getText().equalsIgnoreCase("Yes")) {
			cabr2TempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 
		Thread.sleep(2000);
	}
	
	public void znbr2Acceptable(String value) {

		znbr2Acceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(znbr2Acceptable.getText().equalsIgnoreCase("Yes")) {
			znbr2TempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 
	}
	
	public void brinePhHighLimit(String value, String message) throws InterruptedException {
		
		if(!brinePhHighLimit.getAttribute("value").isEmpty()) {
			brinePhHighLimit.clear();
			brinePhHighLimit.sendKeys(Keys.BACK_SPACE);
			
		}
		
		brinePhHighLimit.sendKeys(value);
		brinePhHighLimit.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
		Thread.sleep(2000);
	}
	
	public void brinePhLowLimit(String value, String message) {
		if(!brinePhLowLimit.getAttribute("value").isEmpty()) {
			brinePhLowLimit.clear();
			brinePhLowLimit.sendKeys(Keys.BACK_SPACE);
			
		}
		brinePhLowLimit.sendKeys(value);
		brinePhLowLimit.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value);  
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}	


}
