package PageFactoryElements;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;

public class MechanicalFailureDiagnosticApp extends CommonFunctions {

	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();

	public MechanicalFailureDiagnosticApp (WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	

 @FindBy(xpath="//div[@id='productLine']")
 WebElement fieldApp;
 @FindBy(xpath="//button[@test-id='next-btn']")
 WebElement nextBtn;
 @FindBy(xpath="//div[@id='supplimentaryVisualDamage-fracturePlaneOrientation']")
 WebElement fracturePlaneOrientation;
 @FindBy(xpath="//input[@id='supplimentaryEnvironment-ph']")
 WebElement supppH;
 @FindBy(xpath="//input[@id='supplimentaryEnvironment-bottomHoleTemperature']")
 WebElement bottomholeTemp;
 @FindBy(xpath="//input[@id='supplimentaryEnvironment-bottomHolePressure']")
 WebElement bottomholePressure;
 @FindBy(xpath="//span[contains(text(),'Failure Location Characteristics')]")
 WebElement failureLocationCharac;
 @FindBy(xpath="//span[contains(text(),'Materials')]")
 WebElement materialsPart;
 @FindBy(xpath="//input[@id='materialGrade']")
 WebElement materialGrade;
 @FindBy(xpath="//input[@id='materialClass']")
 WebElement materialClass;
 @FindBy(xpath="//input[@id='materialSubClass']")
 WebElement materialSubClass;
 @FindBy(xpath="//input[@id='complianceStandards']")
 WebElement compStandards;
 @FindBy(xpath="//span[contains(text(), 'Standard Compliance')]")
 WebElement clickStandardsComp;
 @FindBy(xpath="//button[@test-id='reset-form-btn']")
 WebElement resetBtn;
 @FindBy(xpath="//button[@test-id='submit-form-btn']")
 WebElement submitBtn;
 @FindBy(xpath="//div[contains(text(),'Diagnostic Reference')]//following::div[contains(text(),'FDR')]")
 WebElement diagRef;
 @FindBy(xpath="//button[contains(text(),'Add')]")
 WebElement smeReviewAddButton;
 @FindBy(xpath="//div[@id='result']")
 WebElement validationResult;
 @FindBy(xpath="//textarea[@id='comments']")
 WebElement comment;
		 
 
 public void validationResult() {
	
	 validationResult.click();
 }
 
 public void addComment(String message) {
		
	 comment.sendKeys(message);
 }
 
 public void compStandards() {
		
	 compStandards.click();
 }
 
 public void smeReviewAddButton() {
		
	 smeReviewAddButton.click();
 }
 
 public String fetchDiagRef() {
		
	 
	return diagRef.getText();
 }
 
 public void submitBtn() {
	 executor.executeScript("arguments[0].scrollIntoView();", submitBtn);	
	 executor.executeScript("arguments[0].click();", submitBtn); 
 }
 
 public void resetBtn() {
		
	 resetBtn.click();
 }
 
 public void clickStandardsComp() {
		
	 clickStandardsComp.click();
 }
 
 public void fieldApp() {
		
	 fieldApp.click();
 }
 
 public void getValueofMaterialClass(String value) {
	 
	 if(materialClass.getAttribute("value").contains(value)){
		 Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		
	 }
 }
 
public void verifyValidationResult(String status) {

	By locator = By.xpath(String.format("//div[contains(text(),'Validation Result')]//following::span[contains(text(),'%s')]", status));
	CommonFunctions.waitVisibilityofElement(locator);
	WebElement el = getDriver().findElement(locator);
	if(el.isDisplayed()) {
		Assert.assertTrue(true);
	}else {
		Assert.assertTrue(false);
	}
}
 
public void getValueofMaterialSubClass(String value) {
	 
	 if(materialSubClass.getAttribute("value").contains(value)){
		 Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		
	 }
 }
 
 public void materialGrade() {
		
	 materialGrade.click();
 }
 
 
 public void materialsPart() {
		
	 materialsPart.click();
 }
 
 public void failureLocationCharac() {
		
	 failureLocationCharac.click();
 }
 
 public void fracturePlaneOrientation() {
		
	 fracturePlaneOrientation.click();
 }
 
 public void clickNextBtn() {
	 CommonFunctions.waitVisibilityofElement(nextBtn);
	 nextBtn.click();
 }
 
 public void lifeCycleInfo(String status) {
	 
	    By locator = By.xpath(String.format("//span[contains(text(),'%s')]", status));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
 }
 
 public void yourSection(String label, String value) {
	 
	    By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::div[contains(text(),'%s')]", label, value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
 }
 
 public void verifyNextSection(String section) {
	 
	 By locator = By.xpath(String.format("//p[contains(text(),'%s')]", section));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
 }
 
 public void selectVisualDamage(List<Map<String, String>> dataTable) {
	 
	 for (Map<String, String> dataRow : dataTable) {
			By locator = By.xpath(String.format("//span[contains(text(),'%s')]", dataRow.get("Option")));
			WebElement ele = getDriver().findElement(locator);
			ele.click();
 }}
 
 public void messageError(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
 
 public void movetoSection(String section) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", section));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
 
 public void suppPH(String value) {
		CommonFunctions.expWaitElementToBeClickable(supppH);
		if(!supppH.getAttribute("value").isEmpty());
		{
			supppH.sendKeys(Keys.CONTROL + "a");
			supppH.sendKeys(Keys.DELETE);
		}
		supppH.sendKeys(value);
		supppH.sendKeys(Keys.ENTER);
		supppH.sendKeys(Keys.TAB);
	}
 
 public void bottomHoleTemp(String value) {
		CommonFunctions.expWaitElementToBeClickable(bottomholeTemp);
		if(!bottomholeTemp.getAttribute("value").isEmpty());
		{
			bottomholeTemp.sendKeys(Keys.CONTROL + "a");
			bottomholeTemp.sendKeys(Keys.DELETE);
		}
		bottomholeTemp.sendKeys(value);
		bottomholeTemp.sendKeys(Keys.ENTER);
		bottomholeTemp.sendKeys(Keys.TAB);
	}
 
 public void bottomholePressure(String value) {
		CommonFunctions.expWaitElementToBeClickable(bottomholePressure);
		if(!bottomholePressure.getAttribute("value").isEmpty());
		{
			bottomholePressure.sendKeys(Keys.CONTROL + "a");
			bottomholePressure.sendKeys(Keys.DELETE);
		}
		bottomholePressure.sendKeys(value);
		bottomholePressure.sendKeys(Keys.ENTER);
		bottomholePressure.sendKeys(Keys.TAB);
	}
 
 public void clickPreviousButton(String section) {
	 
	    By locator = By.xpath(String.format("//span[contains(text(),'%s')]//following::button[@test-id='previous-btn']", section));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
 }
	
}
