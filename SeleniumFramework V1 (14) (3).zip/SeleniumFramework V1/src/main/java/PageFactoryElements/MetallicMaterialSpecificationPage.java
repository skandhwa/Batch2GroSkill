package PageFactoryElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;

public class MetallicMaterialSpecificationPage extends CommonFunctions{

	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();
	public MetallicMaterialSpecificationPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}


	@FindBy(xpath="//button//h5[contains(text(),'Metallic')]")
	WebElement metallic;
	@FindBy(xpath="//input[@id='materialSubclassId']")
	WebElement materialSubClass;
	@FindBy(xpath="//input[@id='materialClassId']")
	WebElement materialClass;
	@FindBy(xpath="//div[@id='specType']")
	WebElement specType;
	@FindBy(xpath="//h5[contains(text(),'Metallic')]//following::a[contains(text(),'Specifications')]")
	List<WebElement> specifications;
	@FindBy(xpath="//a[@href='/material-specifications/v2/metal'] | //a[@href='/material-specifications/metal']")
	WebElement specsBtn;
	@FindBy(xpath="//a[contains(text(), 'Create Material Specification')]")
	WebElement createMateSpecs;
	@FindBy(xpath="//input[@id='unsNumber']")
	WebElement unsNumber;
	@FindBy(xpath="//input[@id='alloyCategory']")
	WebElement NACEalloyCategory;
	@FindBy(xpath="//input[@id='yieldMin']")
	WebElement yieldMin;
	@FindBy(xpath="//input[@id='yieldMax']")
	WebElement yieldMax;
	@FindBy(xpath="//input[@id='hardness1Min']")
	WebElement hardness1Min;
	@FindBy(xpath="//input[@id='hardness1Max']")
	WebElement hardness1Max;
	@FindBy(xpath="//div[@id='hardness1Unit']")
	WebElement hardness1Unit;
	@FindBy(xpath="//input[@id='hardness2Min']")
	WebElement hardness2Min;
	@FindBy(xpath="//input[@id='hardness2Max']")
	WebElement hardness2Max;
	@FindBy(xpath="//div[@id='hardness2Unit']")
	WebElement hardness2Unit;
	@FindBy(xpath="//input[@id='materialConditions']")
	WebElement materialCondition;
	@FindBy(xpath="//input[@id='productForms']")
	WebElement productForm;
	@FindBy(xpath="//p[@id='alert-dialog-description']")
    WebElement messageRTD;
	@FindBy(xpath="//button[contains(text(), 'Ok')]")
	WebElement RTDOKButton;
	@FindBy(xpath="//div[@id='customerId']")
	WebElement customerId;
	@FindBy(xpath="//button[contains(text(),'Supplier')]")
	WebElement supplierTab;
	@FindBy(xpath="//input[@id='supplierName']")
	WebElement supplierName;
	@FindBy(xpath="//button[contains(text(),'Add')]")
	WebElement addButton;
	@FindBy(xpath="//button[@title='Clear']")
	WebElement clearButton;
	@FindBy(xpath="//button[contains(text(),'Ok')]")
	WebElement okButton;
	@FindBy(xpath="//a[contains(text(),'Edit')]")
	WebElement editButton;

	public void materialConditions(String text) {
		executor.executeScript("window.scrollBy(0,300)");
		materialCondition.sendKeys(text);
	}
	
	public void editButton() {

		editButton.click();
	}
	
	public void okButton() {

		okButton.click();
	}
	
	public void clearButton() {

		clearButton.click();
	}
	
	public void supplierName(String text) {
		
			supplierName.click();
			supplierName.sendKeys(Keys.BACK_SPACE);
			supplierName.sendKeys(text);
		
	}
	
	public void addButton() {

		addButton.click();
	}
	
	public void supplierTab() {

		supplierTab.click();
	}

	public void customerId() {

		customerId.click();
	}
	
	public void RTDOKButton() {

		RTDOKButton.click();
	}
	
	public void productForm(String text) {

		productForm.sendKeys(text);
	}
	
	public void messageRTD() {
		CommonFunctions.waitVisibilityofElement(messageRTD);
		if(messageRTD.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	public void deleteSupplier(String value) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]//following::a//*[local-name() = 'svg']", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();

	}
	
	public void countryAndSup(String value) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}
	
	
	public void selectEDRfromEDRSummary(String edr) {

		By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::td//a//*[local-name() = 'svg']", edr ));
		CommonFunctions.waitVisibilityofElement(locator);
		List<WebElement> el = getDriver().findElements(locator);
		switch(edr) {
		case "AGCD":
			el.get(0).click();
			break;
		case "BCD":
			el.get(1).click();
			break;
		case "IWCD":
			el.get(2).click();
			break;
		case "ACD":
			el.get(3).click();
			break;
		case "HFCD":
			el.get(4).click();
			break;
		default:

		}

	}
	
	public void openSpec(String value) {

		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}	

	public void hardness2Unit(String value) {

		hardness2Unit.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();

	}

	public void hardness1Unit(String value) {

		hardness1Unit.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();

	}

	public void materialSubClass(String text) throws InterruptedException {

		materialSubClass.sendKeys(text);
		materialSubClass.sendKeys(Keys.DOWN);
		materialSubClass.sendKeys(Keys.RETURN);

	}

	public void hardness2Max(String text){

		hardness2Max.sendKeys(text);

	}

	public void hardness2Min(String text){

		hardness2Min.sendKeys(text);

	}

	public void hardness1Max(String text){

		hardness1Max.sendKeys(text);

	}

	public void hardness1Min(String text){

		hardness1Min.sendKeys(text);

	}

	public void yieldMin(String text){

		yieldMin.sendKeys(text);
		yieldMin.sendKeys(Keys.RETURN);

	}

	public void yieldMax(String text){

		yieldMax.sendKeys(text);
		yieldMax.sendKeys(Keys.RETURN);

	}

	public void NACEalloyCategory() {

		NACEalloyCategory.click();
	}

	public void unsNumber() {
		CommonFunctions.expWaitElementToBeClickable(unsNumber);
		unsNumber.click();
		unsNumber.sendKeys(Keys.BACK_SPACE);
	}

	public void clickSpecBtn() {

		specsBtn.click();
	}

	public void createMateSpecs() {

		CommonFunctions.waitVisibilityofElement(createMateSpecs);
		createMateSpecs.click();
	}

	public void metallicTab() throws InterruptedException {
		Thread.sleep(4000);
		By locator = By.xpath(String.format("//button[@name='metallic-menu']"));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		Thread.sleep(4000);
	}

	public void clickSpecification() throws InterruptedException {
		try {
			executor.executeScript("arguments[0].click();", specifications.get(1));

		}
		catch(Exception e) {
			System.out.println("Check the Error" + e);
			CommonFunctions.expWaitElementToBeClickable(specifications.get(1));
			specifications.get(1).click();
		}

	}

	public void materialClass(String text) throws InterruptedException {

		materialClass.sendKeys(text);
		materialClass.sendKeys(Keys.DOWN);
		materialClass.sendKeys(Keys.RETURN);

	}

	public void clickMetallic() throws InterruptedException {
		metallic.click();
		Thread.sleep(1000);
	}

	public void clickSpecType() {

		specType.click();
	}
}
