package PageFactoryElements;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import Utilities.CommonFunctions;
import Utilities.MyTestResults;

import Utilities.DriverIntialization;


public class Login {


	MyTestResults testresult = new MyTestResults();
	DriverIntialization obj_driver = new DriverIntialization();
	
	public Logger logger = Logger.getLogger(Login.class);
	
	// Object Repository

	@FindBy(id = "loginControl_UserName")
	WebElement LoginPage_UserName_Editbox;

	@FindBy(id = "loginControl_Password")
	WebElement LoginPage_Password_Editbox;
	
	@FindBy(id = "loginControl_LoginButton")
	WebElement Login_Button;
	
	@FindBy(id = "ctl00_lblNameValue")
	WebElement LoggedIn_UserName;

	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement Welcome_Page;
	
	@FindBy(xpath = "//*[contains(text(),'Pradnesh Pune Test')]//preceding-sibling::td//input[@value='rdbUser']")
	WebElement PradneshPuneTest_Radio;
	
	@FindBy(xpath = "//*[contains(text(),'Capgemini-test')]//preceding-sibling::td//input[@value='rdbUser']")
	WebElement CapgeminiTest_Radio;
	
	@FindBy(xpath = "//*[contains(text(),'Diksha')]//preceding-sibling::td//input[@value='rdbUser']")
	WebElement Diksha_Radio;
	
	@FindBy(id = "ctl00_Main_btnSelTravelDesk")
	WebElement WelcomeOK_Button;
	
	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement CreateRequest_Page;
	
	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement ManageRequest_Page;
	
	@FindBy(linkText = "Create Request")
	WebElement CreateRequest_TabLink;
	
	@FindBy(linkText = "Manage Request")
	WebElement ManageRequest_TabLink;
	
	@FindBy(linkText = "Administration")
	WebElement Administration_TabLink;

	@FindBy(linkText = "Self")
	WebElement Self_Link;
	
	@FindBy(id = "ctl00_Main_lblTitle")
	WebElement CreateTravelRequest_Page;
	
	@FindBy(linkText = "Other Staff")
	WebElement OtherStaff_Link;
	
	@FindBy(linkText = "Non-SLB Staff")
	WebElement NonSLBStaff_Link;
	
	@FindBy(id = "ctl00_Main_lblCancelRequest")
	WebElement CancelRequest;
	
	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement CancelRequestPageTitle;
	
	@FindBy(id = "ctl00_Main_lblBrowseRequest")
	WebElement BrowseRequestLink;
	
	@FindBy(id = "ctl00_Main_lblTitle")
	WebElement BrowseRequestPageTitle;
	
	@FindBy(id = "ctl00_Main_lblAmendRequest")
	WebElement AmendRequestLink;
	
	@FindBy(id = "ctl00_Main_lnkBtnRefundRequest")
	WebElement RefundRequestLink;
	
	@FindBy(id = "ctl00_Main_lnkBtnRefundProcess")
	WebElement RefundProcessLink;
	
	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement AmendRequestPageTitle;
	
	@FindBy(id = "ctl00_Main_lblPageTitle")
	WebElement RefundPageTitle;
	
	/// Constructor
	public Login(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	
	public void LoginApplication(String text)
	{	
		LoginPage_UserName_Editbox.sendKeys(text);
		System.out.println("Entered value in UserName textbox : " + text);
		
		//LoginPage_Password_Editbox.sendKeys(CommonFunctions.encryptdecryptPwd("Bundel@424212"));
		
		LoginPage_Password_Editbox.sendKeys(CommonFunctions.fetch_Password_Value());
		System.out.println("Entered Password in Password textbox");
		
		CommonFunctions.clickBySelenium(Login_Button);
		String fetchedTitle = Welcome_Page.getText();
		Assert.assertEquals("Welcome to e-Travel application", fetchedTitle);
	}
	
	
	public void SelectTravelDesk(String TravelDesk) {
		WebElement web_Radio = null;
		
		switch (TravelDesk.toUpperCase()) {
		case "CAPGEMINI-TEST":
			web_Radio = CapgeminiTest_Radio;
			break;

		case "PRADNESH PUNE TEST":
			web_Radio = PradneshPuneTest_Radio;
			break;
			
		case "DIKSHA":
			web_Radio = Diksha_Radio;
			break;	
			
		}
		
		web_Radio.click();
		CommonFunctions.clickBySelenium(WelcomeOK_Button);
		
		String fetchedTitle = ManageRequest_Page.getText();
		Assert.assertEquals("Manage Request Dashboard", fetchedTitle);
		
	}

	public void SelectTab(String TabName) {
		
		WebElement web_TabName = null;
		String ValidatePageTitle = null;
		WebElement we_PageTitle = null;
		
		switch (TabName.toUpperCase()) {
		case "CREATE REQUEST":
			web_TabName = CreateRequest_TabLink;
			ValidatePageTitle = "Create Request Dashboard";
			we_PageTitle = CreateRequest_Page;
			break;
			
		case "MANAGE REQUEST":
			web_TabName = ManageRequest_TabLink;
			we_PageTitle = ManageRequest_Page;
			ValidatePageTitle = "Manage Request Dashboard";
			break;	
			
		case "ADMINISTRATION":
			web_TabName = Administration_TabLink;
			ValidatePageTitle = "Administration Dashboard";
			we_PageTitle = CreateRequest_Page;
			break;
			
		}
		
		CommonFunctions.clickBySelenium(web_TabName);
		obj_driver.setUpImplicitWait();
		
		String fetchedTitle = we_PageTitle.getText();
		Assert.assertEquals(ValidatePageTitle, fetchedTitle);
		
	}
	
	
	public void SelectBusinessTravel(String BusinessTravel){
		WebElement web_LinkName = null;
		String ValidatePageTitle = null;
		WebElement we_PageTitle = null;
		
		switch (BusinessTravel.toUpperCase()) {
		case "SELF":
			web_LinkName = Self_Link;
			ValidatePageTitle = "Create Travel Request";
			we_PageTitle = CreateTravelRequest_Page;
			break;
			
		case "OTHER STAFF":
			web_LinkName = OtherStaff_Link;
			ValidatePageTitle = "Create Travel Request for SLB Staff";
			we_PageTitle = CreateTravelRequest_Page;
			break;
			
		case "NON-SLB STAFF":
			web_LinkName = NonSLBStaff_Link;
			ValidatePageTitle = "Create Travel Request for non-SLB Staff";
			we_PageTitle = CreateTravelRequest_Page;
			break;	
		}
		
			System.out.println("***********Travel booking type is *************"+BusinessTravel);
			CommonFunctions.clickBySelenium(web_LinkName);
			obj_driver.setUpImplicitWait();
			
			String fetchedTitle = we_PageTitle.getText();
			System.out.println("After Clicking link "+BusinessTravel.toUpperCase()+" Navigated to Page "+fetchedTitle);
			Assert.assertEquals(ValidatePageTitle, fetchedTitle);
			
	}
	
	public void ManageRequestClickLink(String LinkName){

		WebElement web_LinkName = null;
		String ValidatePageTitle = null;
		WebElement we_PageTitle = null;
		
		switch (LinkName.toUpperCase()) {
			
			case "CANCEL REQUEST":
			web_LinkName = CancelRequest;
			ValidatePageTitle = "Cancel Travel Request";
			we_PageTitle = CancelRequestPageTitle;
			break;
	
			case "BROWSE REQUEST":
			web_LinkName = BrowseRequestLink;
			ValidatePageTitle = "Browse Travel Requests";
			we_PageTitle = BrowseRequestPageTitle;
			break;
			
			case "AMEND REQUEST":
			web_LinkName = AmendRequestLink;
			ValidatePageTitle = "Amend Travel Request";
			we_PageTitle = AmendRequestPageTitle;
			break;
			
			case "REQUEST FOR REFUND":
			web_LinkName = RefundRequestLink;
			ValidatePageTitle = "Browse Travel Requests";
			we_PageTitle = RefundPageTitle;
			break;	
			
			case "REFUND PROCESS":
			web_LinkName = RefundProcessLink;
			ValidatePageTitle = "Browse Travel Requests";
			we_PageTitle = RefundPageTitle;
			break;

		}

		System.out.println("Clicked on the Link "+LinkName+" under Manage Request Tab");
		CommonFunctions.clickBySelenium(web_LinkName);
		obj_driver.setUpImplicitWait();
		String fetchedTitle = we_PageTitle.getText();
		Assert.assertEquals(ValidatePageTitle, fetchedTitle);


		}

}