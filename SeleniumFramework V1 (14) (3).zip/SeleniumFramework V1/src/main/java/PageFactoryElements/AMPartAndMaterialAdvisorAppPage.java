package PageFactoryElements;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;

public class AMPartAndMaterialAdvisorAppPage extends CommonFunctions{

	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();
	public AMPartAndMaterialAdvisorAppPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	@FindBy(xpath="//input[@id='yield']")
	WebElement yieldStrength;
	@FindBy(xpath="//div[@id='serviceType']")
	WebElement appType;
	@FindBy(xpath="//input[@id='temperature']")
	WebElement servTemperature;
	@FindBy(xpath="//input[@id='pressure']")
	WebElement pressure;
	@FindBy(xpath="//input[@id='partNumber']")
	WebElement partNumber;
	@FindBy(xpath="//span[contains(text(),'Existing part')]")
	WebElement existingPart;
	@FindBy(xpath="//div[@class='MuiAlert-message css-1xsto0d']")
	WebElement noteMessage;
	@FindBy(xpath="//div[contains(text(),'Dimensions')]")
	WebElement dimensions;
	@FindBy(xpath="//div[contains(text(),'Design & Manufacturing Considerations')]")
	WebElement designManufacturingConsiderations;
	@FindBy(xpath="//div[contains(text(),'Functionality Requirements')]")
	WebElement functionalityRequirements;
	@FindBy(xpath="//input[@id='dimension.length']")
	WebElement dimensionlength;
	@FindBy(xpath="//input[@id='dimension.width']")
	WebElement dimensionwidth;
	@FindBy(xpath="//input[@id='dimension.height']")
	WebElement dimensionheight;
	@FindBy(xpath="//input[@id='dimension.wallThickness']")
	WebElement dimensionwallThickness;
	@FindBy(xpath="//input[@id='manufacturingConsideration.overhang']")
	WebElement overhangs;
	@FindBy(xpath="//input[@id='complianceStandards']")
	WebElement complianceStandards;
	@FindBy(xpath="//h2[contains(text(),'AM Internal Printing Capabilities at Sugar Land campus')]")
	WebElement mtPrintingPopUp;
	@FindBy(xpath="//button[contains(text(),'Yes')]")
	WebElement yesButton;
	@FindBy(xpath="//div[@id='productLine']")
	WebElement productLine;
	@FindBy(xpath="//div[@id='productGroup']")
	WebElement productGroup;
	@FindBy(xpath="//div[@id='function']")
	WebElement function;
	@FindBy(xpath="//div[@id='materialCategory']")
	WebElement materialCategory;
	@FindBy(xpath="//input[@id='projectName']")
	WebElement projectName;
	@FindBy(xpath="//input[@id='desiredLeadTime']")
	WebElement desiredLeadTime;
	@FindBy(xpath="//input[@id='costCenter']")
	WebElement WBS;
	@FindBy(xpath="//input[@id='projectCode']")
	WebElement projectCode;
	@FindBy(xpath="//input[@id='managerEmail']")
	WebElement managerEmail;
	@FindBy(xpath="//div[@class='MuiGrid-root reference-number css-rfnosa']")
	WebElement AMPartReferenceNumber;
	@FindBy(xpath="//a[contains(text(),'New Request')]")
	WebElement newRequest;

	public void complianceStandards() {

		complianceStandards.click();
	}
	
	public void newRequest() {

		newRequest.click();
	}


	public void managerEmail(String name) {

		managerEmail.sendKeys(name);
	}
	
	public String amReferenceNumber() {
		
		return AMPartReferenceNumber.getText();
	}
	
	public void setProjectName(String name) {

		projectName.sendKeys(name);
		projectName.sendKeys(Keys.ENTER);
	}
	
	public void setProjectCode(String name) {

		projectCode.sendKeys(name);
	}
	
	

	public void setWBS(String name) {

		WBS.sendKeys(name);
	}

	public void desiredLeadTime(String name) {

		desiredLeadTime.sendKeys(name);
	}

	public void materialCategory() {

		materialCategory.click();
	}

	public void function() {

		function.click();
	}

	public void productGroup() {
		CommonFunctions.expWaitElementToBeClickable(productGroup);
		productGroup.click();
	}

	public void productLine() throws InterruptedException {

		Thread.sleep(2000);
		CommonFunctions.expWaitElementToBeClickable(productLine);
		if(productLine.isDisplayed()) {
			Assert.assertTrue(true);
			executor.executeScript("arguments[0].click();",productLine);
			CommonFunctions.clickBySelenium(productLine);
		}else {
			Assert.assertTrue(false);
		}

	}

	public void mtPrintingPopUp() {

		CommonFunctions.waitVisibilityofElement(mtPrintingPopUp);
		if(mtPrintingPopUp.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void expandOption(String option) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]//preceding::td", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void legacyCameron(String option) {

		By locator = By.xpath(String.format("//label[contains(text(),'Legacy Cameron')]//following::span[contains(text(),'%s')]", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void cadAndParts(String option) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
	}

	public void yesBtn() {
		CommonFunctions.expWaitElementToBeClickable(yesButton);
		yesButton.click();
	}

	public void dimensionheight(String value) {

		if(!dimensionheight.getAttribute("value").isEmpty());
		{
			dimensionheight.sendKeys(Keys.CONTROL + "a");
			dimensionheight.sendKeys(Keys.DELETE);
		}
		dimensionheight.sendKeys(value);
		dimensionheight.sendKeys(Keys.ENTER);
	}

	public void overhangs(String value) {

		if(!overhangs.getAttribute("value").isEmpty());
		{
			overhangs.sendKeys(Keys.CONTROL + "a");
			overhangs.sendKeys(Keys.DELETE);
		}
		overhangs.sendKeys(value);
		overhangs.sendKeys(Keys.ENTER);
	}

	public void dimensionwallThickness(String value) {

		if(!dimensionwallThickness.getAttribute("value").isEmpty());
		{
			dimensionwallThickness.sendKeys(Keys.CONTROL + "a");
			dimensionwallThickness.sendKeys(Keys.DELETE);
		}
		dimensionwallThickness.sendKeys(value);
		dimensionwallThickness.sendKeys(Keys.ENTER);
	}

	public void dimensionwidth(String value) {

		if(!dimensionwidth.getAttribute("value").isEmpty());
		{
			dimensionwidth.sendKeys(Keys.CONTROL + "a");
			dimensionwidth.sendKeys(Keys.DELETE);
		}
		dimensionwidth.sendKeys(value);
		dimensionwidth.sendKeys(Keys.ENTER);
	}

	public void dimensionlength(String value) {

		if(!dimensionlength.getAttribute("value").isEmpty());
		{
			dimensionlength.sendKeys(Keys.CONTROL + "a");
			dimensionlength.sendKeys(Keys.DELETE);
		}
		dimensionlength.sendKeys(value);
		dimensionlength.sendKeys(Keys.ENTER);
	}

	public void materialInfoAndPartStage(String option) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();

	}
	
	public void materialInfoAndPartStageNotSelected(String option) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(!ele.isSelected()){
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}

	public void additionalFunctionality(List<Map<String, String>> dataTable) throws InterruptedException {


		for (Map<String, String> dataRow : dataTable) {
			By locator = By.xpath(String.format("//span[contains(text(),'%s')]", (dataRow.get("Options"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}

	}

	@SuppressWarnings("rawtypes")
	public void requestInformation(DataTable dt) {
	//	executor.executeScript("window.scrollBy(0,3000)");
		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();

				By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::div[contains(text(),'%s')]", pair.getKey(), pair.getValue()));
				CommonFunctions.expWaitAllElementToBePresent(locator);
				WebElement ele = getDriver().findElement(locator); 
				ele.isDisplayed();
			}
		}
	}


	public void referneceNumber(String number) {
		
		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", number));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}
	
	public void printingService(String string) {
		executor.executeScript("scroll(0, -350);");
		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", string));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}

	public void clickPrintingService(String notes) {

		By locator = By.xpath(String.format("//a[contains(text(),'%s')]", notes));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();
		CommonFunctions.switchToWindow();

	}

	public void displayNotes(String notes) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", notes));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}

	public void selectDesignManufacturingConsiderations(String option) {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", option));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		ele.click();

	}

	public void currentManufacturingProcessAndFuncReq(List<Map<String, String>> dataTable) throws InterruptedException {


		for (Map<String, String> dataRow : dataTable) {
			By locator = By.xpath(String.format("//span[contains(text(),'%s')]", (dataRow.get("Options"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			ele.click();

		}

	}


	public void noteMessage(String message) {

		String[] messageNote = noteMessage.getText().split(": ");
		if(messageNote[1].equalsIgnoreCase(message)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void dimensions() {

		if(dimensions.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void functionalityRequirements() {

		if(functionalityRequirements.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void designManufacturingConsiderations() {

		if(designManufacturingConsiderations.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void messageError(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.expWaitElementToBeClickable(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void partNumber(String value) {

		partNumber.sendKeys(value);
	}


	public void clickappType() {

		appType.click();
	}


	public void displayPartNumber() {
		CommonFunctions.expWaitElementToBeClickable(partNumber);
		if(partNumber.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void displayYieldStrength() {
		CommonFunctions.expWaitElementToBeClickable(yieldStrength);
		if(yieldStrength.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void enterYieldStrength(String value) {
		CommonFunctions.expWaitElementToBeClickable(yieldStrength);
		if(!yieldStrength.getAttribute("value").isEmpty());
		{
			yieldStrength.sendKeys(Keys.CONTROL + "a");
			yieldStrength.sendKeys(Keys.DELETE);
		}
		yieldStrength.sendKeys(value);
		yieldStrength.sendKeys(Keys.ENTER);
	}

	public void servTemperature(String value) {
		CommonFunctions.expWaitElementToBeClickable(servTemperature);
		if(!servTemperature.getAttribute("value").isEmpty());
		{
			servTemperature.sendKeys(Keys.CONTROL + "a");
			servTemperature.sendKeys(Keys.DELETE);
		}
		servTemperature.sendKeys(value);
		servTemperature.sendKeys(Keys.ENTER);
	}

	public void servPressure(String value) {
		CommonFunctions.expWaitElementToBeClickable(pressure);
		if(!pressure.getAttribute("value").isEmpty());
		{
			pressure.sendKeys(Keys.CONTROL + "a");
			pressure.sendKeys(Keys.DELETE);
		}
		pressure.sendKeys(value);
		pressure.sendKeys(Keys.ENTER);
	}



}
