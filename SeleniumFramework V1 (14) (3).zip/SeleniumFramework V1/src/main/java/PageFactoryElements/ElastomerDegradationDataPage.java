package PageFactoryElements;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ElastomerDegradationDataPage extends CommonFunctions{
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();


	public ElastomerDegradationDataPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}


	@FindBy(xpath="//input[@id='complianceStandards']")
	WebElement complianceStandards;
	@FindBy(xpath="//div[@id='eedd.h2sPressureAcceptable']")
	WebElement h2sPressureAcceptable;
	@FindBy(xpath="//div[@id='eedd.h2sPressureLimitAvailable']")
	WebElement h2sPressureLimitAvailable;
	@FindBy(xpath="//div[@id='eedd.h2sTempApplicable']")
	WebElement h2sTempApplicable;
	@FindBy(xpath="//input[@id='eedd.h2sPressureMax']")
	WebElement maxAllowableH2S;
	@FindBy(xpath="//input[@id='eedd.h2sTempMax']")
	WebElement h2sTempMax;
	@FindBy(xpath="//div[@id='eedd.co2PressureAcceptable']")
	WebElement co2Acceptable;
	@FindBy(xpath="//div[@id='eedd.co2PressureLimitAvailable']")
	WebElement co2Limit;
	@FindBy(xpath="//div[@id='eedd.co2TempApplicable']")
	WebElement tempForCO2;
	@FindBy(xpath="//input[@id='eedd.co2PressureMax']")
	WebElement maxAllowableCO2;
	@FindBy(xpath="//input[@id='eedd.co2TempMax']")
	WebElement co2TempMax;
	@FindBy(xpath="//div[@id='eedd.wbmAcceptable']")
	WebElement wbmAcceptable;
	@FindBy(xpath="//div[@id='eedd.wbmTempApplicable']")
	WebElement wbmTempApplicable;
	@FindBy(xpath="//input[@id='eedd.wbmTempMax']")
	WebElement wbmTempMax;
	@FindBy(xpath="//div[@id='eedd.amineAcceptable']")
	WebElement amineAcceptable;
	@FindBy(xpath="//div[@id='eedd.amineTempApplicable']")
	WebElement amineTempApplicability;
	@FindBy(xpath="//input[@id='eedd.amineTempMax']")
	WebElement amineTempMax;
	@FindBy(xpath="//a[contains(text(),'Clone')]")
	WebElement cloneBtn;
	@FindBy(xpath="//button[contains(text(),'Delete')]")
	List<WebElement> deleteBtn;
	@FindBy(xpath="//h4[@class='MuiTypography-root MuiTypography-h4 edr-view-title css-1xvinid']")
	WebElement recordUID;
	@FindBy(xpath="//button[contains(text(),'Save')]")
	WebElement saveBtn;
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	List<WebElement> submitBtn;
	@FindBy(xpath="//textarea[@id='standard-multiline-static']")
	WebElement commentBox;
	@FindBy(xpath="//button[contains(text(),'Decline')]")
	List<WebElement> declineBtn;
	@FindBy(xpath="//button[contains(text(),'Approve')]")
	List<WebElement> approveBtn;
	@FindBy(xpath="//*[local-name() = 'svg']")
	List<WebElement> notificationClose;
	@FindBy(xpath="//button[contains(text(),'Obsolete')]")
	List<WebElement> obsoleteBtn;
	@FindBy(xpath="//button[contains(text(),'Reactivate')]")
	List<WebElement> reactivateBtn;
	@FindBy(xpath="//div[@id='eacd.hclAcceptable']")
	WebElement hclAcceptable;
	@FindBy(xpath="//div[@id='eacd.hclTempApplicable']")
	WebElement hclTempApplicable;
	@FindBy(xpath="//input[@id='eacd.hclTempMax']")
	WebElement hclTempMax;
	@FindBy(xpath="//div[@id='eacd.hfAcceptable']")
	WebElement hfAcceptable;
	@FindBy(xpath="//div[@id='eacd.hfTempApplicable']")
	WebElement hfTempApplicable;
	@FindBy(xpath="//input[@id='eacd.hfTempMax']")
	WebElement hfTempMax;
	@FindBy(xpath="//div[@id='eacd.aceticAcidAcceptable']")
	WebElement aceticAcidAcceptable;
	@FindBy(xpath="//div[@id='eacd.aceticAcidTempApplicable']")
	WebElement aceticAcidTempApplicable;
	@FindBy(xpath="//input[@id='eacd.aceticAcidTempMax']")
	WebElement aceticAcidTempMax;


	public void hfTempMax(String value, String message) {

		hfTempMax.sendKeys(value);
		hfTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}


	public void aceticAcidTempMax(String value, String message) {

		aceticAcidTempMax.sendKeys(value);
		aceticAcidTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void aceticAcidAcceptable(String value) {

		aceticAcidAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(aceticAcidAcceptable.getText().equalsIgnoreCase("Yes")) {
			aceticAcidTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void aceticAcidTempApplicable(String value) throws InterruptedException {

		aceticAcidTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(aceticAcidTempApplicable.getText().equalsIgnoreCase("Yes")) {
			aceticAcidTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 
		//executor.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);

	}

	public void hclTempMax(String value, String message) {

		hclTempMax.sendKeys(value);
		hclTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void hfTempApplicable(String value) {

		hfTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(hfTempApplicable.getText().equalsIgnoreCase("Yes")) {
			hfTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}


	public void hclTempApplicable(String value) {

		hclTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(hclTempApplicable.getText().equalsIgnoreCase("Yes")) {
			hclTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}


	public void hfAcceptable(String value) {

		hfAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(hfAcceptable.getText().equalsIgnoreCase("Yes")) {
			hfTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void hclAcceptable(String value) {

		hclAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(hclAcceptable.getText().equalsIgnoreCase("Yes")) {
			hclTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}


	public String getRecordUID() {
		if(recordUID.getText()!=null) {
			Assert.assertTrue(true);
		}
		return recordUID.getText();

	}

	public void closeNotification() throws InterruptedException {
		CommonFunctions.waitVisibilityofElement(notificationClose.get(2));
		notificationClose.get(2).click();
		Thread.sleep(10000);
	}

	public void reactivateBtn() {
		try {
			Thread.sleep(5000);
			reactivateBtn.get(0).click();}
		catch(Exception e) {
			reactivateBtn.get(1).click();
		}
	}

	public void obsoleteBtn() {
		try {
			Thread.sleep(5000);
			obsoleteBtn.get(0).click();}
		catch(Exception e) {
			obsoleteBtn.get(1).click();
		}
	}

	public void approveBtn() {
		try {
			Thread.sleep(5000);
			approveBtn.get(0).click();}
		catch(Exception e) {
			approveBtn.get(1).click();
		}
	}

	public void declineBtn() throws InterruptedException {

		try {
			Thread.sleep(15000);
			if(declineBtn.get(0).isDisplayed()) {
				declineBtn.get(0).click();}}
		catch(Exception e) {
			if(declineBtn.get(1).isDisplayed()) {
				declineBtn.get(1).click();}
		}
	}

	public void enterComment(String message)
	{
		commentBox.sendKeys(message);
	}


	public void clickSubmit() {
		try {

			submitBtn.get(0).click();}
		catch(Exception e) {
			submitBtn.get(1).click();
		}
	}

	public void saveBtn() throws InterruptedException {
		try {
			executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			executor.executeScript("arguments[0].click();", saveBtn);}
		catch(Exception e) {
			CommonFunctions.waitVisibilityofElement(saveBtn);
			executor.executeScript("arguments[0].click();", saveBtn);;
		}
	}

	public void deleteBtn() {
		try {
			deleteBtn.get(0).click();
		}catch(Exception e) {
			deleteBtn.get(1).click();	
		}
	}

	public void cloneBtn() {

		cloneBtn.click();
	}

	public void recordonEDDpage(String option, String value) {

		String[] split = value.split("revision");
		String recordUID = split[0];
		By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::a[contains(text(),'%s')]", option, recordUID));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void complianceStandards(String text) throws InterruptedException {

		complianceStandards.sendKeys(text);
		complianceStandards.sendKeys(Keys.DOWN);
		complianceStandards.sendKeys(Keys.RETURN);

	} 

	public void Status(String value) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", value));
		CommonFunctions.expWaitAllElementToBePresent(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		} 

	}

	public void amineAcceptable(String value) {

		amineAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(amineAcceptable.getText().equalsIgnoreCase("Yes")) {
			amineTempApplicability.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void deletemessageNotification(String page) {
		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", page));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void clickOnpagetoNavigate(String page) {
		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", page));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
	}

	public void activityMessage(String message) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void amineTempApplicability(String value) {

		amineTempApplicability.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(amineTempApplicability.getText().equalsIgnoreCase("Yes")) {
			amineTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}  


	public void amineTempMax(String value, String message) {

		amineTempMax.sendKeys(value);
		amineTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void wbmTempMax(String value, String message) {

		wbmTempMax.sendKeys(value);
		wbmTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void wbmAcceptable(String value) {

		wbmAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(wbmAcceptable.getText().equalsIgnoreCase("Yes")) {
			wbmTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void wbmTempApplicable(String value) {

		wbmTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(wbmTempApplicable.getText().equalsIgnoreCase("Yes")) {
			wbmTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void tempForCO2(String value) {

		tempForCO2.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(tempForCO2.getText().equalsIgnoreCase("Yes")) {
			h2sPressureLimitAvailable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void edrVerifyonSummaryPage() {
			By locator = By.xpath(String.format("//span[contains(text(),'BCD')]//following::a[starts-with(@href,'/material-specifications/')]"));
			List<WebElement> el = getDriver().findElements(locator);
			try {
				el.get(1).isDisplayed();
				Assert.assertTrue(true);
			}catch(Exception e) {
							
			}
	}

	public void mandatorymessages(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void co2TempMax(String value, String message) {

		co2TempMax.sendKeys(value);
		co2TempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void maxAllowableCO2(String value, String message) {

		maxAllowableCO2.sendKeys(value);
		maxAllowableCO2.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void h2sAcceptable(String value) {

		h2sPressureAcceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(h2sPressureAcceptable.getText().equalsIgnoreCase("Yes")) {
			h2sPressureLimitAvailable.isDisplayed();
			h2sTempApplicable.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void CO2Limit(String value) {

		co2Limit.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(co2Limit.getText().equalsIgnoreCase("Yes")) {
			maxAllowableCO2.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void CO2Acceptable(String value) {

		co2Acceptable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(co2Acceptable.getText().equalsIgnoreCase("Yes")) {
			co2Limit.isDisplayed();
			tempForCO2.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void setmaxAllowableH2S(String value, String message) {

		maxAllowableH2S.sendKeys(value);
		maxAllowableH2S.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void seth2sTempMax(String value, String message) {

		h2sTempMax.sendKeys(value);
		h2sTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}


	public void h2sPressureLimitAvailable(String value) {

		h2sPressureLimitAvailable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(h2sPressureLimitAvailable.getText().equalsIgnoreCase("Yes")) {
			maxAllowableH2S.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void h2sTempApplicable(String value) {

		h2sTempApplicable.click();
		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", value));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		el.click();
		if(h2sTempApplicable.getText().equalsIgnoreCase("Yes")) {
			h2sTempMax.isDisplayed();
			Assert.assertTrue(true);
		} 

	}

	public void verifySpec(String name) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", name));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void verifyDataOnEDD(DataTable dt) {
		List<Map<String, String>> data =  dt.asMaps();
		for (Map<String, String> listItem : data) {
			Iterator it = listItem.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::div[contains(text(),'%s')]", pair.getKey(), pair.getValue()));
				CommonFunctions.waitVisibilityofElement(locator);
				WebElement el = getDriver().findElement(locator);
				if(el.isDisplayed()) {
					Assert.assertTrue(true);
				}else {
					Assert.assertTrue(false);
				}
			}
		}	
	}

}
