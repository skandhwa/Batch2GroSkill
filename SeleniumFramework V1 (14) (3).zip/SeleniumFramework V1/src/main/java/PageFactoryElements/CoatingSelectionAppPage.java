package PageFactoryElements;
/**
 * 
 * @author Ethesh Gaur
 */

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.Console;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import Utilities.MyTestResults;
import io.cucumber.datatable.DataTable;


public class CoatingSelectionAppPage extends CommonFunctions{
	static MyTestResults results = new MyTestResults();
	JavascriptExecutor executor = (JavascriptExecutor) DriverIntialization.getDriver();
	//	public static WebDriver driver;


	//Service Information Objects
	@FindBy(xpath="//div[@id='productLine']")
	WebElement productline; 
	@FindBy(xpath="//div[@id='serviceTypeId' or @id='productCenter']")
	WebElement serviceTypeProductCenter;
	@FindBy(xpath="//div[@id='productCenter']")
	WebElement productCenter;
	@FindBy(xpath="//div[@id='businessPurpose']")
	WebElement businessPurpose;
	@FindBy(xpath="//input[@id='serviceTemperature']")
	WebElement serviceTemp;
	@FindBy(xpath="//button[contains(text(), 'Show Coating Options')]")
	WebElement showCoatingoptionsBTN;
	@FindBy(xpath="//div[contains(text(),'Coating Selection')]")
	WebElement coatingSelectioSection;

	//Material Information Objects

	@FindBy(xpath="//input[@name='materialSubClass']")
	WebElement materialSubClass;
	@FindBy(xpath="//input[@name='materialClass']")
	WebElement materialClass;
	@FindBy(xpath="//input[@id='materialGrade']")
	WebElement baseMaterial;
	@FindBy(xpath="//input[@name='yieldMin']")
	WebElement yieldStr;
	@FindBy(xpath="//input[@name='heatTreatTemperature']")
	WebElement finalMaxHeat;
	@FindBy(xpath="//span[contains(text(),'Cold Worked Materials?')]")
	WebElement ColdWM;
	@FindBy(xpath="//input[@name='genernalCoatingFeature' and @value='Thread']")
	WebElement coatingFeature;
    @FindBy(xpath="//input[@id='thread-breakUp']")
	WebElement threadBreakup;
	@FindBy(xpath="//input[@id='thread-threadName']")
	WebElement threadName;

	@FindBy(xpath="//div[contains(text(),'Coating Recommendation')]")
	WebElement coatingRecSection;
	@FindBy(xpath="//input[@name='cylindericalParts.partLength']")
	WebElement partLength;
	@FindBy(xpath="//input[@id='cylindericalParts-insideDiameterMin']")
	WebElement insideDiaMin;

	@FindBy(xpath="//input[@name='environmentalOptionsRequired']")
	WebElement envReq;
	@FindBy(xpath="//input[@name='downhole.h2sPartialPressure']")
	WebElement h2sPartialPressure;
	@FindBy(xpath="//input[@name='downhole.co2PartialPressure']")
	WebElement co2PartialPressure;
	@FindBy(xpath="//input[@name='downhole.chlorides']")
	WebElement chlorides;

	@FindBy(xpath="//input[@name='functionalOptionsRequired']")
	WebElement functionalRequirements;
	@FindBy(xpath="//input[@name='specialOptionsRequired']")
	WebElement specialOptionsRequired;
	//Specific Coating Features
	@FindBy(xpath="//input[@name='specificOptionsRequired']")
	WebElement specificCoatingfeat;
	@FindBy(xpath="//input[@id='heatTreatTemperature']")
	WebElement finalHeatTreatTemp;
	@FindBy(xpath="//span[@class='MuiLinearProgress-bar MuiLinearProgress-barColorPrimary MuiLinearProgress-bar2Indeterminate css-tl4bwb']")
    WebElement hydraulicLine;
	@FindBy(xpath="//h2[@id='confirmation-dialog-title']")
	WebElement resetPopUp;
    @FindBy(xpath="//input[@name='selection-box']")
	List<WebElement> selectionBox;
	@FindBy(xpath="//input[@name='selection-box']//following::h6")
	List<WebElement> expandOption;
	@FindBy(xpath="//div[contains(text(),'Coating Selection Reference')]//following::div[@class='MuiGrid-root reference-number css-rfnosa']")
	WebElement csrNumber;
	@FindBy(xpath="//div[@class='MuiTypography-root MuiTypography-h5 css-vh421m']")
	WebElement csrNumberinPrintPage;
	@FindBy(xpath="//*[contains(text(),'Coating Comparison')]")
	WebElement coatingCoparison;


	public CoatingSelectionAppPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}
	
	
	//Action methods

	/**
	 * 
	 * Selection options like Blind Hole, Anchoring Profile Selective Surface Coating and Sealing Surface
	 * @param options
	 * @throws InterruptedException
	 */ 
	public void selectfromSpecificCoatingFeatures(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.clickRadioBTN(ele);

	}


	public void selectmultOptions(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", ele);

	}

	

	/**
	 * 
	 * Thread Area and General Coating Features
	 * @param options
	 * @throws InterruptedException
	 */
	public boolean displayCoatingRecommendationSection() {
        CommonFunctions.waitVisibilityofElement(coatingRecSection);
		if(coatingRecSection.isDisplayed()) {
			Assert.assertTrue(true);
			return true;
		}else {
			Assert.assertTrue(false);
		}
		return false;

	}

	public boolean displayCoatingComparison() {

		if(coatingCoparison.isDisplayed()) {
			Assert.assertTrue(true);
			return true;
		}else {
			Assert.assertTrue(false);
		}
		return false;

	}
	
	public void clickLink(String link, String coatingName) throws InterruptedException {
		
		By locator = By.xpath(String.format("//h6[contains(text(),'%s')]//following::a[contains(text(),'%s')]", coatingName, link));
		WebElement ele = getDriver().findElement(locator);
		executor.executeScript("arguments[0].click();", ele);
		Thread.sleep(3000);
				
	}

	public void clickBTNonRecommendScr(String button) throws InterruptedException {
		
		try {
			By locator = By.xpath(String.format("//button[contains(text(),'%s')]", button));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement ele = getDriver().findElement(locator);
			executor.executeScript("arguments[0].click();", ele);
			
		}catch (Exception e) {

		}

	}

	public void confidentialMessage(String message) throws InterruptedException {
 
		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}


	}

	public String fetchCSRNumber() {

		return csrNumber.getText();


	}

	public String csrNumberinPrintPage() {

		CommonFunctions.waitVisibilityofElement(csrNumberinPrintPage);
		String ss = csrNumberinPrintPage.getText();
		String arr[] = ss.split(" ", 2);
		String firstWord = arr[0];
		return firstWord;
	}

	public void selectBox(String n) throws InterruptedException {
		//int len = selectionBox.size();
		try {
			if(n.equals("3")) {
				executor.executeScript("arguments[0].click();", selectionBox.get(0));
				executor.executeScript("arguments[0].click();", selectionBox.get(1));
				executor.executeScript("arguments[0].click();", selectionBox.get(3));
			} if(n.equals("2")) {
				executor.executeScript("arguments[0].click();", selectionBox.get(0));
				executor.executeScript("arguments[0].click();", selectionBox.get(1));
			}if(n.equals("1")) {
				executor.executeScript("arguments[0].click();", selectionBox.get(0));
			}}
		catch (Exception e) {

		}
	}

	public void expandOption(int n) {

		executor.executeScript("arguments[0].click();", expandOption.get(n-1));

	}

	public boolean resetPopUp() {
		CommonFunctions.waitVisibilityofElement(resetPopUp);
		if(resetPopUp.isDisplayed()) {
			return true;
		}
		else return false;
	}

	public boolean CoatingSelection() {
		CommonFunctions.waitVisibilityofElement(coatingSelectioSection);
		if(coatingSelectioSection.isDisplayed()) {
			return true;
		}
		else return false;
	}

	public boolean resetPopupMessage(String message) {

		By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			return true;
		}else return false;
	}
	
	public void verifySupplierInfoTable(List<Map<String, String>> dataTable) {

		for (Map<String, String> dataRow : dataTable) {
			By locator = By.xpath(String.format("//td[contains(text(),'%s')]", (dataRow.get("Coating Specification"))));
			By locator2 = By.xpath(String.format("//td[contains(text(),'%s')]", (dataRow.get("Description"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			WebElement ele2 = getDriver().findElement(locator2);
		  if(ele.isDisplayed() && ele2.isDisplayed()) {
			Assert.assertTrue(true);
		  }
		  else {
			Assert.assertTrue(false);
		 }
		 }
	}


	public void verifyDatailCompare(List<Map<String, String>> dataTable) throws InterruptedException {

		
		for (Map<String, String> dataRow : dataTable) {
			//CommonFunctions.clickBySelenium(productline);
			By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::td[contains(text(),'%s')]", (dataRow.get("Fields")), (dataRow.get("Data"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
			Thread.sleep(3000);

		}

	}
	
     public void verifyDatailReport(List<Map<String, String>> dataTable) throws InterruptedException {

		
		for (Map<String, String> dataRow : dataTable) {
			//CommonFunctions.clickBySelenium(productline);
			By locator = By.xpath(String.format("//h6[contains(text(),'%s')]", (dataRow.get("Coating Name"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			By locator2=By.xpath(String.format("//span[contains(text(),'%s')]", (dataRow.get("Coating Specification Description"))));
			WebElement ele2 = getDriver().findElement(locator2);
			By locator3 =By.xpath(String.format("//div[contains(text(),'%s')]", (dataRow.get("Chemical Compostion"))));
			WebElement ele3 = getDriver().findElement(locator3);
			//By locator4=By.xpath(String.format("//li[contains(text(),'%s')]", (dataRow.get("Notes"))));
			//WebElement ele4 = getDriver().findElement(locator4);
			//By locator5 = By.xpath(String.format("//h6[contains(text(),'%s')]//span[contains(text(),'%s')]", (dataRow.get("Coating Name")), (dataRow.get("Process"))));
		//	WebElement ele5 = getDriver().findElement(locator5);
		/**	if(ele.isDisplayed() && ele2.isDisplayed() && ele3.isDisplayed() && ele4.isDisplayed() && ele5.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}**/
			
		}

	}
	
	
     public void verifyDatailComparewith2(List<Map<String, String>> dataTable) throws InterruptedException {

		
		for (Map<String, String> dataRow : dataTable) {
			//CommonFunctions.clickBySelenium(productline);
			By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::td[contains(text(),'%s')]//following::td[contains(text(),'%s')]", 
					(dataRow.get("Fields")), (dataRow.get("Data")), (dataRow.get("Data2"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
			Thread.sleep(3000);

		}

	}
     
     public void verifyDatailComparewith(List<Map<String, String>> dataTable, String n) throws InterruptedException {

 		
 		for (Map<String, String> dataRow : dataTable) {
 			//CommonFunctions.clickBySelenium(productline);
 			By locator = By.xpath(String.format("//th[contains(text(),'%s')]//following::td[contains(text(),'%s')]//following::td[contains(text(),'%s')]//following::td[contains(text(),'%s')]", 
 					(dataRow.get("Fields")), (dataRow.get("Data")), (dataRow.get("Data2")), (dataRow.get("Data3"))));
 			CommonFunctions.expWaitAllElementToBePresent(locator);
 			WebElement ele = getDriver().findElement(locator);
 			if(ele.isDisplayed()){
 				Assert.assertTrue(true);
 			}else {
 				Assert.assertTrue(false);
 			}
 			Thread.sleep(3000);

 		}

 	}

	public void verifyProductLine(List<Map<String, String>> dataTable) throws InterruptedException {


		for (Map<String, String> dataRow : dataTable) {
			CommonFunctions.clickBySelenium(productline);
			selectOptions(dataRow.get("Product Line"));
			By locator = By.xpath(String.format("//label[contains(text(),'%s')]", (dataRow.get("Option"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
			Thread.sleep(3000);

		}
	}
	
	
	public void clickspecialOptionsRequired() {

		CommonFunctions.waitVisibilityofElement(specialOptionsRequired);
		specialOptionsRequired.click();
	}

	public void clickfunctionalReq() {

		CommonFunctions.waitVisibilityofElement(functionalRequirements);
		functionalRequirements.click();
	}

	public void seth2sPartialPressure(String value) {

		h2sPartialPressure.sendKeys(value);
	}

	public void setco2PartialPressure(String value) {

		co2PartialPressure.sendKeys(value);
	}

	public void setChlorides(String value) {

		chlorides.sendKeys(value);
	}

	public void clickEnvReq() throws InterruptedException {

		executor.executeScript("arguments[0].click();", envReq);

	}	

	public void setInsideDiaMin(String dia) throws InterruptedException {

		insideDiaMin.clear();
		insideDiaMin.sendKeys(dia);
		insideDiaMin.sendKeys(Keys.RETURN);
	}

	public void clearinsideDiaMin() {

		while (!insideDiaMin.getAttribute("value").isEmpty())

			insideDiaMin.sendKeys(Keys.BACK_SPACE);

	}

	public void setPartLen(String len) {

		partLength.clear();
		partLength.sendKeys(len);
		partLength.sendKeys(Keys.RETURN);
	}

	public void clearPartLen() {

		while (!partLength.getAttribute("value").isEmpty())

			partLength.sendKeys(Keys.BACK_SPACE);

	}

	public void clickSCoatingF() throws InterruptedException {

		executor.executeScript("arguments[0].click();",specificCoatingfeat);
		//specificCoatingfeat.click();
	}

	public void selectGeneralCoatingFeatures(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		Thread.sleep(4000);
		CommonFunctions.clickRadioBTN(ele);

	}


	public void threadArea(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//input[@name='thread.threadArea' and @value='%s']", options));
		WebElement ele = getDriver().findElement(locator);
		Thread.sleep(2000);
		CommonFunctions.clickRadioBTN(ele);

	}

	public void setThreadBreak(String breakno) {

		threadBreakup.clear();
		threadBreakup.sendKeys(breakno);
		threadBreakup.sendKeys(Keys.RETURN);
	}

	public void clearThreadBreak() {

		while (!threadBreakup.getAttribute("value").isEmpty())

			threadBreakup.sendKeys(Keys.BACK_SPACE);
	}


	public void threadType(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//input[@name='thread.threadType' and @value='%s']", options));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.clickRadioBTN(ele);

	}

	public void insideDiaCoating(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//input[@name='cylindericalParts.insideDiameterCoating' and @value='%s']", options));
		WebElement ele = getDriver().findElement(locator);
		Thread.sleep(2000);
		CommonFunctions.clickRadioBTN(ele);

	}

	public void outSideDiaCoating(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//input[@name='cylindericalParts.outsideDiameterCoating' and @value='%s']", options));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.clickRadioBTN(ele);

	}

	public void setThreadName(String name) throws InterruptedException {
		
		threadName.clear();
        Thread.sleep(2000);
		CommonFunctions.clickBySelenium(threadName);
		threadName.sendKeys(name);
		threadName.sendKeys(Keys.DOWN);
		threadName.sendKeys(Keys.ENTER);
	}
	
	public void verifyThreadName(String name) {
				
		if(name.equals(threadName.getAttribute("value"))) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
		
				
	}

	public void clickpLine() {

		CommonFunctions.expWaitElementToBeClickable(productline);
		CommonFunctions.clickBySelenium(productline);

	}

	public void verifyProductlineinPrintPage(String ss) {

		By locator = By.xpath(String.format("//td[contains(text(),'%s')]", ss));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	public void verifySpecialNotes(String ss) {

		By locator = By.xpath(String.format("//div[contains(text(),'%s')]", ss));
		WebElement ele = getDriver().findElement(locator);
		if(ele.isDisplayed()) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

	public void clickShowCoatingoptionsBTN() {

		CommonFunctions.waitVisibilityofElement(showCoatingoptionsBTN);
		CommonFunctions.clickBySelenium(showCoatingoptionsBTN);

	}

	public void setTemp(String temp) throws InterruptedException {

		//CommonFunctions.clickBySelenium(serviceTemp);
		serviceTemp.clear();
		serviceTemp.sendKeys(temp);
		serviceTemp.sendKeys(Keys.RETURN);
		Thread.sleep(2000);

	} 

	public void clearfinalHeatTreatTemp() {

		while (!finalMaxHeat.getAttribute("value").isEmpty())

			finalMaxHeat.sendKeys(Keys.BACK_SPACE);
	}

	public void clearTemp() {

		while (!serviceTemp.getAttribute("value").isEmpty())

			serviceTemp.sendKeys(Keys.BACK_SPACE);


	}

	public void setYieldS(String yield) {

		yieldStr.clear();
		yieldStr.sendKeys(yield);

	}

	public void setfinalMaxHeat(String maxHeat) {

		finalMaxHeat.clear();
		finalMaxHeat.sendKeys(maxHeat);
		finalMaxHeat.sendKeys(Keys.RETURN);

	}

	public void clickProductCenter() {

		CommonFunctions.clickBySelenium(productCenter);
	}
	
	public void clickbusinessPurpose() {

		CommonFunctions.clickBySelenium(businessPurpose);
	}

	public void selectProductCenterServiceType(String options) throws InterruptedException {

		By locator = By.xpath(String.format("//span[contains(text(),'%s')]", options));
		WebElement ele = getDriver().findElement(locator);
		CommonFunctions.clickRadioBTN(ele);

	}

	public void clickServiceType() {

		CommonFunctions.clickBySelenium(serviceTypeProductCenter);
	}

	public void selectOptions(String apps) throws InterruptedException {

		By locator = By.xpath(String.format("//li[contains(text(),'%s')]", apps));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		CommonFunctions.clickBySelenium(el);

	}
	
	public void verifyOptions(List<Map<String, String>> dt) throws InterruptedException {

				
		for (Map<String, String> dataRow : dt) {
		
			By locator = By.xpath(String.format("//li[contains(text(),'%s')]", (dataRow.get("Data"))));
			CommonFunctions.expWaitAllElementToBePresent(locator);
			WebElement ele = getDriver().findElement(locator);
			if(ele.isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}

	}

	public void errorMessages(String field, String message) throws InterruptedException {

		By locator = By.xpath(String.format("//label[contains(text(),'%s')]//following::p[contains(text(), '%s')]", field, message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);	
		}

	}

	public void setBaseMaterial(String name) {

		CommonFunctions.clickBySelenium(baseMaterial);
		baseMaterial.sendKeys(name);
		baseMaterial.sendKeys(Keys.DOWN);
		baseMaterial.sendKeys(Keys.ENTER);
	}
	
	public void clearBaseMaterial() {
		
		baseMaterial.clear();
	}

	public void ClickColdWB(String onOff) {
		CommonFunctions.expWaitElementToBeClickable(ColdWM);
		if(onOff.equalsIgnoreCase("On")) {
			ColdWM.click();
			}

	}

	public void errorMessageFields(String message) {

		By locator = By.xpath(String.format("//p[contains(text(), '%s')]", message));
		CommonFunctions.waitVisibilityofElement(locator);
		WebElement el = getDriver().findElement(locator);
		if(el.isDisplayed()) {
			Assert.assertTrue(true);}
		else {
			Assert.assertTrue(false);	
		}
	}
	
	public void messageDisappeared(String message) {
		
		try
		{
			By locator = By.xpath(String.format("//p[contains(text(), '%s')]", message));
			WebElement el = getDriver().findElement(locator);
			el.isDisplayed();
		} 
		catch(NoSuchElementException error)
		{
		    logger.error("Element does not exist!");
		    Assert.assertTrue(true);
		}
	}

	public void materialSubClass(String option) {

		String matSubCl=materialSubClass.getAttribute("value");
		materialSubClass.click();
		if(option.equals(matSubCl)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}


	public void materialClass(String option) {

		String matClass=materialClass.getAttribute("value");
		if(option.equals(matClass)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}

    public void displayHydraulicLine() {
    	
    	CommonFunctions.waitVisibilityofElement(hydraulicLine);
    	if(hydraulicLine.isDisplayed()) {
    		Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
    	
    }


}
