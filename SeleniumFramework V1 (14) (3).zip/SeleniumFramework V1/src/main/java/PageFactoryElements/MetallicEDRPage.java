package PageFactoryElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Utilities.CommonFunctions;

public class MetallicEDRPage extends CommonFunctions {


	public MetallicEDRPage (WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//input[@id='magcd.naceReference']")
	WebElement naceRef;
	@FindBy(xpath="//input[@id='magcd.tempMin']")
	WebElement tempMin;
	@FindBy(xpath="//input[@id='magcd.tempMax']")
	WebElement tempMax;
	@FindBy(xpath="//input[@id='magcd.h2sPartialPressureMax']")
	WebElement h2sPartialPressureMax;
	@FindBy(xpath="//input[@id='magcd.co2PartialPressureMax']")
	WebElement co2PartialPressureMax;
	@FindBy(xpath="//input[@id='magcd.chloridesMax']")
	WebElement chloridesMax;
	@FindBy(xpath="//input[@id='magcd.phMin']")
	WebElement phMin;
	@FindBy(xpath="//input[@id='magcd.phMax']")
	WebElement phMax;
	@FindBy(xpath="//input[@id='magcd.waterCutMax']")
	WebElement waterCutMax;
	@FindBy(xpath="//input[@id='magcd.mercuryMax']")
	WebElement mercuryMax;
	@FindBy(xpath="//div[@id='magcd.sulfurResistant']")
	WebElement sulfurResistant;
	@FindBy(xpath="//div[@id='magcd.stressCondition']")
	WebElement stressCondition;
	@FindBy(xpath="//input[@id='magcd.maxTensileStress']")
	WebElement maxTensileStress;
	@FindBy(xpath="//input[@id='mbcd.brineId']")
	WebElement brineDesc;
	@FindBy(xpath="//input[@id='mbcd.tempMax']")
	WebElement accpTemp;
	@FindBy(xpath="//div[@id='mbcd.stressCondition']")
	WebElement stressConditionBCD;
	@FindBy(xpath="//input[@id='mbcd.tensileStressMax']")
	WebElement maxTensileStressBCD;
	@FindBy(xpath="//input[@id='mbcd.brineExposurePeriod']")
	WebElement brineExposurePeriod;
	@FindBy(xpath="//div[@id='mbcd.pittingRisk']")
	WebElement pittingRisk;
	@FindBy(xpath="//div[@id='mbcd.sccGeneralRisk']")
	WebElement sccGeneralRisk;
	@FindBy(xpath="//div[@id='mbcd.sccCo2Risk']")
	WebElement sccCo2Risk;
	@FindBy(xpath="//div[@id='mbcd.sccH2sRisk']")
	WebElement sccH2sRisk;
	@FindBy(xpath="//div[@id='mbcd.sccOxyRisk']")
	WebElement sccOxyRisk;
	@FindBy(xpath="//span[contains(text(),'HFCD')]//following::a")
	List<WebElement> acdPlus;
	@FindBy(xpath="//input[@id='macd.acidId']")
	WebElement acidDescription;
	@FindBy(xpath="//div[@id='macd.acidInhibition']")
	WebElement acidInhibilition;
	@FindBy(xpath="//input[@id='macd.inhibitorDescription']")
	WebElement inhibitorDescription;
	@FindBy(xpath="//input[@id='macd.tempMax']")
	WebElement tempMaxACD;
	@FindBy(xpath="//input[@id='macd.exposurePeriod'] | //input[@id='mhfcd.exposurePeriod']")
	WebElement exposurePeriod;
	@FindBy(xpath="//input[@id='macd.corrosionRate'] | //input[@id='mhfcd.corrosionRate']")
	WebElement corrosionRate;
	@FindBy(xpath="//textarea[@id='macd.corrosionNotes'] | //input[@id='mhfcd.corrosionNotes']")
	WebElement corrosionNotes;
	@FindBy(xpath="//input[@id='macd.overallRisk'] | //input[@id='mhfcd.overallRisk']")
	WebElement overallRisk;
	@FindBy(xpath="//span[contains(text(),'HFCD')]//following::a")
	List<WebElement> hfcdPlus;
	@FindBy(xpath="//input[@id='mhfcd.hfProductId']")
	WebElement hydraulicFluidDesc;
	@FindBy(xpath="//input[@id='mhfcd.tempMin']")
	WebElement hfcdTempMin;
	@FindBy(xpath="//input[@id='mhfcd.tempMax']")
	WebElement hfcdTempMax;
	@FindBy(xpath="//input[@id='mhfcd.hfCoatingId']")
	WebElement hfCoatingId;
	@FindBy(xpath="//span[contains(text(),'IWCD')]//following::a")
	List<WebElement> iwcdPlus;
	@FindBy(xpath="//input[@id='miwcd.wiTempMax']")
	WebElement injectionTempMax;
	@FindBy(xpath="//input[@id='miwcd.wiDOMax']")
	WebElement disolveOxy;
	@FindBy(xpath="//input[@id='miwcd.wiPhMin']")
	WebElement waterpHMin;
	@FindBy(xpath="//input[@id='miwcd.wiPhMax']")
	WebElement waterpHMax;
	@FindBy(xpath="//div[@id='miwcd.wiResChlorineAccept']")
	WebElement resChlorineAcc;
	@FindBy(xpath="//div[@id='miwcd.sealEquipmentAccept']")
	WebElement sealEquipmentAccept;
	@FindBy(xpath="//div[@id='miwcd.nonSealEquipmentAccept']")
	WebElement nonSealEquipmentAccept;
	@FindBy(xpath="//input[@id='miwcd.wiWaterSources']")
	WebElement waterSource;
	@FindBy(xpath="xpath=//a[@href='https://app-2654-material-advisor-web-evq.azurewebsites.net/']")
	WebElement homeBtn;
	
	public void homeBtn() {

		homeBtn.click();
	}
	
	public void iwcdPlus() {

		iwcdPlus.get(3).click();
	}
	
	public void waterSource() {

		waterSource.click();
	}
	
	public void nonSealEquipmentAccept() {

		nonSealEquipmentAccept.click();
	}
	
	public void sealEquipmentAccept() {

		sealEquipmentAccept.click();
	}
	
	public void resChlorineAcc() {

		resChlorineAcc.click();
	}
	
	public void overallRisk() {

		overallRisk.click();
	}
	
	public void coatingDesc() {

		hfCoatingId.click();
	}
	
	public void hydraulicFluidDesc() {

		hydraulicFluidDesc.click();
	}
	
	public void pittingRisk() {

		pittingRisk.click();
	}
	
	public void acidInhibilition() {

		acidInhibilition.click();
	}
	
	public void acidDescription() {

		acidDescription.click();
	}
	
	public void acdPlus() {

		acdPlus.get(4).click();
	}
	
	public void hfcdPlus() {

		hfcdPlus.get(5).click();
	}
	
	public void sccGeneralRisk() {

		sccGeneralRisk.click();
	}
	
	public void sccCo2Risk() {

		sccCo2Risk.click();
	}
	
	public void sccH2sRisk() {

		sccH2sRisk.click();
	}
	
	public void sccOxyRisk() {

		sccOxyRisk.click();
	}
	
	public void corrosionNotes(String value) {

		if(!corrosionNotes.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(corrosionNotes);

		}
		corrosionNotes.sendKeys(value);
		corrosionNotes.sendKeys(Keys.RETURN);
	}	
	
	public void corrosionRate(String value) {

		if(!corrosionRate.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(corrosionRate);

		}
		corrosionRate.sendKeys(value);
		corrosionRate.sendKeys(Keys.RETURN);
	}
	
	public void acidExposurePeriod(String value) {

		if(!exposurePeriod.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(exposurePeriod);

		}
		exposurePeriod.sendKeys(value);
		exposurePeriod.sendKeys(Keys.RETURN);
	}
	
	
	public void inhibitorDescription(String value) {

		if(!inhibitorDescription.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(inhibitorDescription);

		}
		inhibitorDescription.sendKeys(value);
		inhibitorDescription.sendKeys(Keys.RETURN);
	}	
	
	public void brineDesc() {

		brineDesc.click();
	}
	
	
	public void clickNace() {

		naceRef.click();
	}
	
	public void stressConditionBCD() {

		stressConditionBCD.click();
	}
	
	
	public void stressCondition() {

		stressCondition.click();
	}
	
	public void sulfurResistant() {

		sulfurResistant.click();
	}
	
	public void waterpHMax(String value, String message) {

		if(!waterpHMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(waterpHMax);

		}
		waterpHMax.sendKeys(value);
		waterpHMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void waterpHMin(String value, String message) {

		if(!waterpHMin.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(waterpHMin);

		}
		waterpHMin.sendKeys(value);
		waterpHMin.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void hfcdTempMax(String value, String message) {

		if(!hfcdTempMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(hfcdTempMax);

		}
		hfcdTempMax.sendKeys(value);
		hfcdTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void hfcdTempMin(String value, String message) {

		if(!hfcdTempMin.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(hfcdTempMin);

		}
		hfcdTempMin.sendKeys(value);
		hfcdTempMin.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void injectionTempMax(String value, String message) {

		if(!disolveOxy.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(injectionTempMax);

		}
		injectionTempMax.sendKeys(value);
		injectionTempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	
	public void disolveOxy(String value, String message) {

		if(!disolveOxy.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(disolveOxy);

		}
		disolveOxy.sendKeys(value);
		disolveOxy.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void brineExposurePeriod(String value, String message) {

		if(!brineExposurePeriod.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(brineExposurePeriod);

		}
		brineExposurePeriod.sendKeys(value);
		brineExposurePeriod.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void maxTensileStressBCD(String value, String message) {

		if(!maxTensileStressBCD.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(maxTensileStressBCD);

		}
		maxTensileStressBCD.sendKeys(value);
		maxTensileStressBCD.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 100) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void accpTemp(String value, String message) {

		if(!accpTemp.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(accpTemp);

		}
		accpTemp.sendKeys(value);
		accpTemp.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void h2sPartialPressureMax(String value, String message) {

		if(!h2sPartialPressureMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(h2sPartialPressureMax);

		}
		h2sPartialPressureMax.sendKeys(value);
		h2sPartialPressureMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void co2PartialPressureMax(String value, String message) {

		if(!co2PartialPressureMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(co2PartialPressureMax);

		}
		co2PartialPressureMax.sendKeys(value);
		co2PartialPressureMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 9999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void chloridesMax(String value, String message) {

		if(!chloridesMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(chloridesMax);

		}
		chloridesMax.sendKeys(value);
		chloridesMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 999999) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}

	public void tempMax(String value, String message) throws InterruptedException {

		if(!tempMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(tempMax);

		}
		tempMax.sendKeys(value);
		Thread.sleep(2000);
		tempMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	
	public void tempMaxACD(String value, String message) throws InterruptedException {

		if(!tempMaxACD.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(tempMaxACD);

		}
		tempMaxACD.sendKeys(value);
		Thread.sleep(2000);
		tempMaxACD.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void tempMin(String value) throws InterruptedException {
		
		tempMin.sendKeys(value);
		Thread.sleep(2000);
		tempMin.sendKeys(value);
		
	}
	
   public void tempMax(String value) throws InterruptedException {
		
		tempMax.sendKeys(value);
		Thread.sleep(2000);
		tempMin.sendKeys(value);
	}


	public void tempMin(String value, String message) throws InterruptedException {

		if(!tempMin.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(tempMin);

		}
		tempMin.sendKeys(value);
		Thread.sleep(2000);
		tempMin.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 450) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void phMin(String value, String message) {

		if(!phMin.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(phMin);

		}
		phMin.sendKeys(value);
		phMin.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void phMax(String value, String message) {

		if(!phMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(phMax);

		}
		phMax.sendKeys(value);
		phMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 14) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void waterCutMax(String value, String message) {

		if(!waterCutMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(waterCutMax);

		}
		waterCutMax.sendKeys(value);
		waterCutMax.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 100) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void maxTensileStress(String value, String message) {

		if(!maxTensileStress.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(maxTensileStress);

		}
		maxTensileStress.sendKeys(value);
		maxTensileStress.sendKeys(Keys.RETURN);
		int i=Integer.parseInt(value); 
		if(i > 100) {
			By locator = By.xpath(String.format("//p[contains(text(),'%s')]", message));
			CommonFunctions.waitVisibilityofElement(locator);
			WebElement el = getDriver().findElement(locator);
			if(el.isDisplayed()) {
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
	}
	
	public void mercuryMax(String value) {

		if(!mercuryMax.getAttribute("value").isEmpty());
		{
			CommonFunctions.deleteText(mercuryMax);

		}
		mercuryMax.sendKeys(value);
		mercuryMax.sendKeys(Keys.RETURN);
		
	}
}
