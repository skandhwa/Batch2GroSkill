package stepDefinitions;
/** 
 * @author Ethesh Gaur
 */
public enum PageScenarioKeys implements ScenarioKeys{

   ProductLine,	CSRNumber, Options, ThreadType, ARSRNumber, RepairSurface, RequestName, RequestNameE, RecordUID, AMPartRefenerenceNumber;
}
