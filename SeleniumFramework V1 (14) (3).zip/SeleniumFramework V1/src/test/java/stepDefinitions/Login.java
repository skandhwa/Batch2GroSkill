package stepDefinitions;

import java.awt.AWTException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.By;

import PageFactoryElements.AMPartAndMaterialAdvisorAppPage;
import PageFactoryElements.MaterialAdvisorLoginPage;
import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login extends DriverIntialization{

	MaterialAdvisorLoginPage MALoginPage = new MaterialAdvisorLoginPage(DriverIntialization.getDriver());
	
	public static InputStream loadFileAsStream(String file) {
		return CommonFunctions.class.getResourceAsStream(file);
	}
	
	@And("add verification code")
	public void addver_code() throws InterruptedException {
		Totp generateOtp = new Totp("pnnmq7yzr5wpyy5k");
		MALoginPage.setVerCode(generateOtp.now());
	}   
	
	@Given("user enter email address {string}")
	public void user_enter_email_address(String email) throws InterruptedException {

		MALoginPage.addEmail(email);
	}

	@When("user click next button")
	public void user_click_next_button() throws InterruptedException, AWTException {

		MALoginPage.clickNext();

	}
	
	@Then("click Material Selection & Validation")
	public void navigate_to_my_request() {
		
		MALoginPage.matSelVal();
		
	}

	@And("user enters pass {string}")
	
	public void user_enters_pas(String pass) throws InterruptedException {
		
		MALoginPage.addPass(pass);
				
	}
	
	@And("user enters password")
	public void ass_password() throws InterruptedException {
		
		MALoginPage.addPass(ppty.getProperty("pass"));
	}
	
	@Then("verify Apps {string} are present")
	public void verify_apps_are_present(String app) throws InterruptedException {
		
		MALoginPage.selectAppDisplayed(app);
	}
	
	@Then("verify Apps are not present")
	public void verify_apps_are_not_present() {
		
		MALoginPage.noApps();
	}
}
