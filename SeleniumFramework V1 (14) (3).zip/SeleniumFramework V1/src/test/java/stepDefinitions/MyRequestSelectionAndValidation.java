package stepDefinitions;
import java.awt.AWTException;
import java.util.List;
import java.util.Map;

import PageFactoryElements.MaterialAdvisorMyRequest;
import PageFactoryElements.MaterialSelectionReportPage;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import Utilities.ExcelConfiguration;
import Utilities.ExcelDataReader;
import Utilities.IDataReader;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyRequestSelectionAndValidation extends DriverIntialization{
	
	MaterialAdvisorMyRequest matAdvReq = new MaterialAdvisorMyRequest(DriverIntialization.getDriver());
	MyRequestCreateRequestPage matAdvCreReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());
	ScenarioContext sc=new ScenarioContext();
	MaterialSelectionReportPage matSelReportPage = new MaterialSelectionReportPage(DriverIntialization.getDriver());
	
	@When("user enter name {string} of the request in Search Request field")
	public void user_enter_name_of_the_request_in_search_requesnewt_field(String name) throws InterruptedException, AWTException {
		
		sc.save(PageScenarioKeys.RequestName, name);
		matAdvReq.searchResult(name);
		
	}
	
	@Then("search result match with the search item {string}")
	public void search_result_match_with_the_search_itemString(String name) throws InterruptedException {
		
		sc.save(PageScenarioKeys.RequestName, name);
		matAdvReq.verifyResult(name);
	}
	
	@When("user select Material Type {string}")
	public void select_material_type(String matetype) throws InterruptedException {
		matAdvReq.clickMaterialType();
		matAdvReq.selectOption(matetype);
		
	}
	
	@When("user select Request Type {string}")
	public void select_mrequest_type(String reqtype) throws InterruptedException {
		matAdvReq.requestType();
		matAdvReq.selectOption(reqtype);
		
	}
	
	@When("user select Requester {string}")
	public void select_requester(String reqName) throws InterruptedException {
		
		matAdvReq.requester(reqName);
		
	}
	
	@When("user select {string} on SME Test")
	public void user_select_on_SME_Test(String option) throws InterruptedException {
		
		matAdvReq.SMETest();
		matAdvReq.selectOption(option);
	}
	
	@When("user click Clear All")
	public void user_click_Clear_All() {
		
		matAdvReq.clearAll();
	}
	
	@When("user click Create Request Button")
	public void user_clickCreate_Button() {
		
		matAdvReq.createRequestBtn();
	}
	
	@Then("verify notice pop up appears")
	public void verify_notice_pop_up_appears() {
		matAdvReq.noticePopUp();
	}
	
	@When("user click on Date Arrow")
	public void user_click_on_date_arrow() {
		
		matAdvReq.dateSort();
	}
	@Then("data is sorted according to ascending order")
	public void data_is_sorted_according_to_the_ascending_order() {
		
	}
	
	@Then("data is sorted according to descending order")
	public void data_is_sorted_according_to_the_descending_order() {
		
	}
	
	@And("click on {string}")
	public void click_on(String btn) throws InterruptedException {
		
		matAdvReq.regularOrSMEVal(btn);
	}
	
	@Then("navigated to Edit Request page")
	public void navigated_to_edit_request_page() {
		
		matAdvReq.editRequestPage();
	}
	
	@Then("navigated to Create Request page")
	public void navigated_to_created_request_page() {
		
		matAdvReq.createRequestPage();
	}
	
	@When("user enter request name {string}")
	public void user_enter_request_name(String name) throws InterruptedException, AWTException {
		
		matAdvReq.requestName(name);
		sc.save(PageScenarioKeys.RequestName, name);
	}
	
	@And("user click on SME Validation")
	public void user_click_on_sme_validation() {
		
		matAdvReq.clickSMEVal();
	}
	
	@Then("verify the note {string}")
	public void verify_the_note(String note) {
		
		matAdvReq.noteVerify(note);
	}
	
	@When("user click Product line on create Page")
	public void user_click_product_line_on_createpage() {
		
		matAdvReq.productLine();
	}
	
	@When("user select Product Application {string}")
	public void user_select_product_application(String name) {
		
		matAdvReq.productApplication(name);
	}
	
	@When("user select Product Application")
	public void user_select_product_application(List<Map<String, String>> dt) throws InterruptedException {
		
		matAdvReq.verifyProdApp(dt);
	}
	
	@And("user select Request type {string} and Material type {string}")
	public void user_select_request_type_and_material_type(String reqType, String matType) {
		
		matAdvReq.reqAndMatType(reqType);
		matAdvReq.reqAndMatType(matType);
	}
	
	@Then("verify the Proposed Metallurgy and Yield Strength assciated with Material Validation and Metallic")
	public void verify_the_proposed_metallurgy_and_yield_strength_associated_with_material_validaion_and_metallic() {
		
		matAdvReq.propossedMetaAndYieldStrength();
	}
	
	@Then("verify the Elastomer Family and Elastomer Description assciated with Material Validation and Elastomer")
	public void verify_the_elastomer_family_and_elastomer_description_associated_with_material_validaion_and_metallic() {
		
		matAdvReq.elastomerfamilyanddescription();
	}
	
	@When("user click on Reset button icon")
	public void user_click_on_reset_button_icon() throws InterruptedException {
		
		matAdvReq.clickResetButton();
	}
	
	@Then("reset pop up screen appears with message {string}")
	public void reset_pop_up_screen_appears_with_message(String message) {
		
		matAdvReq.resetpopup(message);
	}
	
	@When("user click OK button")
	public void user_click_ok_button() {
		
		matAdvReq.okButton();
	}
	
	@Then("reset button is greyed out and edit icon is higlighted")
	public void reset_button_is_greyed_out_and_edit_is_highlighted() {
		
		matAdvReq.resetandeditbuttonEnable();
	}
	
	@When("user click on Edit button")
	public void user_click_on_Edit_button() throws InterruptedException {
		
		matAdvReq.editButton();
	}
	
	
	@Then("verify request is reset")
	public void verify_request_is_reset() throws InterruptedException {
		
		matAdvReq.resetVerified();
	}
	
	@And("User click Next button")
	public void click_next_button() {
		
		matAdvReq.clicknextBtn();
	}
	
    @When("user select Service Type {string} and verify mandatory message {string}")
    public void user_verify_and_select_service_type(String service, String message) throws InterruptedException {
    	
    	matAdvCreReq.clickSaveBtn();
    	matAdvCreReq.verifyMandatoryMessage(message);
    	matAdvCreReq.clickServiceType();
    	matAdvCreReq.selectOption(service);
    	
    }
    
    @When("user select Service Type {string}")
    public void user_select_service_type(String service) {
    	    	
    	matAdvCreReq.clickServiceType();
    	matAdvCreReq.selectOption(service);
    	    	
    }
    
    
    @And("user verify Intended Service Life mandatory message {string} and enter the value {string}")
    public void user_verify_intended_service_life_mndatory_message_and_enter_value(String message, String value) throws InterruptedException {
    	
    	matAdvCreReq.verifyMandatoryMessage(message);
    	matAdvCreReq.enterIntendedSerLife(value);
    	
    }
    
    @And("user enter Intended Service Life value {string}")
    public void user_enter_intended_service_life_value(String value) throws InterruptedException {
    	
    	matAdvCreReq.enterIntendedSerLife(value);
    	
    }
    
    @Then("verify negative/maximum value error message {string}")
    public void verify_negative_value_and_verify_message(String message) throws InterruptedException {
    	
       	matAdvCreReq.verifyMandatoryMessage(message);
    }
    
    @And("user select Service Life Unit select as {string}")
    public void select_serviceLife_unit(String option) {
    	    	
    	matAdvCreReq.clickServLUnit();
    	matAdvCreReq.selectOption(option);
    }
    
    @And("verify Service Life Unit mandatory message {string} and select option {string}")
    public void verify_service_life_unit_mand_message_and_select_option(String message, String option) {
    	
    	matAdvCreReq.verifyMandatoryMessage(message);
    	matAdvCreReq.clickServLUnit();
    	matAdvCreReq.selectOption(option);
    }
    
    @When("User click save button")
    public void user_click_save_button() throws InterruptedException {
    	
    	matAdvCreReq.clickSaveBtn();
    	
    	
    }
	
    @And("verify the Customer mandatory message {string}")
    public void verify_customer_mandatory_message(String message) {
    	
    	matAdvCreReq.verifyMandatoryMessage(message);
    }
    
    @Then("Verify Customer field and Country data")
    public void verify_customer_field_data(IDataReader dataTable) throws InterruptedException {
    	
    	List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			matAdvCreReq.enterCustName(data.get(i).get("Customer"));
			matAdvCreReq.countryfield(data.get(i).get("Country"));
		}
    }
    
    @Then("user select {string} for Primary Production Fluid")
    public void user_select_for_primary_production_fluid(String string) {
       
    	matAdvCreReq.clickPrimaryProductionFluid();
    	matAdvCreReq.selectOption(string);
    }
    
    @Then("user select {string} for Liquid System")
    public void user_select(String string) {
        
    	matAdvCreReq.clickliquidSystem();
    	matAdvCreReq.selectOption(string);
    }
    
    @And("enter field name {string}")
    public void enter_field_name(String name) {
    	
    	matAdvCreReq.filedName(name);
    }
    
    @Then("Verify Production Tubing Data")
    public void verify_production_tubing_field_data(IDataReader dataTable) throws InterruptedException {
    	
    	List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			matAdvCreReq.productionTubing(data.get(i).get("Production Tubing"));
			
		}
    }
    
    @When("user select production tubing {string} and verify Specified min yield strength {string}")
    public void user_select_production_tubing_and_verify_specified_min_yield_strength(String name, String value) throws InterruptedException {
    	
    	matAdvCreReq.productionTubing(name);
    	matAdvCreReq.fetchspecifiedtubingYieldMin(value);
    }
    
    @When("user select production tubing {string}")
    public void user_select_production_tubing(String name) throws InterruptedException {
    	
    	matAdvCreReq.productionTubing(name);
    	
    }
    
    @And("user select Is Tubing Internally Coated {string}")
    public void user_select_is_tubing_internally_coated(String value) {
    	
    	matAdvCreReq.clickIsTubingCoat();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("verify Tubing Inside Dia {string}")
	public void verify_tubing_inside_dia_and_message(String value) throws InterruptedException {

			matAdvCreReq.tubingInsideDiameter(value);
				
	}
    
    @And("user select Inside Diameter Unit {string}")
    public void user_select_inside_diameter_unit(String unit) {
    	
    	matAdvCreReq.clicktubingInsideDiaUnit();
    	matAdvCreReq.selectOption(unit);
    }
    
    @And("user add Tubing weight {string}")
    public void user_add_tubing_weight(String value) throws InterruptedException {
    	
    	matAdvCreReq.tubeWeight(value);
    }
    
    @Then("user select Tube Weight Unit {string}")
    public void user_select_tube_weight_unit(String unit) {
    	
    	matAdvCreReq.tubeWeightUnit();
    	matAdvCreReq.selectOption(unit);
    }
    
    @And("User enter Tubing Inhibitor {string}")
    public void user_enter_tubing_inhibitor(String value) {
    	
    	matAdvCreReq.enterTubingInhibitor(value);
    }
    
    @Then("verify Mandatory message {string}")
    public void verify_mandatory_message_for_water_source(String message) throws InterruptedException {
       
    	
    	matAdvCreReq.verifyMandatoryMessage(message);
    	
    }
    
    @Then("verify Equipment error message {string}")
    public void verify_equipement_message_for_water_source(String message) {
       
    	matAdvCreReq.verifyMandatoryMessage(message);
    	
    }
    
    @Then("user verify data of Water Source")
    public void user_verify_data_of_water_source(List<Map<String, String>> dt) throws InterruptedException {
        
    	matAdvCreReq.waterSource(dt);
    }
    
    @Then("enter Disolved Oxygen {string} and verify the message for min and max value")
    public void enter_disolved_oxygen_and_verify_the_message_for_min_and_max_value(String value, DataTable dt) {
    	
    	matAdvCreReq.disolvedOxygen(value);
    	matAdvCreReq.verifyErrorMessage(dt);
    	
    }
    
    @When("user select Dissolved Oxygen unit {string}")
    public void user_select_dissolved_oxygen_unit(String unit) {
        
    	matAdvCreReq.selectDiOxyUnit();
    	matAdvCreReq.selectOption(unit);
    }
    
    @Then("enter Water pH {string} and verify the message for min and max value")
    public void enter_water_ph_and_verify_the_message_for_min_and_max_value(String value, DataTable dt) {
    	
    	matAdvCreReq.waterpH(value);
    	matAdvCreReq.verifyAllErrorMessage(dt);
    	
    }
    
    @When("user select Water pH unit {string}")
    public void user_select_water_ph_unit(String unit) {
        
    	matAdvCreReq.waterpHUnit();
    	matAdvCreReq.selectOption(unit);
    }
    
    @When("user select Residual Chlorine {string}")
    public void user_select_residual_chlorine(String value) {
       
    	matAdvCreReq.residualChlorine();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("enter Injection flow {string} and verify the message for min and max value")
    public void enter_injection_flow_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.injectionFlow(string);
    	matAdvCreReq.verifyInjectionFlowErrorMessage(dataTable);
    }
    
    @When("enter Injection Temp {string} and verify the message for min and max value")
    public void enter_injection_temp_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.injectiontemp(string);
    	matAdvCreReq.verifyInjectionTempErrorMessage(dataTable);
    }
    
    @When("user select Injection Flow unit {string}")
    public void user_select_inject_temp_unit(String value) {
        
    	matAdvCreReq.injectionTempUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("user verify Industry Standard data")
    public void user_verify_industry_standards_data(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.industryStandardData(dataTable);
    }
    
    @And("user remove Industry/Mud Standard/Type {string}")
    public void user_remove(String value) {
    	
    	matAdvCreReq.industryStandardsOptionRemove(value);
    }
    
    @When("enter Bottom Hole {string} and verify the message for min and max value")
    public void enter_bottom_hole_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.bottomHole(string);
    	matAdvCreReq.verifyAllErrorMessage(dataTable);
    }
    
    @When("enter Bottom Hole Temp {string} and verify the message for min and max value")
    public void enter_bottom_hole_temp_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.bottomHoleTemp(string);
    	matAdvCreReq.verifyAllErrorMessage(dataTable);
    }
    
    @When("user select Bottom Hole unit {string}")
    public void user_select_bottom_hole_unit(String value) {
        
    	matAdvCreReq.bottomHoleUnit();
    	matAdvCreReq.selectOption(value);
    	
    }
    
    @When("user select Bottom Hole Temp unit {string}")
    public void user_select_bottom_hole_temp_unit(String value) {
        
    	matAdvCreReq.bottomHoleTempUnit();
    	matAdvCreReq.selectOption(value);
    	
    }
    
    @When("enter Shut-in Wellhead {string} and verify the message for min and max value")
    public void enter_shut_in_wellHead_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.shutInWellhead(string);
    	matAdvCreReq.verifyShutinWellheadErrorMessage(dataTable);
    }
    
    @When("user enter Shut-in Wellhead Pressure {string}")
    public void add_shut_in_well_head_pressure(String value) {
    	
    	matAdvCreReq.shutInWellhead(value);
    }
    
    @Then("user select Shut-in Wellhead unit {string}")
    public void user_select_shut_in_wellhead_unit(String value) {
       
    	matAdvCreReq.shutInWellheadUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("enter Wellhead Temp {string} and verify the message for min and max value")
    public void enter_wellhead_temp_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.wellheadTemp(string);
    	matAdvCreReq.verifyAllErrorMessage(dataTable);
    }
    
    @Then("user select Wellhead Temp unit {string}")
    public void user_select_wellhead_temp_unit(String value) {
      
    	matAdvCreReq.wellheadTempUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("enter Min Service Temp {string} and verify the message for min and max value")
    public void enter_minservice_temp_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.minServiceTemp(string);
    	matAdvCreReq.verifyMinServiceTempErrorMessage(dataTable);
    }
    
    @Then("user Min Service Temp unit {string}")
    public void user_select_min_service_temp_unit(String value) {
      
    	matAdvCreReq.minSTempUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("enter Vertical Depth {string} and verify the message for min and max value")
    public void enter_vertical_depth_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.verticalDepth(string);
    	matAdvCreReq.verifyverticalDepthErrorMessage(dataTable);
    }
    
    @Then("user Vertical Depth unit {string}")
    public void user_select_vertical_depth_unit(String value) {
      
    	matAdvCreReq.verticalDUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("user select Brine Information")
    public void user_select_brine_information() {
        
    	matAdvCreReq.brineinformation();
    }
    
    @Then("user verify data of Brine Description")
    public void user_verify_data_of_brine_description(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.brineDescriptionData(dataTable);
    }
    
    @When("user select CO2 Contamination {string}")
    public void user_select_co2_contamination(String value) {
    	
    	matAdvCreReq.co2Contamination();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("user select H2S Contamination {string}")
    public void user_select_h2s_contamination(String value) {
        
    	matAdvCreReq.h2sContamination();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("user select Oxygen Contamination {string}")
    public void user_select_oxygen_contamination(String value) {
        
    	matAdvCreReq.oxygenContamination();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("user select Acid Information")
    public void user_select_acid_information() {
        
    	matAdvCreReq.acidInformation();
    }
    
    @Then("user verify data of Acid Description")
    public void user_verify_data_of_acid_description(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.acidDescriptionData(dataTable);
    }
    
    @When("user select Acid Inhibitor {string}")
    public void user_select_acid_inhibitor(String value) {
        
    	matAdvCreReq.acidInhibitor();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("enter Acid Exposure Time {string} and verify the message for min and max value")
    public void enter_acid_exposure_and_verify_the_message_for_min_and_max_value(String string, DataTable dataTable) {
       
    	matAdvCreReq.acidExpoTime(string);
    	matAdvCreReq.verifyAcidExpoTimeErrorMessage(dataTable);
    }
    
    @Then("enter Acid Exposure Time {string}")
    public void enter_acid_exposure_time(String value) {
    	matAdvCreReq.acidExpoTime(value);
    }
    
    @Then("user Acid Exposure Time unit {string}")
    public void user_select_acid_exposure_unit(String value) {
      
    	matAdvCreReq.acidTimeUnit();
    	matAdvCreReq.selectOption(value);
    }
    
    @When("user select Fluid Type {string}")
    public void user_select_fluid_type(String value) {
        
    	matAdvCreReq.fluidType();
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("user verify data of Material Coating")
    public void user_verify_data_of_material_coating(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.materialCoating(dataTable);
    }
    
    @When("user select Hydraulic Fluid Information")
    public void user_select_hf_information() {
        
    	matAdvCreReq.hydraulicFluidInfo();
    }
    
    @When("user click Edit Button")
    public void user_click_edit_button() {
    	
    	matAdvCreReq.editBtn();
    }
    
    @And("enter Dissolved Oxygen {string}")
    public void enter_dissolved_oxygen(String oxy) {
    	
    	matAdvCreReq.disolvedOxygen(oxy);
    }
    
    @And("enter Injection Temp {string}")
    public void enter_Injection_Temp_(String temp) {
    	
    	matAdvCreReq.injectiontemp(temp);
    }
    
    @And("enter Injection flow {string}")
    public void enter_Injection_flow(String temp) {
    	
    	matAdvCreReq.injectionFlow(temp);
    }
    
    @And("Enter customer {string} and country {string}")
    public void enter_customer_and_coutry(String cust, String country) throws InterruptedException {
    	
    	matAdvCreReq.enterCustName(cust);
    	matAdvCreReq.countryfield(country);
    }
    
    @And("enter Bottom Hole {string}")
    public void enter_bottomhole(String temp) {
    	
    	matAdvCreReq.bottomHole(temp);
    }
    
    @Then("verify the message after Save {string}")
    public void verify_the_message_after_save(String string) {
       
    	matAdvCreReq.verifySaveMessage(string);
    }
    
    @Then("enter Bottom Hole Temp {string}")
    public void enter_bottom_hole_temp(String string) {
       
    	matAdvCreReq.bottomHoleTemp(string);
    }
    
    @Then("User click Equipment Tab")
    public void user_click_equipment_tab() {
        
    	matAdvCreReq.equipment();
    }
    
    @Then("user click General Tab")
    public void user_click_general_tab() {
        
    	matAdvCreReq.generalTab();
    }
    
    @Then("user select Equipment")
    public void user_select_equipment(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.selectEquipment(dataTable);
    }
    @Then("user select Component")
    public void user_select_component(List<Map<String, String>> dataTable) throws InterruptedException {
        
    	matAdvCreReq.selectComponent(dataTable);
    }
    
    @Then("user add the Equipment and Component")
    public void user_add_the_equipment_and_component() throws InterruptedException {
        
    	matAdvCreReq.addBtn();
    }
   
    @Then("user add Maximum Stress {string}")
    public void user_add_maximum_stress(String value) {
        
    	matAdvCreReq.maxStress(value);
    }
    
    @Then("verify save message {string} disappeared and component added {string}")
    public void verify_save_message_disappeared_and_component_added(String message, String component) {
        
    	matAdvCreReq.verifySaveMessageAfterComponentAdded(message);
    	matAdvCreReq.verifyComponentAdded(component);
    }
    
    @Then("user delete component {string}")
    public void user_delete_component(String string) {
        
    	matAdvCreReq.deleteComponent(string);
    	matAdvCreReq.okButton();
    }
    
    @Then("user select Equipment {string}")
    public void user_select_equipment_option(String dataTable) throws InterruptedException {
        
    	matAdvCreReq.selectEquipmentOp(dataTable);
    }
    
    @When("user click Test Submit/Workflow button")
    public void user_click_test_submit_button() throws InterruptedException {
       
    	matAdvCreReq.testSubmit();
    }
    
    @When("user click Submit button")
    public void user_click_submit_button() throws InterruptedException {
       
    	matAdvCreReq.submitBtn();
    }
    
    @Then ("verify the message {string}")
    public void verify_the_message(String string) {
    	
    	matAdvCreReq.verifySubmitMessage(sc.getData(PageScenarioKeys.RequestName), string);
    	
    }
    
    @Then("enter H2S Partial Pressure {string}")
    public void enter_h2s_partial_pressure(String string) {
        
    	matAdvCreReq.h2sPartialPressure(string);
    }
    
    @Then("enter CO2 Partial Pressure {string}")
    public void enter_co2_partial_pressure(String string) {
        
    	matAdvCreReq.co2PartialPressure(string);
        
    }
    
    @When("user select Specified min Yield  {string}")
    public void user_select_specified_min_yield(String string) {
        
    	matAdvCreReq.specifiedMinYield(string);
    }
    
    @Then("Submit pop up appears with message {string}")
    public void submit_pop_up_appears(String message) {
        
    	matAdvCreReq.verifyPopUpMessage(message);
    }
    
    @Then("user click cancel button")
    public void user_click_cancel_button() {
        
    	matAdvCreReq.cancelBtn();
    }
    
    @Then("user navigated to {string} page and Request name is present")
    public void user_navigated_to_material_selection_report_page_and_request_name_is_present(String page) {
        
    	matSelReportPage.reportPage(page);
    	//matSelReportPage.reportPage(sc.getData(PageScenarioKeys.RequestName));
    }
    
    @Then("Verify data on the Material/Elastomer Selection/Validation Report page")
    public void verify_data_on_the_material_selection_report_page(DataTable dt) throws InterruptedException {
    	
    	matSelReportPage.verifyDataInReportPage(dt);
    	
    }
    
    
    @And("Verify the data under Recommendation")
    public void verify_the_data_under_recommendation(DataTable dt) throws InterruptedException {
    	
       matSelReportPage.verifyDataInMaterialRecomendation(dt);
    }
    
    @And("Verify the data for Proposed Material")
    public void verify_the_data_for_proposed_material(DataTable dt) throws InterruptedException {
    	
       matSelReportPage.verifyDataInReportPage(dt);
    }
    
    @When("user enter Acid Inhibitor {string}")
    public void user_ener_acid_inhibitor(String value) {
    	matAdvCreReq.acidInhibitor();
    	matAdvCreReq.selectOption(value);
    	
    }
    
    @Then("user verify Warning message {string} and Notes")
    public void user_verify_warning_message_and_notes(String message, List<Map<String, String>> dataTable) {
       
    	matSelReportPage.verifyNotes(dataTable);
    	matSelReportPage.warningMessage(message);
    }
    
    @Then("verify the message {string} and {string} at the footer of the page")
    public void verify_the_message_and_at_the_footer_of_the_page(String string, String string2) {
      
    	matSelReportPage.confidentialMessage(string);
    	matSelReportPage.donotdiscloseMessage(string2);
    }
    
    @Then("user click {string} button")
    public void user_click_button(String button) throws InterruptedException {
        
    	matSelReportPage.clickButton(button);
    }
    
    @Then("user click My Requests button")
    public void user_click_my_requests_button() {
        
    	matSelReportPage.clickMyRequests();
    }
    
    @Then("deleted item is not present item {string}")
    public void deleted_item_is_not_present_item(String string) throws InterruptedException {
    	matAdvReq.verifyDeletedRequest(string);
    }
    
    @When("user click Three dots in Recommendation options and select {string}")
    public void user_click_three_dots_in_recommendation_options_and_select(String string) {
       
    	matSelReportPage.threeDotsinRecom();
    	matAdvCreReq.selectOption(string);
    }
    
    @Then("verify Material Condition in Material Recommendation")
    public void verify_condition_inMaterial_recommendation(DataTable dataTable) {
       
    	matSelReportPage.verifyMaterialCondition(dataTable);
    }
       
    @Then("verify the Proposed Metallurgy")
    public void verify_proposed_metalurgy_data(IDataReader dataTable) throws InterruptedException, AWTException {
    	
    	List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=1;i<data.size();i++) {
			matAdvCreReq.proposedMetallurgy(data.get(i).get("Proposed Metallurgy").replaceAll("^\"|\"$", ""));
			
		}
    }
    
    @When("user select Proposed Metallurgy {string}")
    public void user_select_proposed_metallurgy(String value) throws InterruptedException, AWTException {
        
    	matAdvCreReq.proposedMetallurgy(value);
    	matAdvCreReq.selectOption(value);
    }
    
    @When("enter Yield Strength {string}")
    public void enter_yield_strength(String value) {
       
    	matAdvCreReq.setProposedYieldStrengthMin(value);
    }

    @Then("verify Important Note {string}")
    public void verify_important_note(String note) {
        
    	matAdvCreReq.verifyImportantNote(note);
    }
    
    @Then("Click Select Material Specification")
    public void click_select_material_specification() throws InterruptedException {
        
    	matAdvCreReq.selectMaterialSpecs();
    }
    
    @Then("Pop up appears with message {string}")
    public void pop_up_appears_with_message(String message) {
       
    	matAdvCreReq.verifyPopUpMessage(message);
    }
    
    @Then("Select Material Specification {string}")
    public void select_material_specification(String string) {
        
    	matAdvCreReq.selectMaterialSpecicationFromPopup(string);
    }
    
    @Then("verify data for Select Material Specification")
    public void verify_data_for_select_material_specification(DataTable dataTable) {
       
    	matAdvCreReq.verifyDataSelectMaterialSpecs(dataTable);
    }
    
    @And("Select Proposed Material Coating {string}")
    public void select_proposed_material_coating(String value) throws InterruptedException {
    	
    	matAdvCreReq.proposedMetarialCoating(value);
    	matAdvCreReq.selectOption(value);
    }
    
    @Then("verify data on Create Page form")
    public void verify_data_on_create_page_form(DataTable dataTable) {
       
    	matAdvCreReq.verifyDataonCreatePageForm(dataTable);
    }
   
    @Then("User select Mud Type {string}")
    public void user_select_mud_type(String string) {
    	matAdvCreReq.clickMudType();
    	matAdvCreReq.selectOption(string);
    }
    
    @Then("user select Amine Based Inhibitor {string}")
    public void user_select_amine_based_inhibitor(String string) {
        
    	matAdvCreReq.amineBasedInhibitor();
    	matAdvCreReq.selectOption(string);
    }
    
    @Then("user select Menthol, Dry {string}")
    public void user_select_menthol_dry(String string) {
        
    	matAdvCreReq.mentholDry();
    	matAdvCreReq.selectOption(string);
    }
    
    @When("user select Elastomer Family {string}")
    public void user_select_elastomer_family(String string) throws InterruptedException {
       
    	matAdvReq.clickElastomerFamily();
    	matAdvReq.selectOption(string);
    }
    
    @When("user select Elastomer Description {string}")
    public void user_select_elastomer_description(String string) throws InterruptedException {
        
    	matAdvReq.clickProposedMaterialDescription();
    	matAdvReq.selectOption(string);
    }
    
    
}

