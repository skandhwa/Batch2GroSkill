package stepDefinitions;

import PageFactoryElements.ElastomerBrineCompatibilityDataRecordPage;
import PageFactoryElements.ElastomerDegradationDataPage;
import PageFactoryElements.ElastomerHydraulicFluidCompatibilityDataPage;
import PageFactoryElements.ElastomerMaterialSpecificationPage;
import PageFactoryElements.MaterialAdvisorMyRequest;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ElastomerEDR {
	
	MaterialAdvisorMyRequest matAdvReq = new MaterialAdvisorMyRequest(DriverIntialization.getDriver());
	ElastomerMaterialSpecificationPage elasMatSpec = new ElastomerMaterialSpecificationPage(DriverIntialization.getDriver());
	MyRequestCreateRequestPage MyReqCreateReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());
	ElastomerDegradationDataPage elastomerEDD = new ElastomerDegradationDataPage(DriverIntialization.getDriver());
	ElastomerBrineCompatibilityDataRecordPage elastomerBCD = new ElastomerBrineCompatibilityDataRecordPage(DriverIntialization.getDriver());
	ElastomerHydraulicFluidCompatibilityDataPage elastomerHFCD= new ElastomerHydraulicFluidCompatibilityDataPage(DriverIntialization.getDriver());
	
	@When("user click {string} plus button")
	public void user_click_plus_button(String edr) {
	    
		elasMatSpec.selectEDR(edr);
	}
	
	@When("user click {string} plus button for Metal")
	public void user_click_plus_buttonformetal(String edr) {
	    
		elasMatSpec.selectEDR2(edr);
	}
	
	@Then("verify Specification {string}")
	public void verify_specification(String string) {
	    
		elastomerEDD.verifySpec(string);
	}	
	
	@And("user select {string} and component {string}")
	public void selectadd_equipement(String equipment, String comp) throws InterruptedException {
		try {
		MyReqCreateReq.addEquipmentIfRequired().isDisplayed();
		MyReqCreateReq.equipment();
		MyReqCreateReq.selectEquipmentOp(equipment);
		MyReqCreateReq.selectComponent(comp);
		MyReqCreateReq.addBtn();}
		catch(Exception e) {
			
		}
	}
	
	@Then("user verify data on EDD/BCD/ACD/HFCD/AGCD/IWCD")
	public void user_verify_data_on_edd(DataTable dataTable) {
	
		elastomerEDD.verifyDataOnEDD(dataTable);
	}
	
	@Then("delete button pop up appears {string}")
	public void deletebutton(String message) {
		elastomerEDD.mandatorymessages(message);
	}
	
	@Then("delete/submit/decline/obsolete/reactivate message appears on screen {string}")
	public void delete_message_appears_on_screen(String message) {
		
		elastomerEDD.deletemessageNotification(message);
	}
	
	@Then("verify the activity message {string}")
	public void verify_the_activity_message(String message) {
	   
		elastomerEDD.activityMessage(message);
	}
	
	@When("user click clone button")
	public void user_click_clone_button() {
	    
		elastomerEDD.cloneBtn();
	}
	
	@When("user click delete button")
	public void user_click_delete_button() {
	    
		elastomerEDD.deleteBtn();
	}
	
	@Then("navigate to {string}")
	public void navigate_to(String string) {
	    
		elastomerEDD.clickOnpagetoNavigate(string);
	}
	
	@When("user select Amine Applicability {string}")
	public void user_select_amine_applicability(String value) {
	  
		elastomerEDD.amineTempApplicability(value);
	}

	@When("user select Max Temp for Amine {string} and verify message  {string}")
	public void user_select_max_temp_for_amine_and_verify_message(String value, String message) {
	   
		elastomerEDD.amineTempMax(value, message);
	}
	
	@When("user select Compliance Standards {string}")
	public void user_select_compliance_standards(String string) throws InterruptedException {
	    
		elastomerEDD.complianceStandards(string);
	}
	
	@Then("verify the Mandatory/error message {string}")
	public void verify_the_mandatory_message(String message) {
	    
		elastomerEDD.mandatorymessages(message);
	}
	
	@And("enter comment {string}")
	public void enter_comment(String message) {
		
		elastomerEDD.enterComment(message);
	}
	
	@And("user click decline button")
	public void user_click_decline_button() throws InterruptedException {
		
		elastomerEDD.declineBtn();
	}
	
	@And("user click approve button")
	public void user_click_approve_button() {
		
		elastomerEDD.approveBtn();
	}
	
	@And("user close notification")
	public void user_close_notification() throws InterruptedException {
		
		elastomerEDD.closeNotification();
		
	}
	
	@Then("user click Obsolete button")
	public void user_click_obsolete_button() {
	   
		elastomerEDD.obsoleteBtn();
	}
	
	@Then("user click Reactivate button")
	public void user_click_reactivate_button() {
	   
		elastomerEDD.reactivateBtn();
	}
	
	
	@Then("check Record UID status is {string}")
	public void check_record_uid_status_is(String value) {
	    
		elastomerEDD.Status(value);
	}
	
	@Then("verify edr record is present in Summary page")
	public void verify_edr_record_is_present_in_summary_page() {
	    
		elastomerEDD.edrVerifyonSummaryPage();
	}

	@When("user enter Brine PH, Higher Limit {string} and verify message {string}")
	public void user_enter_brine_ph_higher_limit_and_verify_message(String value, String message) throws InterruptedException {
	    
		elastomerBCD.brinePhHighLimit(value, message);
		
	}
	
	@When("user enter Brine PH, Lower Limit {string} and verify message {string}")
	public void user_enter_brine_ph_lower_limit_and_verify_message(String value, String message) {
	    
		elastomerBCD.brinePhLowLimit(value, message);
		
	}
	
	@When("user set Brine PH Higher Acceptable {string}")
	public void user_set_brine_ph_higher_acceptable(String option) {
	   
		elastomerBCD.clickBrinePhHigherAcceptable();
		elasMatSpec.clickoption(option);
	}
	
	@When("user set Brine PH Lower Acceptable {string}")
	public void user_set_brine_ph_lower_acceptable(String option) {
	   
		elastomerBCD.clickbrinePhLowerAcceptable();
		elasMatSpec.clickoption(option);
	}
	
	@When("user set CaBr2 Acceptable {string}")
	public void user_set_ca_br2_acceptable(String string) throws InterruptedException {
		elastomerBCD.cabr2Acceptable(string);
	}
	
	@When("user set CaBr2 Temp applicable {string}")
	public void user_set_ca_br2_temp_applicable(String value) {
	    
		elastomerBCD.cabr2TempApplicable(value);
	}
	
	@When("user enter CaBr2 Temp Max {string} and verify message {string}")
	public void user_enter_ca_br2_temp_max_and_verify_message(String value, String message) {
	    
		elastomerBCD.cabr2TempMax(value, message);
	}
	
	@When("user set ZnBr2 Acceptable {string}")
	public void user_set_zn_br2_acceptable(String string) {
		elastomerBCD.znbr2Acceptable(string);
	}
	
	@When("user set ZnBr2 Temp applicable {string}")
	public void user_set_zn_br2_temp_applicable(String string) {
	    
		elastomerBCD.znbr2TempApplicable(string);
	}
	
	@When("user enter ZnBr2 Temp Max {string} and verify message {string}")
	public void user_enter_zn_br2_temp_max_and_verify_message(String value, String string2) {
	    
		elastomerBCD.znbr2TempMax(value, string2);
	}

	@Then("user open Record UID {string}")
	public void user_click_record_uid(String uid) throws InterruptedException {
	    
		elastomerBCD.openRecordUID(uid);
	}
	
	@When("user select HCL Acceptable {string}")
	public void user_select_hcl_acceptable(String value) {
	  
		elastomerEDD.hclAcceptable(value);
	}
	
	@When("user select HCL Temp Applicable {string}")
	public void user_select_hcl_temp_applicable(String value) {
	    
		elastomerEDD.hclTempApplicable(value);
	}
	
	@When("user enter HCL Temp Max {string} and verify message {string}")
	public void user_enter_hcl_temp_max_and_verify_message(String value, String message) {
	    
		elastomerEDD.hclTempMax(value, message);
	}

	@When("user select HF Acceptable {string}")
	public void user_select_hf_acceptable(String string) {
		
		elastomerEDD.hfAcceptable(string);
	}
	
	@When("user select HF Temp Applicable {string}")
	public void user_select_hf_temp_applicable(String value) {
	    
		elastomerEDD.hfTempApplicable(value);
	}

	@When("user enter HF Temp Max {string} and verify message {string}")
	public void user_enter_hf_temp_max_and_verify_message(String value, String message) {
	    
		elastomerEDD.hfTempMax(value, message);
	}
	
	@When("user select Acetic Acid Acceptable {string}")
	public void user_select_acetic_acid_acceptable(String value) {
	    
		elastomerEDD.aceticAcidAcceptable(value);
	}
	
	@When("user select Acetic Acid Temp Applicable {string}")
	public void user_select_acetic_acid_temp_applicable(String value) throws InterruptedException {
	    
		elastomerEDD.aceticAcidTempApplicable(value);
		
	}
	
	@When("user enter Acetic Acid Temp Max {string} and verify message {string}")
	public void user_enter_acetic_acid_temp_max_and_verify_message(String value, String message) {

		elastomerEDD.aceticAcidTempMax(value, message);
	}
	
	@When("user select Water Glycol Based Fluid Acceptable {string}")
	public void user_select_water_glycol_based_fluid_acceptable(String value) {
	    
		elastomerHFCD.waterGlycolFluidAcceptable();
		elasMatSpec.clickoption(value);
	}
	
	@When("user select Mineral Oil Applicable {string}")
	public void user_select_mineral_oil_applicable(String value) {
	    
		elastomerHFCD.mineralOilAcceptable(value);
	}
	
	@When("user select Mineral Oil Temp Applicable {string}")
	public void user_select_mineral_oil_temp_applicable(String value) {
	    
		elastomerHFCD.mineralOilTempApplicable(value);
	}
	
	@When("user enter Mineral Oil Temp Max {string}  and verify message {string}")
	public void user_enter_mineral_oil_temp_max_and_verify_message(String value, String message) {
	   
		elastomerHFCD.mineralOilTempMax(value, message);
	}
	
	@When("user select Synthetic Oil Applicable {string}")
	public void user_select_synthetic_oil_applicable(String value) {
		
		elastomerHFCD.synthaticOilAcceptable(value);
	}
	
	@When("user select Synthetic Oil Temp Applicable {string}")
	public void user_select_synthetic_oil_temp_applicable(String value) {
	    
		elastomerHFCD.synthaticOilTempApplicable(value);
	}
	
	@When("user enter Synthetic Oil Temp Max {string}  and verify message {string}")
	public void user_enter_synthetic_oil_temp_max_and_verify_message(String value, String message) {
	    
		elastomerHFCD.synthaticOilTempMax(value, message);
	}
	
	@When("user enter HF pH Higher Limit Acceptable {string} and verify {string}")
	public void user_enter_hf_p_h_higher_limit_acceptable_and_verify(String value, String message) {
	    
		elastomerHFCD.waterGlycolFluidPhHighLimit(value, message);
	}
	
	@When("user select HF pH Higher Limit Acceptable {string}")
	public void user_select_hf_p_h_higher_limit_acceptable(String value) {
	    
		elastomerHFCD.waterGlycolFluidPhHigherAcceptable(value);
	}
	
	@When("user select HF pH Higher Limit Acceptable Temp {string}")
	public void user_select_hf_p_h_higher_limit_acceptable_temp(String string) {
	    
		elastomerHFCD.waterGlycolFluidPhHigherTempApplicable(string);
	}
	
	@When("user select HF pH Higher Limit Temp Max {string} and verify {string}")
	public void user_select_hf_p_h_higher_limit_temp_max_and_verify(String string, String string2) {
	    
		elastomerHFCD.waterGlycolFluidPhHigherTempMax(string, string2);
	}
	
	@When("user enter HF pH Lower Limit Acceptable {string} and verify {string}")
	public void user_enter_hf_p_h_lower_limit_acceptable_and_verify(String string, String string2) {
	    
		elastomerHFCD.waterGlycolFluidPhLowLimit(string, string2);
	}
	
	@When("user select HF pH Lower Limit Acceptable {string}")
	public void user_select_hf_p_h_lower_limit_acceptable(String string) {
	    
		elastomerHFCD.waterGlycolFluidPhLowerAcceptable(string);
	}
	
	@When("user select HF pH Lower Limit Acceptable Temp {string}")
	public void user_select_hf_p_h_lower_limit_acceptable_temp(String string) {
	    
		elastomerHFCD.waterGlycolFluidPhLowerTempApplicable(string);
	}
	
	@When("user select HF pH Lower Limit Temp Max {string} and verify {string}")
	public void user_select_hf_p_h_lower_limit_temp_max_and_verify(String string, String string2) {

		elastomerHFCD.waterGlycolFluidPhLowerTempMax(string, string2);
		
	}
	
}
