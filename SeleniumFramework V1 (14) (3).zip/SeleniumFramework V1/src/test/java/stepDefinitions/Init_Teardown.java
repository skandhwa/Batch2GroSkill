package stepDefinitions;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;

import org.testng.annotations.AfterSuite;

import Utilities.CommonFunctions;
import Utilities.MyTestResults;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

//import cucumber.api.Scenario;
//import cucumber.api.java.After;
//import cucumber.api.java.Before;

public class Init_Teardown extends CommonFunctions {
	static TreeMap<String, String> map = null;
	static Entry<String, String> lastfile;
	public static Properties ppty;
	
	@Before(order = 0)
	public void initDriver() throws Exception {
		ppty = CommonFunctions.getObjDetails();
		String driverName = ppty.getProperty("browser");
		killChromeDriver();
		Thread.sleep(5000);
		intializeDriver(driverName);
		
	}

	public static void killChromeDriver() {
		try {
			Runtime.getRuntime().exec("TASKKILL /F /IM chromedriver.exe");
		} catch (Exception e) {
		}
	}

	@Before(order = 1)
	public void loginInit() throws Exception {
		actionInit();
		webDriverWaitInit();
		javascriptInit();
		loadBaseURL();
		/*String env = ppty.getProperty("env");
		try {
			if (env.equals("DEV")) {
				handleAADLogin();
			}
			drvWait.until(ExpectedConditions.urlContains("dashboard"));
			closeNotWnd();
		} catch (Exception e) {
		}
		Thread.sleep(3000);
		drvWait.until(ExpectedConditions.elementToBeClickable(
				By.xpath("//*[@id='appContainer']//*[contains(text(),'Operations Management')]")));*/
	}

	public static void setClipboardData(String str) {
		StringSelection ss = new StringSelection(str);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	}

	@After
	public void afterScenario(Scenario scenario) throws InterruptedException, IOException {
		if (getDriver() != null) {
			if (scenario.isFailed()) {
				String TestCaseName = scenario.getName();
				scenario.log("Current Page URL is " + getDriver().getCurrentUrl());
				messageHandler.log(TestCaseName + "is failed =  " + scenario.isFailed());
				//scenario.embed(embedScreenshot(), "image/png");
				scenario.attach(embedScreenshot(), "image/png",TestCaseName);//added attach and new string Testcasename
				
				File currentDir = new File(System.getProperty("user.dir") + "/target/Cucumberreports/Screenshots/");
				map = new TreeMap<String, String>();
			}
			logger.info("Test Cases Completed");
			getDriver().close();
		}
		//killChromeDriver();
		Thread.sleep(5000);
	}
	
	@AfterSuite
	public void quitDriver() {
		
		getDriver().quit();
	}
	
	@AfterStep    
	public void takeScreensot(Scenario ss) {
		
		Constants.Constants.ScenarioName = ss.getName();
		
		//capturing screenshot after failure
		//if(ss.isFailed()) {
		//MyTestResults.takescreenshot();}
	}

	@Before
	public static void SetUp(Scenario s) {
		messageHandler = s;
		CommonFunctions.WriteLog(" Test Case name  - " + s.getName());
		System.out.println(" Test Case name  - " + s.getName());
		// messageHandler.write();
	}
}
/*
 ** ==========~~~~~~~~~~==========~~~~~~~~~~==========~~~~~~~~~~==========
 ** Copyright (C) 2008-2019 Schlumberger,- All Rights Reserved Unauthorized
 * copying of this file, via any medium is strictly prohibited Proprietary and
 * confidential
 ** ==========~~~~~~~~~~==========~~~~~~~~~~==========~~~~~~~~~~==========
 */