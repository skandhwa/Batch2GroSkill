package stepDefinitions;

import PageFactoryElements.SealLifePredictionAppPageClass;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SealLifePredictionAppStepDefinition extends DriverIntialization{
	
	SealLifePredictionAppPageClass sealLifeApp = new SealLifePredictionAppPageClass(DriverIntialization.getDriver());
    
	
	@When("user search reference {string}")
	public void when_user_search_reference(String ref) {
		
		sealLifeApp.searchReference(ref);
		
	}
	
	@Then("verify the reference {string} is shown in result")
	public void then_verify_the_reference_is_shown_in_result(String value) {
		
		sealLifeApp.verifyReference(value);
	}
	
	@When("user clear the reference search box")
	public void user_clear_the_reference_search() {
		
		sealLifeApp.clearSearchRef();
	}
	
	@When("user open the reference {string}")
	public void user_open_the_reference(String value) throws InterruptedException {
	    
		sealLifeApp.openReference(value);
		Thread.sleep(5000);
	}

	@Then("user landed on Seal Life Prediction Requests")
	public void user_landed_on_seal_life_prediction_requests() {
	   
		sealLifeApp.displaySealLifeReqPage();
	}

	@When("user move to Refernece page")
	public void user_move_to_refernece() {
	    
		sealLifeApp.sealLifeReqPageClick();
		sealLifeApp.displaySealLifePrePage();
	}

	@When("user click on pdf icon")
	public void user_click_on_pdf_icon() {
	   
		sealLifeApp.clickPDF();
		
	}
	
	@Then("verify the reference data")
	public void verify_the_reference_data_and(DataTable dt) throws InterruptedException {
	    
		sealLifeApp.verifyReferenceData(dt);
	}

	@When("verify the data on Seal Life Request Page")
	public void verify_the_reference_data_and_on_request_page(DataTable dt) {
	   
		sealLifeApp.verifyReferenceDataonRequestPage(dt);
	}
	
	
	@When("user add the Trial Name {string}")
	public void user_add_the_trial_name(String value) {
	   
		sealLifeApp.setTrialName(value);
	}

	@When("user select Temperature {string} and Profile {string}")
	public void user_select_temperature_and_profile(String temp, String profile) {
	   
		sealLifeApp.clickTempandProfile(temp);
		sealLifeApp.clickTempandProfile(profile);
	}

	@When("user select Material {string} in Run Setting")
	public void user_select_material_in_run_setting(String mat) {

		sealLifeApp.setMaterial(mat);
	}

	@Then("check images is present")
	public void check_images_is_present() {

		sealLifeApp.verifyImage();
	}
	
	@Then("user verify Material data in Run Setting")
	public void user_verify_material_dat_in_run_setting(DataTable dt) {
		
		sealLifeApp.verifyMaterialData(dt);
	}
	
	@When("user add Temp {string} and Time {string}")
	public void user_add_temp_and_time(String temp, String time) {
	  
		sealLifeApp.setTemp(temp);
		sealLifeApp.setTime(time);
	}

	@Then("verify the Run input mandatory message {string}")
	public void verify_the_run_input_mandatory_message(String message) {

		sealLifeApp.verifyMandatMessage(message);
	}

	@Then("user add Fluid Environment {string}")
	public void user_add_fluid_environment(String value) throws InterruptedException {
		
		sealLifeApp.selectFluidType(value);
	}

	@Then("user add Multiplier {string}")
	public void user_add_multiplier(String value) {
	  
		sealLifeApp.setMultiplier(value);
	}
	
	
}
