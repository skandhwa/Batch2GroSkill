package stepDefinitions;
/**
 * @author Ethesh Gaur
 */
import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import PageFactoryElements.AMPartAndMaterialAdvisorAppPage;
import PageFactoryElements.AssetRepairSelectionAppPage;
import PageFactoryElements.CoatingSelectionAppPage;
import PageFactoryElements.MaterialAdvisorLoginPage;
import Utilities.CommonFunctions;
import Utilities.DriverIntialization;
import Utilities.ExcelConfiguration;
import Utilities.ExcelDataReader;
import Utilities.IDataReader;
import Utilities.MyTestResults;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.Given;

public class CoatingSelectionStepDef extends DriverIntialization{
	AssetRepairSelectionAppPage AssetRPage=new AssetRepairSelectionAppPage(DriverIntialization.getDriver());
	MaterialAdvisorLoginPage MALoginPage = new MaterialAdvisorLoginPage(DriverIntialization.getDriver());
	CoatingSelectionAppPage CSPage = new CoatingSelectionAppPage(DriverIntialization.getDriver());
	ScenarioContext sc=new ScenarioContext();
	List list = new ArrayList();
	
	
	@And("user selects app {string}")
	public void user_selects_app(String app) throws InterruptedException {

		MALoginPage.selectApp(app);
		
		
	}
	
	@When("user click the accept button")
	public void user_click_accept_button() {
		
		MALoginPage.acceptBtn();
	}

	@Given("enter url {string}")
	public void enter_url(String url) {
		
		DriverIntialization.getDriver().get(url);
	}
	
	@When("user click SignIn button")
	public void signin() throws InterruptedException {

		MALoginPage.clickSignIn();

	}

	@When("user click Product line")
	public void usre_click_Product_line() throws InterruptedException {

		CSPage.clickpLine();

	}

	@And("user select {string} in Product line")
	public void user_select_in_product_line(String options) throws InterruptedException {

		CSPage.selectOptions(options);
		sc.save(PageScenarioKeys.ProductLine, options);

	}

	@When("user click ServiceType/ProductCenter and select {string}")
	public void click_servicetype_and_select(String serviceType) throws InterruptedException {

		CSPage.clickServiceType();
		CSPage.selectOptions(serviceType);
	}
	
	@When("user click Business Purpose and select {string}")
	public void click_businessPurpose_and_select(String businessPurpose) throws InterruptedException {

		CSPage.clickbusinessPurpose();
		CSPage.selectOptions(businessPurpose);
	}

	@When("user set the Service Temperature to {string}")
	public void user_set_the_temp_to(String temp) throws InterruptedException {

		CSPage.setTemp(temp);

	}

	@When("user click Show Coating Options button")
	public void user_click_show_coating() {

		CSPage.clickShowCoatingoptionsBTN();
	}

	@When("user select Base Material {string}")
	public void user_select_base_material(String baseM) {

		CSPage.setBaseMaterial(baseM);
	}

	@When("user set the Yield Strength {string}")
	public void user_set_the_Yield_Strength(String yStr) {
		CSPage.setYieldS(yStr);
	}

	@When("user set Final Max Heat Temp {string}")
	public void Final_heat(String fHeat) {

		CSPage.setfinalMaxHeat(fHeat);  
	}   

	@When("user set Cold Worked Materials {string}")
	public void set_cold_worked_materials(String onoff) {
    
		CSPage.ClickColdWB(onoff);
	}

	@When("user select General Coating Features {string}")
	public void user_select_general_coating_features(String gsFeatures) throws InterruptedException {

		CSPage.selectGeneralCoatingFeatures(gsFeatures);
	}

	@When("user select Thread Area {string} and select Thread Type {string}")
	public void user_select_thread_area(String threadarea, String threadType) throws InterruptedException {
		sc.save(PageScenarioKeys.ThreadType, threadType); 
		CSPage.threadArea(threadarea);
		CSPage.threadType(threadType);
	}

	@When("user enter Thread name {string} and Number of make & break up {string}")
	public void user_enter_thread_name_and_thread_break(String name, String breaknum) throws InterruptedException {

		CSPage.setThreadName(name);
		CSPage.setThreadBreak(breaknum);
	}

	@Then("Coating Recommendation section is displayed")
	public void coatind_recommendation_section_is_dispalyed() throws AWTException, InterruptedException {

		CSPage.displayCoatingRecommendationSection();
		Thread.sleep(4000);
		CommonFunctions.pageup();

	}

	@When("user select Cylindrical Parts Inside Dia Coating {string} and Outside Dia Coating {string}")
	public void user_select_cylindrical_parts_inside_dia_coating_and_outside_dia_coating(String string, String string2) throws InterruptedException {
		CSPage.insideDiaCoating(string);
		CSPage.outSideDiaCoating(string2);

	}

	@When("user set the Part Length {string}")
	public void user_set_the_part_length(String len) {

		CSPage.setPartLen(len);
	}

	@When("user click Specific Coating Features")
	public void user_click_specific_coating_features() throws InterruptedException {

		CSPage.clickSCoatingF();
	}

	@When("select options under Specific Coating Features {string}")
	public void select_options_under_specific_coating_features(String options) throws InterruptedException {

		CSPage.selectfromSpecificCoatingFeatures(options);
	}

	@When("select options under Sealing Surface")
	public void select_under_sealing_surface(DataTable dt) throws InterruptedException {

		List<String> data = dt.asList();
		for(String option: data) {
			CSPage.selectmultOptions(option); 
		}

		//CSPage.selectOtionUnderSealingSurface(string);
	}

	@When("user click Environmental Requirements")
	public void user_click_environmental_requirements() throws InterruptedException {

		CSPage.clickEnvReq();
	}

	@When("User select options under Environmental Requirements")
	public void user_select_under_environmental_requirements(DataTable dt) throws InterruptedException {

		List<String> data = dt.asList();
		for(String option: data) {
			CSPage.selectmultOptions(option); 
		}

	}

	@When("user enter values under Downhole Corrosion Resistance h2s {string}, co2 {string} and chlorides {string}")
	public void user_enter_values_under_downhole_corrosion_resistance_h2s_co2_and_chlorides(String string, String string2, String string3) {

		CSPage.seth2sPartialPressure(string);
		CSPage.setco2PartialPressure(string2);
		CSPage.setChlorides(string3);
	}

	@When("user click Functional Requirements")
	public void user_click_functional_requirements() {

		CSPage.clickfunctionalReq();
	}

	@When("select options under Functional Requirements")
	public void select_options_under_functional_requirements(DataTable dt) throws InterruptedException {
		List<String> data = dt.asList();
		for(String option: data) {
			CSPage.selectmultOptions(option); 
		}
		Thread.sleep(3000);
	}

	@When("user click Special Requirements")
	public void user_click_special_requirements() {

		CSPage.clickspecialOptionsRequired();
	}

	@Then("user verify mandatory fields error messages")
	public void user_verify_mandatory_fields_error_messages(List<Map<String, String>> dataTable) throws InterruptedException {

		for (Map<String, String> dataRow : dataTable) {
			CSPage.errorMessages(dataRow.get("Field"), dataRow.get("Message"));
		}

	}

	@When("user set the Service Temperature and verify the messages")
	public void user_set_the_service_temperature(List<Map<String, String>> dataTable) throws InterruptedException {

		for (Map<String, String> dataRow : dataTable) {
			CSPage.setTemp(dataRow.get("Temp"));
			CSPage.errorMessageFields(dataRow.get("Message"));
			CSPage.clearTemp();
		}

	}

	@Then("user enter Final Maximum Heat Treat and verify the messages")
	public void user_enter_final_maximum_heat_treat_and_verify_the_messages(List<Map<String, String>> dt) {


		for (Map<String, String> dataRow : dt) {
			CSPage.setfinalMaxHeat(dataRow.get("Temp"));
			CSPage.errorMessageFields(dataRow.get("Message"));
			CSPage.clearfinalHeatTreatTemp();
		}
	}

	@Then("user enter Number of Make & Break Ups and verify the messages")
	public void user_enter_number_of_make_break_ups_and_verify_the_messages(List<Map<String, String>> dataTable) {

		for (Map<String, String> dataRow : dataTable) {
			CSPage.setThreadBreak(dataRow.get("Temp"));
			CSPage.errorMessageFields(dataRow.get("Message"));
			CSPage.clearThreadBreak();
		}
	}


	@Then("user enter Part Length and verify the messages")
	public void user_enter_part_length_and_verify_the_messages(List<Map<String, String>> dataTable) {

		for (Map<String, String> dataRow : dataTable) {
			CSPage.setPartLen(dataRow.get("Temp"));
			CSPage.errorMessageFields(dataRow.get("Message"));
			CSPage.clearPartLen();
		}
	}

	@Then("user enter Inside Dia Min and verify the messages")
	public void user_enter_inside_dia_min_and_verify_the_messages(List<Map<String, String>> dataTable) throws InterruptedException {

		for (Map<String, String> dataRow : dataTable) {
			CSPage.setInsideDiaMin(dataRow.get("Temp"));
			CSPage.errorMessageFields(dataRow.get("Message"));
			CSPage.clearinsideDiaMin();
		}
	}
	
	

	@When("user click {string} Button")
	public void user_click_button(String button) throws InterruptedException {

		CSPage.clickBTNonRecommendScr(button);

	}

	@Then("Reset popup appears with message {string}")
	public void reset_popup_appears_with_message(String message) {

		CSPage.resetPopUp();
		CSPage.resetPopupMessage(message);
	}

	@Then("Coating Selection section is displayed")
	public void coating_selection_section_is_displayed() throws AWTException, InterruptedException {

		CSPage.CoatingSelection();
		CommonFunctions.pageup();
		Thread.sleep(5000);
	}

	@When("user select {string} Options in Coating Recommendation")
	public void user_select_the_options_in_coating_recommendation(String n) throws AWTException, InterruptedException {
		sc.save(PageScenarioKeys.Options, n); 
		CSPage.selectBox(n);

	} 
	@When("user expand the option {int}")
	public void user_expand_the_option(int n) throws InterruptedException {

		CSPage.expandOption(n);

	}

	@Then("verify the data in option")
	public void verify_the_data_in_option(List<Map<String, String>> dataTable) throws InterruptedException {

		CSPage.verifyDatailReport(dataTable);
	}

	@Then("fetch the Coating Selection Reference number")
	public void fetch_the_coating_selection_reference_number() {

		sc.save(PageScenarioKeys.CSRNumber, CSPage.fetchCSRNumber()); 

	}

	@Then("verify the Coating Selection Reference number in Print page")
	public void verify_the_coating_selection_reference_number_in_print_page() throws InterruptedException {

		CommonFunctions.switchToWindow();
		CSPage.csrNumberinPrintPage();
		String csr = sc.getData(PageScenarioKeys.CSRNumber); 
		if(CSPage.csrNumberinPrintPage().contains(csr)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}

	}

	@Then("verify the Coating Recommendations Section, Product Line and Schlumberger Confidential message {string} in print page")
	public void verify_the_and_schlumberger_confidential_message_in_print_page(String string) throws InterruptedException {

		CSPage.displayCoatingRecommendationSection();
		CSPage.confidentialMessage(string);
		CSPage.verifyProductlineinPrintPage(sc.getData(PageScenarioKeys.ProductLine));

	}

	@Then("user Coating Comparison Pop up displayed")
	public void user_coating_comparison_pop_up_displayed() throws InterruptedException {

		CSPage.displayCoatingComparison();

	}

	@Then("user enter product line and verify")
	public void user_enter_product_line_and_verify(List<Map<String, String>> dataTable) throws InterruptedException {

		CSPage.verifyProductLine(dataTable);
	}

	@Then("verify Material Sub Class {string} and Material Class is {string}")
	public void verify_material_sub_class_and_material_class_is(String string, String string2) {

		CSPage.materialSubClass(string);
		CSPage.materialClass(string2);
	}

	@And("user verify data on the Compare pop up")
	public void user_verify_data_on_the_compare(List<Map<String, String>> dataTable) throws InterruptedException {

		if(sc.getData(PageScenarioKeys.Options).equals("1")) {
			CSPage.verifyDatailCompare(dataTable);}
		if(sc.getData(PageScenarioKeys.Options).equals("2")) {
			CSPage.verifyDatailComparewith2(dataTable);
		}
		if(sc.getData(PageScenarioKeys.Options).equals("3")) {
			CSPage.verifyDatailComparewith(dataTable, null);;
		}
	}

	@DataTableType
	public IDataReader excelToDataTable(Map<String, String> entry) {
		ExcelConfiguration config= new ExcelConfiguration.ExcelConfigurationBuilder()
				.setFileName(entry.get("Excel"))
				.setFileLocation(System.getProperty("user.dir") + entry.get("Location"))
				.setSheetName(entry.get("Sheet"))
				.build();

		return new ExcelDataReader(config);
	}

	@When("user read the data from excel")
	public void user_read_the_data_from_excel(IDataReader dataTable) {

		List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			System.out.println("Data from the Excel"+ data.get(i).get("Base Material"));}

	}

	@When("user select Base Material from excel data")
	public void user_select_base_material_from_excel_data(IDataReader dataTable) throws InterruptedException {

		List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			CSPage.setBaseMaterial(data.get(i).get("Base Material").replaceAll("^\"|\"$", ""));
			CSPage.materialSubClass(data.get(i).get("Material Sub Class").replaceAll("^\"|\"$", ""));
			CSPage.materialClass(data.get(i).get("Material Class").replaceAll("^\"|\"$", ""));
			CSPage.clearBaseMaterial();
		}
	}

	@When("user enter Thread name data from Excel sheet")
	public void user_enter_thread_name_data_from_excel_sheet(IDataReader dataTable) throws InterruptedException {

		List<Map<String, String>> data=dataTable.getAllRows();
		if(sc.getData(PageScenarioKeys.ThreadType).equals("Non-premium")) {
			for(int i=0;i<data.size();i++) {
				CSPage.setThreadName(data.get(i).get("Non-premium"));
				CSPage.verifyThreadName(data.get(i).get("Non-premium"));
			}}else {
		if(sc.getData(PageScenarioKeys.ThreadType).equals("Premium")) {
			for(int i=0;i<data.size();i++) {
				CSPage.setThreadName(data.get(i).get("Premium"));
				CSPage.verifyThreadName(data.get(i).get("Premium"));
				}
				}}
	}
	
	
	@Then("verify message {string} disappeared")
	public void verify_message_disappeared(String string) {
	   
	  CSPage.messageDisappeared(string);
	}
	
	@Then("verify the hydraulic line")
	public void verify_the_hydraulic_line() {
	    
		CSPage.displayHydraulicLine();
	}
	
	@Then("verify ServiceType and ProductCenter data")
	public void verify_service_type_data(DataTable dataTable) {
		
		if(sc.getData(PageScenarioKeys.ThreadType).equals("Completion")){
			
		}
	   
		
	}
	
	@When("user click ServiceType/ProductCenter and verify data")
	public void click_servicetype_and_select(List<Map<String, String>> dt) throws InterruptedException {

		CSPage.clickServiceType();
		CSPage.verifyOptions(dt);
	}
	
	@Then("verify Special Notes {string}")
	public void verify_special_notes(String string) {
	    
		CSPage.verifySpecialNotes(string);
	}
	
	@When("user open {string} link for Coating name {string}")
	public void user_open_link(String link, String coatingName) throws InterruptedException {
	    
		CSPage.clickLink(link, coatingName);
	}
	
	@Then("verify the table in Supplier info pop up")
	public void verify_the_table_in_supplier_info_pop_up(List<Map<String, String>> dataTable) {
		
		CSPage.verifySupplierInfoTable(dataTable);
	    
	}
	
	
	@Then("user verify Coating Specification with Coating Name from excel data")
	public void user_verify_coating_specification_with_coating_name(IDataReader dataTable) throws InterruptedException {
		
		List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			AssetRPage.selectCoatingName(data.get(i).get("Coating Name").replaceAll("^\"|\"$", ""));
			list.add(data.get(i).get("Coating Name"));
			Thread.sleep(2000);
		}
	}

	
	
}	