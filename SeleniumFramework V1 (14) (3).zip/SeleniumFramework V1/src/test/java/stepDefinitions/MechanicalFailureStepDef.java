package stepDefinitions;

import java.util.List;
import java.util.Map;

import PageFactoryElements.MechanicalFailureDiagnosticApp;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MechanicalFailureStepDef extends DriverIntialization {

	MyRequestCreateRequestPage matAdvCreReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());
	MechanicalFailureDiagnosticApp mfda =  new MechanicalFailureDiagnosticApp(DriverIntialization.getDriver());
	
	@When("user Select Field Application {string}")
	public void user_select_field_application(String name) {
	 
		mfda.fieldApp();
	    matAdvCreReq.selectOption(name);
		
	}
	
	@When("user Select Lifecycle Information {string}")
	public void user_select_Lifecycle_Informations(String status) {
	 
		mfda.lifeCycleInfo(status);
		
	}
	
	@Then("verify Your Section {string} as {string}")
	public void verify_your_section_as(String string, String string2) {
	    
		mfda.yourSection(string, string2);
	}
	
	@Then("click Next button and verify {string} section displayed")
	public void click_next_button_and_verify_section_displayed(String string) {
	    
		mfda.clickNextBtn();
		mfda.verifyNextSection(string);
	}
	
	@When("user select Visual/Failure Damage/Location options")
	public void user_select_visual_damage_options(List<Map<String, String>> dataTable) {
	    
		mfda.selectVisualDamage(dataTable);
	}
	
	@When("user select Materials options")
	public void user_select_materials_options(List<Map<String, String>> dataTable) {
	    
		mfda.selectVisualDamage(dataTable);
	}
	
	@When("user add Fracture Plane Orientation {string}")
	public void user_add_fracture_plane_orientation(String name) {
	    
		mfda.fracturePlaneOrientation();
		matAdvCreReq.selectOption(name);
		
	}
	
	@When("add Supp pH {string} and message {string}")
	public void add_supp_p_h_and_message(String value, String string2) {
	    
		mfda.suppPH(value);
		mfda.messageError(string2);
	}
	
	@When("add Supp pH {string}")
	public void add_supp_p_h(String value) {

		mfda.suppPH(value);
	}
	
	@When("add Bottomhole Temp {string} and message {string}")
	public void add_bottomhole_temp_and_message(String string, String string2) {
	    
		mfda.bottomHoleTemp(string);
		mfda.messageError(string2);
	}
	
	@When("add Bottomhole Temp {string}")
	public void add_bottomhole_temp(String string) {
	    
		mfda.bottomHoleTemp(string);
	}
	
	@When("add Bottomhole Pressure {string} and message {string}")
	public void add_bottomhole_pressure_and_message(String string, String string2) {
	    
		mfda.bottomholePressure(string);
		mfda.messageError(string2);
	}
	
	@When("add Bottomhole Pressure {string}")
	public void add_bottomhole_pressure(String string) {

		mfda.bottomholePressure(string);
	}

	@When("user select Previous Button of {string}")
	public void user_select_previous_button_of(String string) {
	    
		mfda.clickPreviousButton(string);
	}
	
	@Then("user click Failure Location Characteristics")
	public void user_click_failure_location_characteristics() {
	    
		mfda.failureLocationCharac();
	}
	
	@Then("user click Materials")
	public void user_click_materials() {
	    
		mfda.materialsPart();
	}
	
	@Then("user move to {string}")
	public void user_move_to(String section) {
		
		mfda.movetoSection(section);
	}
	
	@When("user select Material Grade as {string}")
	public void user_select_material_grade_as(String name) throws InterruptedException {
	    
		mfda.materialGrade();
		matAdvCreReq.selectOption(name);
		Thread.sleep(2000);
		
	}

	@Then("verify the Material Class as {string} and Material Sub Class {string}")
	public void verify_the_material_class_as_and_material_sub_class(String string, String string2) {
	    
		mfda.getValueofMaterialClass(string);
		mfda.getValueofMaterialSubClass(string2);
	}
	
	@Then("user add Standard Compliance {string}")
	public void user_add_standard_compliance(String string) {
	    
		mfda.compStandards();
		matAdvCreReq.selectOption(string);
	}
	
	@Then("verify the Standard Compliance on Your Section {string}")
	public void verify_the_standard_compliance_on_your_section(String string) {
	    
		mfda.messageError(string);
	}
	
	 @And("user click Standard Compliance")
	 public void user_click_standard_comp() {
		 
		 mfda.clickStandardsComp();
	 }
	 
	 @When("user click Reset Button")
	 public void user_click_reset_button() {
	       
		 mfda.resetBtn();
	 }
	 
	 @Then("verify {string} section displayed")
	 public void verify_section_displayed(String string) {
	     
		 mfda.verifyNextSection(string);
	 }
	 
	 @When("user click Submit button on Final Review")
	 public void user_click_submit_button_on_final_review() {
	     
		 mfda.submitBtn();
	 }
	 
	 @Then("user capture Diagonastic Reference")
	 public void user_capture_diagonastic_reference() {
	     
		 mfda.fetchDiagRef();
	 }
	 
	 @When("user click SME Review Add button")
	 public void user_click_sme_review_add_button() {
	     
		 mfda.smeReviewAddButton();
	 }
	 
	 @When("user select Validation Result {string}")
	 public void user_select_validation_result(String string) {
	     
		 mfda.validationResult();
		 matAdvCreReq.selectOption(string);
	 }
	 
	 @When("add the SME Review Comment {string}")
	 public void add_the_sme_review_comment(String string) {
	     
		 mfda.addComment(string);
	 }
	 
	 @Then("error message {string} is dispalyed")
	 public void error_message_is_dispalyed(String string) {
	     
		 mfda.messageError(string);
	 }
	 
	 @Then("verify Validation Result {string}")
	 public void verify_validation_result(String string) {
	     
		 mfda.verifyValidationResult(string);
	 }
	
}
