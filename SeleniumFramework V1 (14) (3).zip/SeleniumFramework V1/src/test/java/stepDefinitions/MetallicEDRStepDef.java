package stepDefinitions;

import PageFactoryElements.ElastomerMaterialSpecificationPage;
import PageFactoryElements.MaterialAdvisorMyRequest;
import PageFactoryElements.MetallicEDRPage;
import PageFactoryElements.MetallicMaterialSpecificationPage;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MetallicEDRStepDef extends DriverIntialization{

	MetallicEDRPage metallicEDR = new MetallicEDRPage(DriverIntialization.getDriver());
	ElastomerMaterialSpecificationPage elasMatSpec= new ElastomerMaterialSpecificationPage(DriverIntialization.getDriver());
	MyRequestCreateRequestPage matAdvCreReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());


	@When("user select Nace {string}")
	public void user_select_nace(String value) {

		metallicEDR.clickNace();
		matAdvCreReq.selectOption(value);
	}

	@When("user select Temp Min {string}")
	public void user_select_temp_min(String value) throws InterruptedException {

		metallicEDR.tempMin(value);
	}

	@When("user select Temp Max {string}")
	public void user_select_temp_max(String value) throws InterruptedException {

		metallicEDR.tempMax(value);
	}
	
	@When("user select Temp Min {string} and verify message {string}")
	public void user_select_temp_min_and_verify_message(String value, String message) throws InterruptedException {

		metallicEDR.tempMin(value, message);
	}

	@When("user select Temp Max {string} and verify message {string}")
	public void user_select_temp_max_and_verify_message(String value, String message) throws InterruptedException {

		metallicEDR.tempMax(value, message);
	}

	@Then("user enter Service Duration/Life {string}")
	public void user_enter_service_duration(String string) throws InterruptedException {

		elasMatSpec.serviceDuration(string);

	}

	@When("user enter H2S Partial Pressure {string} and verify message {string}")
	public void user_enter_h2s_partial_pressure_and_verify_message(String value, String  message) {

		metallicEDR.h2sPartialPressureMax(value, message);
	}

	@When("user enter CO2 Partial Pressure {string} and verify message {string}")
	public void user_enter_co2_partial_pressure_and_verify_message(String value, String  message) {

		metallicEDR.co2PartialPressureMax(value, message);
	}

	@When("user enter Chlorides {string} and verify message {string}")
	public void user_enter_chlorides_and_verify_message(String value, String  message) {

		metallicEDR.chloridesMax(value, message);
	}

	@When("user enter pH Min {string} and verify message {string}")
	public void user_enter_p_h_min_and_verify_message(String value, String  message) {

		metallicEDR.phMin(value, message);
	}

	@When("user enter pH Max {string} and verify message {string}")
	public void user_enter_p_h_max_and_verify_message(String value, String  message) {

		metallicEDR.phMax(value, message);
	}

	@When("user enter Water Cut {string} and verify message {string}")
	public void user_enter_water_cut_and_verify_message(String value, String  message) {

		metallicEDR.waterCutMax(value, message);
	}

	@When("user enter Mercury {string}")
	public void user_enter_mercury(String string) {

		metallicEDR.mercuryMax(string);
	}

	@When("user enter Sulfur Resistant {string}")
	public void user_enter_sulfur_resistant(String value) {

		metallicEDR.sulfurResistant();
		matAdvCreReq.selectOption(value);
	}

	@When("user enter Stress Condition {string}")
	public void user_enter_stress_condition(String value) {

		metallicEDR.stressCondition();
		matAdvCreReq.selectOption(value);
	}

	@When("user enter Maximum Tensile Stress {string} and verify message {string}")
	public void user_enter_maximum_tensile_stress_and_verify_message(String value, String message) {

		metallicEDR.maxTensileStress(value, message);
	}
	
	@When("user add Brine Description {string}")
	public void user_add_brine_description(String value) {
	    
		metallicEDR.brineDesc();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user enter Acceptance Temperature {string} and verify message {string}")
	public void user_enter_acceptance_temperature_and_veriy_message(String value, String message) {
	    
		metallicEDR.accpTemp(value, message);
	}
	
	@When("user enter Stress Condition for BCD {string}")
	public void user_enter_stress_condition_for_bcd(String value) {
	    
		metallicEDR.stressConditionBCD();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user enter Maximum Tensile Stress for BCD {string} and verify {string}")
	public void user_enter_maximum_tensile_stress_for_bcd_and_verify(String value, String message) {
	    
		metallicEDR.maxTensileStressBCD(value, message);
	}
	
	@When("user enter Brine Exposure Period {string} and verify {string}")
	public void user_enter_brine_exposure_period_and_verify(String value, String message) {
	    
		metallicEDR.brineExposurePeriod(value, message);
	}
	
	@When("user select Pitting Risk {string}")
	public void user_select_pitting_risk(String value) {
	    
		metallicEDR.pittingRisk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select General SCC Risk {string}")
	public void user_select_general_scc_risk(String value) {
	    
		metallicEDR.sccGeneralRisk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select SCC Risk in CO2 presence {string}")
	public void user_select_scc_risk_in_co2_presence(String value) {
	    
		metallicEDR.sccCo2Risk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select SCC Risk in H2S presence {string}")
	public void user_select_scc_risk_in_h2s_presence(String value) {
	    
		metallicEDR.sccH2sRisk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select SCC Risk in Oxygen presence {string}")
	public void user_select_scc_risk_in_oxygen_presence(String value) {
	    
		metallicEDR.sccOxyRisk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user click ACD plus button")
	public void user_click_acd_plus_button() {
	    
		metallicEDR.acdPlus();
	}
	
	@Then("user add Acid Description {string}")
	public void user_add_acid_description(String value) {
	    
		metallicEDR.acidDescription();
		matAdvCreReq.selectOption(value);
	}
	
	@Then("user add Acid Inhibition {string}")
	public void user_add_acid_inhibition(String value) {
	    
		metallicEDR.acidInhibilition();
		matAdvCreReq.selectOption(value);
	}
	
	@Then("user add Inhibittor Description {string}")
	public void user_add_inhibittor_description(String value) {
	    
		metallicEDR.inhibitorDescription(value);
	}
	
	@Then("user enter ACD Temp Max {string} and verify {string}")
	public void user_enter_acd_temp_max_and_verify(String value, String message) throws InterruptedException {
	    
		metallicEDR.tempMaxACD(value, message);
	}
	
	@Then("user enter Acid/HFCD Exposure Period {string}")
	public void user_enter_acid_exposure_period(String value) {
	    
		metallicEDR.acidExposurePeriod(value);
	}
	
	@Then("user enter Corrosion Rate {string}")
	public void user_enter_corrosion_rate(String value) {
	    
		metallicEDR.corrosionRate(value);
	}
	
	@Then("user enter Corrosion Notes {string}")
	public void user_enter_corrosion_notes(String notes) {
	    
		metallicEDR.corrosionNotes(notes);
	}
	
	@When("user select Overall Risk {string}")
	public void user_select_overapp_risk(String value) {
	    
		metallicEDR.overallRisk();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user click HFCD plus button")
	public void user_click_hfcd_plus_button() {
	    
		metallicEDR.hfcdPlus();
	}
	
	@Then("user add Hydraulic Fluid Description {string}")
	public void user_add_hydraulic_fluid_description(String value) {
	    
		metallicEDR.hydraulicFluidDesc();
		matAdvCreReq.selectOption(value);
	}
	
	@Then("user add HFCD Temp Min {string} and verify {string}")
	public void user_add_hfcd_temp_min_and_verify(String value, String message) {
	    
		metallicEDR.hfcdTempMin(value, message);
	}
	
	@Then("user add HFCD Temp Max {string} and verify {string}")
	public void user_add_hfcd_temp_max_and_verify(String value, String message) {

		metallicEDR.hfcdTempMax(value, message);
	}
	
	@Then("user select Coating Description {string}")
	public void user_select_coating_description(String value) {
	    
		metallicEDR.coatingDesc();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user click IWCD plus button")
	public void user_click_iwcd_plus_button() {
	    
		metallicEDR.iwcdPlus();
	}
	
	@Then("user select Water Source {string}")
	public void user_select_water_source(String value) {
	    
		metallicEDR.waterSource();
		matAdvCreReq.selectOption(value);
	}
	
	@Then("user enter Disolve Oxygen Max {string} and verify {string}")
	public void user_enter_disolve_oxygen_max_and_verify(String string, String string2) {
	    
		metallicEDR.disolveOxy(string, string2);
	}
	
	@Then("user enter Injection Temperature Max {string} and verify {string}")
	public void user_enter_injection_temperature_max_and_verify(String value, String message) {
	    
		metallicEDR.injectionTempMax(value, message);
	}
	
	@Then("user enter Water pH Min {string} and verify {string}")
	public void user_enter_water_p_h_min_and_verify(String value, String message) {
	    
		metallicEDR.waterpHMin(value, message);
	}
	
	@Then("user enter Water pH Max {string} and verify {string}")
	public void user_enter_water_p_h_max_and_verify(String value, String message) {
	    
		metallicEDR.waterpHMax(value, message);
	}
	
	@When("user select Residual Chlorine Acceptable {string}")
	public void user_select_residual_chlorine_acceptable(String value) {
	    
		metallicEDR.resChlorineAcc();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select Seal Surface Equipement {string}")
	public void user_select_seal_surface_equipement(String value) {
	    
		metallicEDR.sealEquipmentAccept();
		matAdvCreReq.selectOption(value);
	}
	
	@When("user select Non-Seal Surface Equipement {string}")
	public void user_select_non_seal_surface_equipement(String value) {
	    
		metallicEDR.nonSealEquipmentAccept();
		matAdvCreReq.selectOption(value);
	}
	
	@And("user click home button")
	public void user_click_home_button() {
		
		metallicEDR.homeBtn();
	}

}
