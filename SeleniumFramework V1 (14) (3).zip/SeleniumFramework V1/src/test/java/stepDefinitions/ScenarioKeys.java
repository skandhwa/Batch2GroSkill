package stepDefinitions;

public interface ScenarioKeys {

}

