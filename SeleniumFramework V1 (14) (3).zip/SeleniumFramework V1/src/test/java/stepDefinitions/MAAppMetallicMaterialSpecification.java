package stepDefinitions;

import PageFactoryElements.MaterialAdvisorMyRequest;
import PageFactoryElements.MetallicMaterialSpecificationPage;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MAAppMetallicMaterialSpecification {

	
	MetallicMaterialSpecificationPage metallicSpec = new MetallicMaterialSpecificationPage(DriverIntialization.getDriver());
	MaterialAdvisorMyRequest matAdMyReq= new MaterialAdvisorMyRequest(DriverIntialization.getDriver());
	MyRequestCreateRequestPage matAdvCreReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());

	@When("user click Metallic button")
	public void user_click_metallic_button() throws InterruptedException {
	   
		metallicSpec.metallicTab();
		
	}
	
	@When("user click Metallic Specifications button")
	public void user_click_metallic_spec_btn() throws InterruptedException {
		
		metallicSpec.clickSpecBtn();
	}
	
	@When("user select Material Sub Class {string}")
	public void user_select_material_sub_class(String value) throws InterruptedException {
	    
		metallicSpec.materialSubClass(value);
	}
	
	@When("user select Spec type {string}")
	public void user_select_spec_type(String string) {
		
		metallicSpec.clickSpecType();
		matAdvCreReq.selectOption(string);
	}
	
	@When("user click Create Material Specification button")
	public void user_click_create_material_specification_button() {
	    
		metallicSpec.createMateSpecs();
	}
	

	@When("user select UNS Number {string}")
	public void user_select_uns_number(String string) {
	    
		metallicSpec.unsNumber();
		matAdvCreReq.selectOption(string);
	}
	
	@When("user add NACE Alloy Category {string}")
	public void user_add_nace_alloy_category(String string) {
	   
		metallicSpec.NACEalloyCategory();
		matAdvCreReq.selectOption(string);
	}
	
	@When("user add Yield Min {string} and Yield Max {string}")
	public void user_add_yield_min_and_yield_max(String string, String string2) throws InterruptedException {
	    
		metallicSpec.yieldMin(string2);
		metallicSpec.yieldMax(string2);
	}
	
	@When("user add Hardness1 Min {string}, Hardness2 Max {string} and Hardness1 Unit {string}")
	public void user_add_hardness1_hardness2_and_hardness1_unit(String string, String string2, String string3) {
	    
		metallicSpec.hardness1Min(string);
		metallicSpec.hardness1Max(string2);
		metallicSpec.hardness1Unit(string3);
		
	}

	@When("user add Hardness2 Min {string}, Hardness2 Max {string} and Hardness2 Unit {string}")
	public void user_add_hardness2_hardness2_and_hardness2_unit(String string, String string2, String string3) {
	    
		metallicSpec.hardness2Min(string);
		metallicSpec.hardness2Max(string2);
		metallicSpec.hardness2Unit(string3);
	}
	
	@When("user select Material Condition {string}")
	public void user_select_material_condition(String string) {
	    
		metallicSpec.materialConditions(string);
		matAdvCreReq.selectOption(string);
	}
	

	@When("user select Product Form {string}")
	public void user_select_product_form(String string) {
	    
		metallicSpec.productForm(string);
		matAdvCreReq.selectOption(string);
	}
	
	@When("user select Specification Type {string}")
	public void user_select_specification_type(String string) {
	    
		metallicSpec.clickSpecType();
		matAdvCreReq.selectOption(string);
		if(string.contentEquals("RTD")) {
			metallicSpec.messageRTD();
			metallicSpec.RTDOKButton();
		}
	}
	
	@When("user add Customer Name {string}")
	public void user_add_customer_name(String string) {
	    
		metallicSpec.customerId();
		matAdvCreReq.selectOption(string);
		//metallicSpec.addButton();
	}
	
	@When("user click on Supplier Tab")
	public void user_click_on_supplier_tab() {
	    
		metallicSpec.supplierTab();
	}
	
	@When("user add Supplier {string}")
	public void user_add_supplier(String string) throws InterruptedException {
	   
		metallicSpec.supplierName(string);
		matAdvCreReq.selectOption(string);
		matAdvCreReq.addBtn();
	}
	
	@Then("user verify Supplier name {string} and Country {string}")
	public void user_verify_supplier_name_and_country(String sup, String country) {
	    
		metallicSpec.countryAndSup(country);
		metallicSpec.countryAndSup(sup);
	}
	
	@Then("user remove supplier {string} from text box")
	public void user_remove_supplier_from_text_box(String string) {
	    
		metallicSpec.supplierName(string);
		matAdvCreReq.selectOption(string);
		metallicSpec.clearButton();
	}
	
	@Then("remove supplier {string}")
	public void remove_supplier(String sup) {
	    
		metallicSpec.deleteSupplier(sup);
		metallicSpec.okButton();
	}
	
	@When("user click Edit button of Material Specification")
	public void user_click_edit_button_of_material_specification() {
	    
		metallicSpec.editButton();
	}
	
	@When("user open the Specification {string}")
	public void user_open_the_specification(String spec) {
	    
		metallicSpec.openSpec(spec);
	}
	
	@When("user click plus button of {string}")
	public void user_click_plus_button_of_and(String edr) {

		metallicSpec.selectEDRfromEDRSummary(edr);
	}



}
