package stepDefinitions;
/**
 * 
 * @author Ethesh
 */
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import PageFactoryElements.AssetRepairSelectionAppPage;
import PageFactoryElements.CoatingSelectionAppPage;
import Utilities.DriverIntialization;
import Utilities.IDataReader;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AssetRepairSelectionApp extends DriverIntialization {

	AssetRepairSelectionAppPage AssetRPage=new AssetRepairSelectionAppPage(DriverIntialization.getDriver());
	ScenarioContext sc=new ScenarioContext();
	CoatingSelectionAppPage CSPage = new CoatingSelectionAppPage(DriverIntialization.getDriver());

	@Then("user verify {string}")
	public void then_user_verify(String option) throws InterruptedException {

		AssetRPage.selectmultOptions(option);
	}

	@And("user click {string}")
	public void user_click(String option) throws InterruptedException {

		AssetRPage.clickCurrentStage(option);
	}
	
	@And("user click Material App")
	public void user_click_material_app() throws InterruptedException {
		
		AssetRPage.matApp();
	}


	@Then("verify Coating Specification for Coating Name {string}")
	public void verify_coating_specification(String name, List<Map<String, String>> dataTable) throws InterruptedException {

		//AssetRPage.selectCoatingName(name);
		AssetRPage.coatingSpecsSelection(dataTable, name);

	}


	@Then("user verify Coating Specification Information name {string} and data below")
	public void user_verify_coating_specification_information_name_and_data_below(String name, List<Map<String, String>> dataTable) throws InterruptedException {

		AssetRPage.verifyCoatingSpecInfo(name, dataTable);
	}

	@When("enter Damage Severity {string}")
	public void enter_damage_severity(String option) {

		AssetRPage.clickDamageSeverity();
		AssetRPage.clickOption(option);
	}

	@Then("verify the Damage type data")
	public void verify_the_damage_type_data(IDataReader dataTable) throws InterruptedException {

		AssetRPage.verifyDamageType(dataTable);

	}

	@When("enter Damage Type {string}")
	public void enter_damage_type(String option) throws InterruptedException {

		AssetRPage.setDamageType(option);
	}

	@When("click Submit button")
	public void when_click_submit_button() {

		AssetRPage.clickSubmitBtn();
	}

	@Then("{string} section is displayed")
	public void asset_repair_recommendation_section_is_displayed(String name) {

		AssetRPage.verifyAssetRepairRecommendation(name);
	}

	@Then("verify Asset Repair Selection Reference Number")
	public void verify_asset_repair_selection_reference_number() {

		AssetRPage.gettheReferenceNumber();
		System.out.println("Test number " + AssetRPage.gettheReferenceNumber());
		sc.save(PageScenarioKeys.ARSRNumber, AssetRPage.gettheReferenceNumber());

	}

	@Then("verify Asset Repair Selection Reference Number, {string} section and Schlumberger Confidential message {string} in print page")
	public void verify_asset_repair_selection_reference_number_recommendation_section_and_schlumberger_confidential_message_in_print_page(String recom, String string) throws InterruptedException {

		CSPage.confidentialMessage(string);
		AssetRPage.referenceNumberinPrint(sc.getData(PageScenarioKeys.ARSRNumber));
		System.out.println("Number " + sc.getData(PageScenarioKeys.ARSRNumber));
		AssetRPage.verifyAssetRepairRecommendation(recom);

	}

	@Then("click Repair Surface")
	public void click_repair_surface() {

		AssetRPage.clickRepairSurface();
	}


	@Then("verify Repair Surface data")
	public void verify_repair_surface_data(List<Map<String, String>> dt) {
		
		for (Map<String, String> dataRow : dt) {
			if(AssetRPage.selectRepairSurfaceData(dataRow.get("Data")).isDisplayed()){
				Assert.assertTrue(true);
			}else {
				Assert.assertTrue(false);
			}
		}
		
	}
	
	@When("user selects {string}")
	public void user_selects(String string) {
		sc.save(PageScenarioKeys.RepairSurface, string);
		AssetRPage.selectRepairSurfaceData(string).click();
	}
	
	@Then("verify associated sections")
	public void verify_associated_sections(List<Map<String, String>> dt) {
		
		for (Map<String, String> dataRow : dt) {
			AssetRPage.sectionsAssociatedWithBothandBaseMaterial(dataRow.get("Sections"));
		}
	}
	
	@When("click part family")
	public void clic_part_family() {
		
		AssetRPage.partFamily();
	}
	
	@Then("verify Part Family")
	public void verify_part_family(List<Map<String, String>> dt) {
	    
		
		for (Map<String, String> dataRow : dt) {
			AssetRPage.selectOptions(dataRow.get("Data"));
		}
	}
	
	@When("select Part Family {string}")
	public void select_part_family(String string) {
		
		AssetRPage.clickOption(string);
	}
	
	@Then("verify the Repair Surface in  General Repair Details")
	public void verify_the_repair_surface_in_general_repair_details() {
	  
		AssetRPage.repairSurfaceinGeneral(sc.getData(PageScenarioKeys.RepairSurface));
	}
	
	@And("enter Specific Repair Area {string}")
	public void enter_specific_repair_area(String name) throws InterruptedException {
		
		AssetRPage.selectSpecificRepairArea(name);
	}
	
	@Then("click Yes at Material Removal Acceptable and verify message {string}")
	public void click_yes_at_material_removal_acceptable_and_verify_message(String string) throws InterruptedException {
	    
		AssetRPage.materialRemovalAcceptableYES();
		AssetRPage.verifyMessage(string);
	}
	
	@Then("click No at Material Removal Acceptable and verify message {string}")
	public void click_no_at_material_removal_acceptable_and_verify_message(String string) {
	    
		AssetRPage.materialRemovalAcceptableNO();
		AssetRPage.verifyMessage(string);
	}
	
	@Then("click Yes at Post Repair Heat Treatment  and verify message {string}")
	public void click_yes_at_post_repair_heat_treatment_and_verify_message(String string) {
	    
		AssetRPage.postRepairTreatmentYES();
		AssetRPage.verifyMessage(string);
	}
	
	@Then("click No at Post Repair Heat Treatment  and verify message {string}")
	public void click_no_at_post_repair_heat_treatment_and_verify_message(String string) {
	    
		AssetRPage.postRepairTreatmentNo();
		AssetRPage.verifyMessage(string);
	}
	
	@Then("verify the tooltip of Post Repair Requirements {string}")
	public void verify_the_tooltip_of_post_repair_requirements(String toolTip) {
	    
		if(AssetRPage.tooltipPostRepair(toolTip).equalsIgnoreCase(toolTip)) {
			Assert.assertTrue(true);
		}else {
			Assert.assertTrue(false);
		}
	}
	
	@Then("Select Post Repair Requirements {string}")
	public void select_post_repair_requirements(String string) {
	    
		AssetRPage.selectPostRepairReqOptions(string);
	}
	
	@When("user enter Wall Thickness Loss {string}")
	public void user_enter_wall_thickness_loss(String string) {
	    
		AssetRPage.setWallThickness(string);
	}
	
	@When("user enter Defect Location {string}")
	public void user_enter_defect_location(String string) {
	    
		AssetRPage.setDefectLocation(string);
	}
	
	@When("user enter Defect Depth {string}")
	public void user_enter_defect_Depth(String string) {
	    
		AssetRPage.setDefectDepth(string);
	}
	
	@When("user enter Inside Diameter {string}")
	public void user_enter_inside_diameter(String string) {
	    
		AssetRPage.setinsideDia(string);
	}
	
	@When("user enter Crack Length {string}")
	public void user_enter_crack_length(String string) {
	    
		AssetRPage.setcrackLength(string);
	}
	
	@Then("click Yes at Material Removal Acceptable")
	public void click_yes_at_material_removal_acceptable() throws InterruptedException {
	    
		AssetRPage.materialRemovalAcceptableYES(); 
		
	}
	
	@Then("click No at Material Removal Acceptable")
	public void click_no_at_material_removal_acceptable() throws InterruptedException {
	    
		AssetRPage.materialRemovalAcceptableNO(); 
		
	}
	
	@Then("click Yes at Post Repair Heat Treatment")
	public void click_yes_at_post_repair_heat_treatment() {
	     
		AssetRPage.postRepairTreatmentYES();
		
	}
	
	@Then("click No at Post Repair Heat Treatment")
	public void click_no_at_post_repair_heat_treatment() {
	     
		AssetRPage.postRepairTreatmentNo();
		
	}
	
	@Then("verify the components of the recommendation {string}")
	public void verify_the_components_of_the_recommendation(String string, List<Map<String, String>> dt) {
		
		for (Map<String, String> dataRow : dt) {
			AssetRPage.verifyComposition(dataRow.get("Data1"));
			
		}
	    
	}
	
	@And("verify below table")
	public void verify_below_table(List<Map<String, String>> dt) {
		
		for (Map<String, String> dataRow : dt) {
			AssetRPage.verifyTableInRecomm(dataRow.get("Name"));
			AssetRPage.verifyTableInRecomm(dataRow.get("DATA"));
			//AssetRPage.verifyTableInRecomm(dataRow.get("Specification"));
			//AssetRPage.verifyTableInRecomm(dataRow.get("Specification"));
		}
	}
	
	

}