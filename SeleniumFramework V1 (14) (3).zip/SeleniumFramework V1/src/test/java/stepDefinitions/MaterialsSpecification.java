package stepDefinitions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import PageFactoryElements.ElastomerDegradationDataPage;
import PageFactoryElements.ElastomerMaterialSpecificationPage;
import PageFactoryElements.MaterialAdvisorMyRequest;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import Utilities.IDataReader;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MaterialsSpecification extends DriverIntialization{
	MaterialAdvisorMyRequest matAdvReq = new MaterialAdvisorMyRequest(DriverIntialization.getDriver());
	ElastomerMaterialSpecificationPage elasMatSpec = new ElastomerMaterialSpecificationPage(DriverIntialization.getDriver());
	MyRequestCreateRequestPage MyReqCreateReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());
	ElastomerDegradationDataPage elasDegData = new ElastomerDegradationDataPage(DriverIntialization.getDriver());
	List list = new ArrayList();
	ScenarioContext sc=new ScenarioContext();
	
	@When("user click Elastomer button")
	public void user_elastomer_button() {

		matAdvReq.elastomerTab();
	}
	
	@When("user click Specifications button")
	public void user_specification_button() {

		matAdvReq.clickSpecification();
	}
	
	@When("user click Environment Data button")
	public void user_click_environment_data_button() {
	   
		matAdvReq.EnvironmentData();
	}
	
	@When("user click Create Material Specification Button")
	public void user_clikc_create_material_specification_button() {
	    
		elasMatSpec.clickCreateMatSpciBtn();
	}
	
	@Then("user landed on {string}")
	public void user_landed_on_create_material_specification(String page) {
		elasMatSpec.pageDisplay(page);
	}
	
	@Then("user landed on Selection Report Page {string}")
	public void user_landed_on_selection_report_page(String page) {
		elasMatSpec.selectionReportPage(page);
	}
	
	@When("user enter Material Specification Number {string}")
	public void user_enter_material_specification_number(String string) {
	  
		elasMatSpec.setMatSpecNumber(string);
		MyReqCreateReq.selectOption(string);
	}
	
	@Then("Material Specification Number message {string} displayed")
	public void material_specification_number_message_displayed(String string) {

		elasMatSpec.alreadyExits(string);
		
	}
	
	@Then("verify Hardness Nominal {string} and message {string}")
	public void verify_hardness_nominal_and_message(String value, String message) {
	    
		elasMatSpec.setHardenssNom(value);
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Hardness Nominal {string}")
	public void user_select_hardness_nominal(String value) {

		elasMatSpec.setHardenssNom(value);
	}
	
	@Then("verify Hardness Min {string} and message {string}")
	public void verify_hardness_min_and_message(String string, String message) {
		elasMatSpec.setHardenssMin(string); 
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Hardness Min {string}")
	public void user_select_hardness_min(String string) {
	   
		elasMatSpec.setHardenssMin(string); 
	}
	
	@Then("verify Hardness Max {string} and message {string}")
	public void verify_hardness_max_and_message(String string, String message) {

		elasMatSpec.setHardenssMax(string); 
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Hardness Max {string}")
	public void user_select_hardness_max(String string) {

		elasMatSpec.setHardenssMax(string); 
	}
	
	@Then("verify Compression Temperature {string} and message {string}")
	public void verify_compression_temperature_and_message(String string, String message) {
	    
		elasMatSpec.setcompressionSetTemp(string);
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Compression Temperature {string}")
	public void user_select_Compression_Temperature(String string) {

		elasMatSpec.setcompressionSetTemp(string); 
	}
	
	@Then("verify Compression Time {string} and message {string}")
	public void verify_compression_time_and_message(String string, String message) {
	    
		elasMatSpec.setcompressionSetTime(string);
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Compression Time {string}")
	public void user_select_Compression_time(String string) {

		elasMatSpec.setcompressionSetTime(string); 
	}
	
	@Then("verify Compression Max {string} and message {string}")
	public void verify_compression_max_and_message(String string, String message) {
	    
		elasMatSpec.setcompressionSetMax(string);
		elasMatSpec.errorMessage(message);
	}
	
	@Then("user select Compression Max {string}")
	public void user_select_Compression_max(String string) {

		elasMatSpec.setcompressionSetMax(string); 
	}
	
	@When("user add Elastomer material Description {string}")
	public void user_add_elastomer_material_description(String string) {
	    
		elasMatSpec.clickMaterialDescriptions();
		MyReqCreateReq.selectOption(string);
	}
	
	@When("user add Material Condition {string}")
	public void user_add_material_condition(String string) {
	    
		elasMatSpec.setmaterialConditions(string);
		MyReqCreateReq.selectOption(string);
	}
	
	@When("remove Material Condition {string}")
	public void user_remove_material_condition(String string) {
	    
		elasMatSpec.removeMaterialCondition(string);
	}
	
	@When("user add Product Form {string}")
	public void user_add_product_form(String string) {
	   
		elasMatSpec.setproductForms(string);
		MyReqCreateReq.selectOption(string);
	}
	
	@When("remove Product Form {string}")
	public void remove_product_form(String string) {

		elasMatSpec.removeMaterialCondition(string);
	}
	
	@When("user select Cost Index {string}")
	public void user_select_cost_index(String string) {

		elasMatSpec.clickcostIndex();
		elasMatSpec.selectCostIndex(string);
	}
	
	@When("user add Compliance Standards {string}")
	public void user_add_compliance_standards(String string) {

		elasMatSpec.complianceStandards();
		MyReqCreateReq.selectOption(string);
	}
	
	@Then("user verify Elastomer Material Description from excel data")
	public void user_verify_coating_specification_with_coating_name(IDataReader dataTable) throws InterruptedException {
		
		List<Map<String, String>> data=dataTable.getAllRows();
		for(int i=0;i<data.size();i++) {
			elasMatSpec.clickMaterialDescriptions();
			list.add(data.get(i).get("Elastomer Material Description"));
			Thread.sleep(2000);
			elasMatSpec.cancelMaterialDesc(data.get(i).get("Elastomer Material Description"));
		}
	}
	
	@And("verify the General Information is {string}")
	public void verify_the_general_information_is(String value) {
		
		elasMatSpec.generalInfo(value);
	}
	
	@When("user select Manufacturer tab")
	public void user_select_manufacturer_tab() {
		
		elasMatSpec.manufacturerTab();
	}
	
	@Then("verify the Manufacturer/change message/history {string}")
	public void verify_the_manufacturer_message(String message) {

		elasMatSpec.manufacturerOrChangeHistoryMessage(message);
	}
	
	@Then("verify the Manufacturer {string}")
	public void verify_the_manufacturer(String name) {
		
		elasMatSpec.manufacturerName(name);
	
	}
	
	@When("user click on Edit button on elastomer/metallic specification report")
	public void user_click_on_edit_button_on_elastomer_specification_report() throws InterruptedException {
	    
		elasMatSpec.clickeditButton();
	}
	
	@When("user click on {string} button on elastomer/Metallic specification report")
	public void user_click_on_button_on_elastomer_specification_report(String button) throws InterruptedException {
	    
		elasMatSpec.clickButton(button);
	}
	
	@When("user click {string} button on popup")
	public void user_click_on_button_delete_onpopup(String btn) {
	    
		elasMatSpec.clickButtonOnPopup(btn);
	}
	
	@Then("verify Delete message on the pop up {string}")
	public void verify_delete_message_on_the_pop_up(String string) {
	    
		MyReqCreateReq.verifyPopUpMessage(string);
	}
	
	@Then("verify the delete message {string}")
	public void verify_the_delete_message(String string) {
		elasMatSpec.messageTopRightCorner(string);
	}
	
	@When("user add comment {string}")
	public void user_add_comment(String message) {
		
		elasMatSpec.addComment(message);
	}
	
	@Then("verify the Submit/Decline/Approve/Deactivate message {string}")
	public void verify_the_submit_message(String string) {
		elasMatSpec.messageTopRightCorner(string);
	}
	
	@Then("verify Change History {string} and message {string}")
	public void verify_change_history_and_message(String action, String message) {

		elasMatSpec.manufacturerOrChangeHistoryMessage(action);
		elasMatSpec.manufacturerOrChangeHistoryMessage(message);
	}
	
	@Then("verify error message on comment pop up {string}")
	public void verify_error_message_on_comment_pop_up(String string) {
		
		elasMatSpec.errorMessage(string);

	}
	
	@Then("close the top right corner pop up")
	public void close_the_top_right_corner_pop_up() {
	    
		elasMatSpec.closepopupMessage();
	}
	
	
	@Then("verify the EDR Summary is deactivated and message is {string}")
	public void verify_the_edr_summary_is_deactivated_and_message_is(String string) throws InterruptedException {

		elasMatSpec.verifyTooltip(string);
	}
	
	@When("user click plus button of {string} and {string}")
	public void user_click_plus_button_of_and(String edr, String option) {

      elasMatSpec.selectEDRfromEDRSummary(edr, option);
	}
	
	@When("user navigated to the previous page")
	public void user_navigated_to_the_previous_page() {
		elasMatSpec.navigateBack();
	}
	
	@When("user send/search keyword/EDRRecord {string}")
	public void user_send_keyword(String string) throws InterruptedException {

		elasMatSpec.clearAll();
		elasMatSpec.searchSpecifications(string);
	}
	
	@When("user select the Status {string}")
	public void user_select_the_status(String string) throws InterruptedException {

		elasMatSpec.clickStatus();
		Thread.sleep(2000);
		elasMatSpec.clickoption(string);
		Thread.sleep(2000);		
	}
	
	@When("user select Elasomer Family {string}")
	public void user_select_elasomer_family(String string) throws InterruptedException {

		elasMatSpec.elastomerFamily(string);
	}
	
	@When("user select Common Name {string}")
	public void user_select_common_name(String string) throws InterruptedException {

		elasMatSpec.commonName(string);
	}
	
	@When("user select Manufacturer {string}")
	public void user_select_manufacturer(String string) throws InterruptedException {

		elasMatSpec.manufacturer(string);
	}
	
	@When("user select Record Status {string}")
	public void user_select_record_status(String string) throws InterruptedException {

		elasMatSpec.recordStatus();
		elasMatSpec.clickoption(string);
	}
	
	@Then("user verify the below result")
	public void user_verify_the_below_result(DataTable dataTable) {

		elasMatSpec.searchResult(dataTable);
	}
	
	@When("user click Create Environemental Data Record")
	public void user_click_create_environemental_data_record() {
	   
		elasMatSpec.clickCreateEnvDataRecord();
	}
	
	@Then("user enter Service Duration/Life {string} and verify Service Type")
	public void user_enter_service_duration_and_verify_service_type(String string) throws InterruptedException {

		elasMatSpec.serviceDuration(string);
		elasMatSpec.getServiceType();
	}
	
	@Then("user select Data Sources {string}")
	public void user_select_data_sources(String string) throws InterruptedException {
	    
		elasMatSpec.datasources(string);
	}
	
	@Then("user remove Data/Water Sources {string}")
	public void user_remove_data_sources(String string) {

		elasMatSpec.removeDataSources(string);
	}
	
	@When("user enter Acceptable Temp Min {string} and verify message {string}")
	public void user_enter_acceptable_temp_min_and_verify_message(String string, String string2) {
		elasMatSpec.acceptableTempMin(string, string2);
	}
	
	@When("user enter Acceptable Temp Min {string}")
	public void user_enter_acceptable_temp_min_and_verify_message(String string) {
		elasMatSpec.acceptableTempMin(string);
	}
	
	@When("user enter Acceptable Temp Max {string} and verify message {string}")
	public void user_enter_acceptable_temp_max_and_verify_message(String string, String string2) {
		elasMatSpec.acceptableTempMax(string, string2);
		
	}
	
	@When("user enter Acceptable Temp Max {string}")
	public void user_enter_acceptable_temp_max_and_verify_message(String string) {
		elasMatSpec.acceptableTempMax(string);
		
	}
	
	@When("user select ECM Acceptable {string}")
	public void user_select_ecm_acceptable(String string) throws InterruptedException {
		elasMatSpec.ECMAcceptable();
		elasMatSpec.clickoption(string);
		Thread.sleep(2000);

	}
	
	@When("user select Steam Acceptable {string}")
	public void user_select_steam_acceptable(String value) throws InterruptedException {
		elasMatSpec.steamAcceptable(value);
		//elasMatSpec.clickoption(string);

	}
	
	@When("user click save button on EDD page")
	public void user_click_save_button_onn_edd_page() throws InterruptedException {
	   
		elasDegData.saveBtn();
	}
	
	@When("user select Formation Water Acceptable {string}")
	public void user_select_formation_water_acceptable(String string) throws InterruptedException {
	   
		elasMatSpec.formationWaterAcceptable(string);
	}
	
	@When("user select Temp for Formation Water {string}")
	public void user_select_temp_for_formation_water(String string) throws InterruptedException {
	    
		elasMatSpec.formationWaterTempAcceptable(string);
	}
	
	@When("user select Max. Temp for Formation Water {string} and verify message {string}")
	public void user_select_max_temp_for_formation_water_and_verify_message(String string, String string2) {

		elasMatSpec.setformationWaterTempMax(string, string2);
		
	  
	}
	
	@When("user select Seawater Acceptable {string}")
	public void user_select_seawater_acceptable(String string) {

		elasMatSpec.seaWaterAcceptable(string);
	}
	
	@When("user select Temp for Seawater {string}")
	public void user_select_temp_for_seawater(String string) {
		elasMatSpec.seaWaterTempApplicable(string);
	}
	
	@When("user set Max. Temp Limit for Seawater {string} and verify message {string}")
	public void user_set_max_temp_limit_for_seawater_and_verify_message(String string, String string2) {
		elasMatSpec.setseaWaterTempMax(string, string2);
		
	}
	
	@When("user select H2S Acceptable {string}")
	public void user_select_h2s_acceptable(String string) {
	    
		elasDegData.h2sAcceptable(string);
		
	}
	
	@When("user select H2S Limit {string}")
	public void user_select_h2s_limit(String string) {
	    
		elasDegData.h2sPressureLimitAvailable(string);
	}
	
	@When("user set Max Allowable H2S {string} and verify message {string}")
	public void user_set_max_allowable_h2s_and_verify_message(String string, String string2) {
	    
		elasDegData.setmaxAllowableH2S(string, string2);
	}
	
	@When("user select Temp for H2S {string}")
	public void user_select_temp_for_h2s(String string) {

		elasDegData.h2sTempApplicable(string);
	}
	
	@When("user select Max Temp for H2S {string} and verify message  {string}")
	public void user_select_max_temp_for_h2s_and_verify_message(String string, String string2) {
	   
		elasDegData.seth2sTempMax(string, string2);
	}
	
	@When("user set CO2 Acceptable {string}")
	public void user_set_co2_acceptable(String string) {
	    
		elasDegData.CO2Acceptable(string);
	}
	
	@When("user select CO2 Limit {string}")
	public void user_select_co2_limit(String string) {
	    
		elasDegData.CO2Limit(string);
	}
	
	@When("user select Max Allowable CO2 {string} and verify message  {string}")
	public void user_select_max_allowable_co2_and_verify_message(String string, String string2) {
	    
		elasDegData.maxAllowableCO2(string, string2);
	}
	
	@When("user select Temp for CO2 {string}")
	public void user_select_temp_for_co2(String string) {

		elasDegData.tempForCO2(string);
	}
	
	@When("user select Max Temp for CO2 {string} and verify message  {string}")
	public void user_select_max_temp_for_co2_and_verify_message(String string, String string2) {
	    
		elasDegData.co2TempMax(string, string2);
	}
	
	@When("user set WBM Acceptable {string}")
	public void user_set_wbm_acceptable(String string) {

		elasDegData.wbmAcceptable(string);
	}
	
	@When("user select WBM Applicability {string}")
	public void user_select_wbm_applicability(String string) {
	 
		elasDegData.wbmTempApplicable(string);
	}
	
	@When("user select Max Temp for WBM {string} and verify message  {string}")
	public void user_select_max_temp_for_wbm_and_verify_message(String string, String message) {
	    
		elasDegData.wbmTempMax(string, message);
	}
	
	@When("user set Amine Acceptable {string}")
	public void user_set_amine_acceptable(String value) {
	    
		elasDegData.amineAcceptable(value);
	}
	
		
	@Then("verify data for General/UNS Section")
	public void verify_data_for_general_section(DataTable dataTable) {
	   
		MyReqCreateReq.verifyDataSelectMaterialSpecs(dataTable);
	}
	
		
	@Then("verify the Record UID is generated")
	public void verify_the_record_uid_is_generated() {
		
		elasDegData.getRecordUID();
		sc.save(PageScenarioKeys.RecordUID, elasDegData.getRecordUID());
	}
	
	@Then("verify clone {string} is present")
	public void verify_clone_is_present(String record) {
	    
		elasDegData.recordonEDDpage(record, sc.getData(PageScenarioKeys.RecordUID));
	}
	
	
	
	
	
}
