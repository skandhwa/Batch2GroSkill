package stepDefinitions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import PageFactoryElements.AMPartAndMaterialAdvisorAppPage;
import PageFactoryElements.MyRequestCreateRequestPage;
import Utilities.DriverIntialization;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AMPartAndMaterialAdvisorApp extends DriverIntialization{

	AMPartAndMaterialAdvisorAppPage amApp = new AMPartAndMaterialAdvisorAppPage(DriverIntialization.getDriver());
	MyRequestCreateRequestPage matAdvCreReq = new MyRequestCreateRequestPage(DriverIntialization.getDriver());
	ScenarioContext sc=new ScenarioContext();
	
	@When("user select {string} as Material Information")
	public void user_select_as_material_information(String string) {
	
		amApp.materialInfoAndPartStage(string);
	}
	
	@When("user click New Request")
	public void user_click_new_request() {
		
		amApp.newRequest();
	}
	
	
	@Then("verify Yield Strength when metals is selected")
	public void verify_yield_strength_if_metals_is_selected() {
	    
		amApp.displayYieldStrength();
	}
	
	@Then("add Yield Strength {string} and message {string}")
	public void add_yield_strength_and_message(String value, String message) {
	    
		amApp.enterYieldStrength(value);
		amApp.messageError(message);
	}
	
	
	@When("user add Yield Strength {string}")
	public void user_add_yield_strength(String value) {
		amApp.enterYieldStrength(value);
	}
	
	@When("user click Application Type and select {string}")
	public void user_click_application_type_and_select(String string) {
	    
		amApp.clickappType();
		matAdvCreReq.selectOption(string);
	}
	
	@When("add Service Temperature {string} and message {string}")
	public void add_service_temperature_and_message(String string, String string2) {

		amApp.servTemperature(string);
		amApp.messageError(string2);
	}
	
	@When("add Service Pressure {string} and message {string}")
	public void add_service_pressure_and_message(String string, String string2) {
	   
		amApp.servPressure(string);
		amApp.messageError(string2);
	}
	
	@When("user select Part Stage {string}")
	public void user_select_part_stage(String partStage) {
	    
		amApp.materialInfoAndPartStage(partStage);
	}
	
	@Then("Part Number is displayed when Existing Part is selected")
	public void part_number_is_displayed_when_existing_part_is_selected() {
	   
		amApp.displayPartNumber();
	}
	
	@When("user enter Part Number {string}")
	public void user_enter_part_number(String value) {
	    
		amApp.partNumber(value);
	}
	
	@When("user select Part Type {string}")
	public void user_select_part_type(String partStage) {
	    
		amApp.materialInfoAndPartStage(partStage);
	}
	
	@Then("Note {string} displayed if Part Type is Simple/Tubular")
	public void note_displayed_if_part_type_is(String message) {
	   
		amApp.noteMessage(message);
	}
	
	@Then("Dimensions are visible")
	public void dimensions_are_visible() {
	    
		amApp.dimensions();
	}
	
	@When("user enter Dimension Length {string} and verify message {string}")
	public void user_enter_dimension_length_and_verify_message(String string, String string2) {
	    
		amApp.dimensionlength(string);
		amApp.messageError(string2);
	}
	
	@When("user enter Dimension Length {string}")
	public void user_enter_dimension_length(String string) {
	    
		amApp.dimensionlength(string);
	}
	
	@When("user enter Dimension Width {string} and verify message {string}")
	public void user_enter_dimension_width_and_verify_message(String string, String string2) {
	    
		amApp.dimensionwidth(string);
		amApp.messageError(string2);
		
	}
	
	@When("user enter Dimension Width {string}")
	public void user_enter_dimension_width(String string) {
	    
		amApp.dimensionwidth(string);
	}
	
	@When("user enter Dimension Height {string} and verify message {string}")
	public void user_enter_dimension_height_and_verify_message(String string, String string2) {
	    
		amApp.dimensionheight(string);
		amApp.messageError(string2);
	}
	
	@When("user enter Dimension Height {string}")
	public void user_enter_dimension_height(String string) {
	   
		amApp.dimensionheight(string);
	}
	
	@When("user enter Dimension Wall Thickness {string} and verify message {string}")
	public void user_enter_dimension_wall_thickness_and_verify_message(String string, String string2) {
	    
		amApp.dimensionwallThickness(string);
		amApp.messageError(string2);
	}

	@When("user enter Dimension Wall Thickness {string}")
	public void user_enter_dimension_wall_thickness(String string) {
	   
		amApp.dimensionwallThickness(string);
	}
	
	@Then("Design & Manufacturing Considerations is visible")
	public void design_manufacturing_considerations_is_visible() {
	    
		amApp.designManufacturingConsiderations();
	}
	
	@When("user select Surface Finish, Max {string}")
	public void user_select_surface_finish_max(String option) {
	    
		amApp.selectDesignManufacturingConsiderations(option);
	}
	
	@When("user select Current Manufacturing Processes")
	public void user_select_current_manufacturing_processes(List<Map<String, String>> dataTable) throws InterruptedException {
	    
		amApp.currentManufacturingProcessAndFuncReq(dataTable);
	}
	
	@When("user select {string}")
	public void user_select(String option) {
	    
		amApp.selectDesignManufacturingConsiderations(option);
	}
	
	@When("user enter Overhangs {string} and verify message {string}")
	public void user_enter_overhangs_and_verify_message(String string, String string2) {
	    
		amApp.overhangs(string);
		amApp.messageError(string2);
	}
	
	@When("user enter Overhangs {string}")
	public void user_enter_overhangs(String string) {
	    
		amApp.overhangs(string);
	}
	
	@When("user select Tolerences {string}")
	public void user_select_tolerences(String option) {
	    
		amApp.selectDesignManufacturingConsiderations(option);
	}
	
	@Then("Functionality Requirements are visible")
	public void functionality_requirements_are_visible() {
	    
		amApp.functionalityRequirements();
	}
	
	@Then("user select Functionality Requirements")
	public void user_select_functionality_requirements(List<Map<String, String>> dataTable) throws InterruptedException {
	    
		amApp.currentManufacturingProcessAndFuncReq(dataTable);
	}
	
	@When("user select Primary driver for AM Selection")
	public void user_select_primary_driver_for_am_selection(List<Map<String, String>> dataTable) throws InterruptedException {
		
		amApp.currentManufacturingProcessAndFuncReq(dataTable);
	}
	
	@Then("3MT Internal Printing Capabilities is visible")
	public void mt_internal_printing_capabilities_is_visible() {
	    
		amApp.mtPrintingPopUp();
	}
	
	@Then("user select {string} button on the pop up")
	public void user_select_button_on_the_pop_up(String string) {
	    
		amApp.yesBtn();
	}
	
	@Then("user expands Recommendation option {string}")
	public void user_expands_recommendation_option(String string) {
	    
		amApp.expandOption(string);
	}
	
	@Then("verify Additional Functionality")
	public void verify_additional_functionality_and_notes(List<Map<String, String>> dataTable) throws InterruptedException {
	    
		amApp.additionalFunctionality(dataTable);
		
	}
	
	@Then("verify Recommendation Notes {string}")
	public void verify_additional_functionality_and_notes(String notes) throws InterruptedException {
	    
		amApp.displayNotes(notes);
		
	}
	
	@When("user select Product line {string}")
	public void user_select_product_line(String string) throws InterruptedException {
	    
		amApp.productLine();
	    matAdvCreReq.selectOption(string);
	}
	
	@When("add Service Temperature {string}")
	public void add_service_temperature(String string) {
	    
		amApp.servTemperature(string);
	}
	
	@Then("verify data under Request Information")
	public void verify_data_under_request_information(DataTable dt) {
	    
		amApp.requestInformation(dt);
	}
	
	@Then("{string} is visible on Recommendations")
	public void is_visible_on_recommendations(String string) throws InterruptedException {
	    
		amApp.printingService(string);
		Thread.sleep(2000);
	}
	
	@Then("click on {string} on Recommendations")
	public void click_on_on_recommendations(String string) {
	   
		amApp.clickPrintingService(string);
	}
	
	@Then("user select Product Group {string}, Function {string} and Material Category {string}")
	public void user_select_product_group_function_and_material_category(String productGroup, String function, String matCat) {
	   
     // amApp.productGroup();
    //  matAdvCreReq.selectOption(productGroup);
      amApp.function();
      matAdvCreReq.selectOption(function);
    //  amApp.materialCategory();
    //  matAdvCreReq.selectOption(matCat);
      
	}
	
	@Then("user enter Project Name {string}, CAD Support Request {string} and Number of Parts Requested {string}")
	public void user_enter_project_name_cad_support_request_and_number_of_parts_requested(String name, String cad, String parts) {
	   
		amApp.setProjectName(name);
		amApp.cadAndParts(cad);
		amApp.cadAndParts(parts);
	}
	
	@Then("user select Legacy Cameron {string}")
	public void user_select_legacy_cameron(String option) {
	    
		amApp.legacyCameron(option);
	}
	
	@Then("user select Desired Lead time {string}, WBS Code {string}, Project Code {string} and Managers email address {string}")
	public void user_select_desired_lead_time_wbs_code_project_code_and_managers_email_address(String time, String wbs, String projectCode, String email) {
	    
		amApp.desiredLeadTime(time);
		amApp.setWBS(wbs);
		amApp.setProjectCode(projectCode);
		amApp.managerEmail(email);
	}
	
	@Then("user fetch Am Part Reference Number")
	public void user_fetch_am_part_reference_number() {
	    
		amApp.amReferenceNumber();
		sc.save(PageScenarioKeys.AMPartRefenerenceNumber, amApp.amReferenceNumber()); 
	}
	
	@Then("verify AM Part Reference Number is visible")
	public void verify_am_part_reference_number_is_visible() {
	    
		amApp.referneceNumber(sc.getData(PageScenarioKeys.AMPartRefenerenceNumber));
	}
	
	@Then("fields are empty {string}, {string} and {string}")
	public void fields_are_empty_and(String string, String string2, String string3) {
	    
		amApp.materialInfoAndPartStageNotSelected(string);
		amApp.materialInfoAndPartStageNotSelected(string2);
		amApp.materialInfoAndPartStageNotSelected(string3);
	}
}


