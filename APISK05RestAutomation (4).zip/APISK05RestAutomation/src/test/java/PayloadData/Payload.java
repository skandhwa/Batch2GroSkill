package PayloadData;

import java.util.LinkedHashMap;
import java.util.Map;

import ReUsabaleMethod.ReusabaleClass;

public class Payload {
	
	public static String AddEmployee(String name,String job)
	{
		String EmployeeData="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+job+"\"\r\n"
				+ "}";
		
		return EmployeeData;
		
	}
	
	public static String AddBooks(String ISBN,double aisle)
	{
		String BookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+ISBN+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return BookData;
	}
	
	
	public static Map AddUserCredentials()

	{
		Map<String,String> mp=new LinkedHashMap<String,String>();
		mp.put("name", "John Dsouza");
		mp.put("gender", "male");
		
		String email=ReusabaleClass.generateRandomEmail();
		
		mp.put("email", email);
		mp.put("status", "active");
		
		return mp;
		
		
		
	}
	
	
	

}
