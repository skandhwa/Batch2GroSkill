package MyBasicsPractice;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import static org.hamcrest.Matchers.*;


public class MyTest3 {

	public static void main(String[] args) {
		

		RestAssured.baseURI="https://reqres.in";
		String Expected_Date="2024-12-11";
		
	String Response=	given().log().all().headers("Content-Type","application/json")
			.headers("","")
			.body(Payload.AddEmployee("Harry","Qa lead"))
		.when().post("api/users")
		.then().log().all().assertThat().statusCode(201)
		.body("createdAt",equalTo("2024-12-11T14:38:34.551Z")).
		
		extract().response().asString();
		
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String Actual_Date=js.getString("createdAt");
	
String[]a=	Actual_Date.split("T");

String Actual_Calendar_Day=a[0];

System.out.println(a[0]);

Assert.assertEquals(Actual_Calendar_Day, Expected_Date);

System.out.println("Test Case passed");



		

	}

}
