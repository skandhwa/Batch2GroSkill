package MyBasicsPractice;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;


public class MyTest1 {
	
	@Test
	public void method1()
	{
		String Expected_FirstName="Janet";
		RestAssured.baseURI="https://reqres.in";
		
String Response=		given().log().all().headers("Connection","keep-alive").
when().get("api/users/2")
		.then().log().all().
		assertThat().statusCode(200).headers("Server","cloudflare")
		.extract().response().
		asString();
		
System.out.println(Response);

JsonPath js=new JsonPath(Response);

String Actual_FirstName=js.getString("data.first_name");

Assert.assertEquals(Expected_FirstName, Actual_FirstName);










		
		
	}
	

}
