package MyBasicsPractice;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class LibraryScript {

	public static void main(String[] args) {
		
		String ExpectedISBN="TataMcGrawHill";
		double ExpectedAisle= 1234+ Math.floor(Math.random()*120) + 1;
		
		System.out.println(ExpectedAisle);
		
		String ExpectedID=ExpectedISBN+ExpectedAisle;
		

		RestAssured.baseURI="http://216.10.245.166";
		
		
	String Response=	given().log().all().headers("Content-Type","application/json")
			
			.body(Payload.AddBooks(ExpectedISBN,ExpectedAisle))
		.when().post("Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200).
		
		
		extract().response().asString();
		
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
	String ActualID=js.getString("ID");
	
	Assert.assertEquals(ExpectedID, ActualID);
	
	System.out.println("Test Case Passed");
		

	}

}
