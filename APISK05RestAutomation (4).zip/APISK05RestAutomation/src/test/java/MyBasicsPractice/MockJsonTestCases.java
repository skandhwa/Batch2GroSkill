package MyBasicsPractice;

import ResponseBody.MockResponseJson;
import io.restassured.path.json.JsonPath;

public class MockJsonTestCases {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(MockResponseJson.CourseDetails());
		
		///Print No of courses returned by API
		
	int x=	js.getInt("courses.size()");
	
	System.out.println("Total Number of Courses is "+x);
	
	///Print the Purchase Amount
	
	int purchase_amount=js.getInt("dashboard.purchaseAmount");
	System.out.println("Total Purchase Amount is  "+purchase_amount);
		
	
	//Print Title of the first course
	
	String first_CourseTitle=js.getString("courses[0].title");
	
	System.out.println("first Course title is  "+first_CourseTitle);
	
	
	//Print All course titles and their respective Prices

	
	System.out.println("Course title and prices are ");
	
	
	System.out.println("Course title and their respective price are ");
	for(int i=0;i<x;i++)
	{
	String Courses_title=	js.getString("courses["+i+"].title");
	int Courses_price=	js.getInt("courses["+i+"].price");
	System.out.println(Courses_title+"  "+Courses_price);
	
	
	}
	
	///Print no of copies sold by RPA Course
	
	for(int i=0;i<x;i++)
	{
	String Courses_title=	js.getString("courses["+i+"].title");
	if(Courses_title.equals("RPA"))
	{
		int y=js.getInt("courses[2].copies");
		System.out.println("No of copies sold by RPA is "+y);
	}
	
	
	}
	
	////Verify if Sum of all Course prices matches with Purchase Amount
	
	
	int sum=0;
	
	System.out.println("Course copies and their respective price are ");
	for(int i=0;i<x;i++)
	{
	int Courses_copies=	js.getInt("courses["+i+"].copies");//50//40//45
	int Courses_price=	js.getInt("courses["+i+"].price");//6//4//10
	int amount= Courses_copies*Courses_price;//amount=300//amount=160//amo=450
	sum=sum+amount;///sum=0+300=300//sum=300+160//sum=460+450
	
	
	
	
	
	}
	
	System.out.println("The total sum of price and copies is "+sum);
	
	if(sum==purchase_amount)
	{
		System.out.println("Sum of all Course prices matches with Purchase Amount");
		System.out.println("Test Case passed");
	}
	
	else
	{
		System.out.println("Test Case failed");
	}
	
	
	


	}

}
