package ExcelIntegrationEx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FetchDataFromExcel {
	static FileInputStream f;
	static XSSFWorkbook workbook;

	public static void main(String[] args)  {
		
		
		
		try {
			f = new FileInputStream("‪E:\\ExcelRestAssured15thOctober.xlsx");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			workbook = new XSSFWorkbook(f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XSSFSheet sheet=workbook.getSheetAt(1);
		DataFormatter formatter=new DataFormatter();
	    Object value=	formatter.formatCellValue(sheet.getRow(1).getCell(0));
		String val=value.toString();
		System.out.println(val);
		
		
		
		
		

	}

}
