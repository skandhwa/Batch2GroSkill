package UsingXMLforPayload;

import io.restassured.RestAssured;
import static  io.restassured.RestAssured.*;

public class PassingXMLAsBody {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://petstore.swagger.io";
		
	String Response=	given().log().all().headers("Content-Type","application/XML")
		.body(PayloadXML.payloadXML())
		.when().post("v2/pet")
		.then().extract().response().asString();
	
	System.out.println(Response);
		

	}

}
