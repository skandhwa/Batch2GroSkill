package POJOEx5;

import java.util.List;

public class Employee5POJO {
	
	private String name;
	private int age;
	private int salary;
	private EmpAddress5POJO empAddress;
	private boolean isMarried;
	private List<String> banks;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public EmpAddress5POJO getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(EmpAddress5POJO empAddress) {
		this.empAddress = empAddress;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	
	
	

}
