package POJOEx2;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import POJOEx1.EmployeePojo;
import io.restassured.RestAssured;

public class CreateEmployeeMain {

	public static void main(String[] args) throws JsonProcessingException {
		
RestAssured.baseURI="https://reqres.in";

     EmployeeAddressPOJO  empAddressPojo=new EmployeeAddressPOJO();
     empAddressPojo.setCity("Kolkata");
     empAddressPojo.setState("WB");
     empAddressPojo.setZip(700033);
 
        
		
     CreateEmployee2Pojo emp=new CreateEmployee2Pojo();
		emp.setName("Tom");
		emp.setAge(32);
        emp.setSalary(56000f);
        emp.setIsMarried(true);
        emp.setEmpAddress(empAddressPojo);
        
        
        ObjectMapper obj=new ObjectMapper();
		
   String empJson=     obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		
		
String Response=		given().log().all().body(empJson)
		.headers("Content-Type","application/json" )
		.when().post("api/users")
		.then().log().all().
		extract().response().asString();

System.out.println(Response);
		
		

	}

}
