package DBIntegration;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class CreateUser1 {

	public static void main(String[] args) throws SQLException {
		
		LinkedHashMap<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("StudentID",DataBaseConnectionEx.DBConnection(1));
		mp.put("LastName",DataBaseConnectionEx.DBConnection(2));
		mp.put("FirstName",DataBaseConnectionEx.DBConnection(3));
		mp.put("Address",DataBaseConnectionEx.DBConnection(4));
		mp.put("City",DataBaseConnectionEx.DBConnection(5));
		
		RestAssured.baseURI="https://reqres.in";
	String Response=	given().log().all().body(mp).header("Content-Type","application/json")
		.when().post("api/users")
		.then().assertThat().statusCode(201).extract().response()
		.asString();
	
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	int ID=js.getInt("id");
	
	System.out.println();
	System.out.println();
	
	System.out.println("The ID generated is  "+ID);
		
		
		
		

	}

}
