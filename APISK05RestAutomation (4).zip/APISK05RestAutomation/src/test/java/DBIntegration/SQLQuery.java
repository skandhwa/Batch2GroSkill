package DBIntegration;

public class SQLQuery {
	
	public static String myquery()
	{
		String selectLocation="select * from student2.persons where city='Hyderabad'";
		return selectLocation;
	}

}
