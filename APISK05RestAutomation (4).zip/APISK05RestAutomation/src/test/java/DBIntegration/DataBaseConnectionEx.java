package DBIntegration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class DataBaseConnectionEx {
	
	
	public static Object DBConnection(int x) throws SQLException
	{
		Connection mycon=null;
		Statement myst=null;
		ResultSet myRs=null;
		Object obj=null;
		
		mycon=	DriverManager.getConnection("jdbc:mysql://localhost:3306/student2","root","root");
		System.out.println("Connection Successfull");
		myst=	mycon.createStatement();
	myRs=	myst.executeQuery(SQLQuery.myquery());
	
	while(myRs.next())
	{
	obj=	myRs.getString(x);
		
	}
	
	return obj;
	
	
		
		
		
		
	}
	

}
