package ReUsingRequestResponseSpecBuilder;

import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class RequestResponseSpecBuilder {

	public static void main(String[] args) {
		
		
		
		
		RequestSpecification res=given()
				.spec(ReUsingBuilder.
						request()).body(Payload.AddEmployee("Tom","QA Manager"));
		
		
		
				
        Response response=res.when().post("api/users").then().spec(ReUsingBuilder.responseVal())
	  .extract().response();

//Long time=response.getTime();
//
//System.out.println("The total time taken by response is  "+time);

String Responsestr=response.asString();

System.out.println(Responsestr);
		
		
		
	}

}
