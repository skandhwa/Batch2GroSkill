package ReUsingRequestResponseSpecBuilder;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReUsingBuilder {
	
	public static RequestSpecification request()
	{
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("https://reqres.in/")
				.setContentType(ContentType.JSON)
				
				.build();
		
		return req;
	}
	
	public static ResponseSpecification responseVal()
	{
		ResponseSpecification respec=new ResponseSpecBuilder()
				.expectStatusCode(201)
				.expectContentType(ContentType.JSON)
				.build();
		
		return respec;
	}
	

}
