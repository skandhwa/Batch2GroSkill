package UsingSpecBuilders;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.sessionId;
import static org.testng.Assert.assertTrue;

import PayloadData.Payload;
import ReUsingRequestResponseSpecBuilder.ReUsingBuilder;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class RequestAndResponseSpecificationGet {

	public static void main(String[] args) {
		
		
		
		
		RequestSpecification res=given().log().all()
				.spec(ReUsingBuilder.request());
		
		
		
		
String Response=res.when().get("api/users/2").then().
spec(ReUsingBuilder.responseVal())
		.extract().response().asString();




System.out.println(Response);
				
				

	}

}
