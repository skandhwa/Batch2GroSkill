package POJOEx3;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ReUsingRequestResponseSpecBuilder.ReUsingBuilder;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

import static  io.restassured.RestAssured.*;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		CreateEmployeePOJO3 emp1=new CreateEmployeePOJO3();
		
		emp1.setId(1234);
		emp1.setName("Monty");
		emp1.setSalary(80000);
		emp1.setMarried(false);
		
CreateEmployeePOJO3 emp2=new CreateEmployeePOJO3();
		
		emp2.setId(2234);
		emp2.setName("Jonty");
		emp2.setSalary(90000);
		emp2.setMarried(true);
		
		
CreateEmployeePOJO3 emp3=new CreateEmployeePOJO3();
		
		emp3.setId(3234);
		emp3.setName("Tom");
		emp3.setSalary(100000);
		emp3.setMarried(false);
		
		
	List<CreateEmployeePOJO3> li=new ArrayList<CreateEmployeePOJO3>();	
	
	li.add(emp1);
	li.add(emp2);
	li.add(emp3);
	
	RestAssured.baseURI="https://reqres.in";
	
	
	ObjectMapper obj=new ObjectMapper();
	
String empJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
	
	
RequestSpecification res=given().log().all()
.spec(ReUsingBuilder.request());




String Response=res.when().post("api/users").then().
spec(ReUsingBuilder.responseVal())
.extract().response().asString();


System.out.println(Response);


/////////////Doing Deserailization


//CreateEmployeePOJO3 empObj=obj.readValue(empJson, CreateEmployeePOJO3.class);




	
	
		
		

	}

}
