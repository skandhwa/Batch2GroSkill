package AbstractionEx;

interface Drawable
{
	void draw();
	void shape();
}

class Rectangle implements Drawable
{
	public void draw()
	{
		System.out.println("Drawing Rectangle");
	}
	public void shape()
	{
		System.out.println("It is a rectangle");
	}
	
}

class Square implements Drawable
{
	public void draw()
	{
		System.out.println("Drawing Square");
	}

	public void shape()
	{
		System.out.println("It is a square");
	}


}


public class InterfaceRealTimeEx {

	public static void main(String[] args) {
		
		Drawable ref=new Rectangle();
		ref.shape();
		ref.draw();
		
		Drawable ref1=new Square();
		ref1.shape();
		ref1.draw();
		
		

	}

}
