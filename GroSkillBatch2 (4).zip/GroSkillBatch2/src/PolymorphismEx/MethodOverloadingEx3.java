package PolymorphismEx;

public class MethodOverloadingEx3 {
	
	 static int display(String name)
	{
		return name.length();
	}
	
	 static String display(String name1,String name2)
	{
		return name1+name2;
	}
	


	public static void main(String[] args) {
		
	System.out.println(MethodOverloadingEx3.display("Saurabh"));	
		
	System.out.println	(MethodOverloadingEx3.display("India", "Nation"));
		

	}

}
