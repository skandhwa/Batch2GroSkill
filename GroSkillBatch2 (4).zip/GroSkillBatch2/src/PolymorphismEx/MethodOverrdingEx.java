package PolymorphismEx;

class Bank
{
	 int getROI(int x,int y)
	{
		return x+y;
	}
}


class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class BOB extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}




public class MethodOverrdingEx {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
	System.out.println(obj.getROI(4, 5));	
	
	Bank obj1=new  Bank();
	System.out.println	(obj1.getROI(7, 7))
			;
		
		

	}

}
