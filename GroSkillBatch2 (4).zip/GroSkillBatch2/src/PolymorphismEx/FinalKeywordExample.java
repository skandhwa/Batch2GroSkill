package PolymorphismEx;

class D1
{
	  int id=10;
	
    void display()
    {
    	id=50;
    	System.out.println(id);
    }
	
}



public class FinalKeywordExample {

	public static void main(String[] args) {
		
		D1 obj=new D1();
		obj.display();
		

	}

}
