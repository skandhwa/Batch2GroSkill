package AccessModifierEx;




public class PrivateEx {
	
	private int x=20;
	private void  display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
           
		PrivateEx obj=new PrivateEx();
		obj.display();
		
	}

}
