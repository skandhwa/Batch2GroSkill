package EncapsulationEx;

class Student3
{
	
	private int id;
	private String name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
public class EncapsulationEx1 {

	public static void main(String[] args) {
		
		Student3 obj=new Student3();
		obj.setName("Harsh");
		
	System.out.println(obj.getName());	
		
		

	}

}
