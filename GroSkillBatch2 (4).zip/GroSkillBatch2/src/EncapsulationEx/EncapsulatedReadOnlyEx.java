package EncapsulationEx;

class Student4
{
	private String college="AEC";
	private int id=45;
	
	
	public String getCollege() {
		return college;
	}
	
	public int getId() {
		return id;
	}
	
	
	
}



public class EncapsulatedReadOnlyEx {

	public static void main(String[] args) {
		
		
		Student4 obj=new Student4();
	System.out.println(obj.getCollege());	
	System.out.println(obj.getId());
		
		

	}

}
