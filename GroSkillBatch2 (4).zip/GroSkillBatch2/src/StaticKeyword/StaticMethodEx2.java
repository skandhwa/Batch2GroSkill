package StaticKeyword;

class C7
{
	 String  colour="red";
}

class C5 extends C7
{
	
	 String colour="green";
	 static String name="Saurabh";
	static int sum(int x,int y)
	{
		return x+y;
	}
	
	 void display()
	{
		System.out.println(colour);
		System.out.println(name);
		//System.out.println(super.colour);
	}
}



public class StaticMethodEx2 {

	public static void main(String[] args) {
		
	System.out.println("The sum is  "+C5.sum(23, 99));	
		

	}

}
