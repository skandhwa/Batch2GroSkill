package StaticKeyword;

public class StaticBlockEx {
	
	static
	{
		System.out.println("Hello");
	}
	
	static
	{
		System.out.println("Welcome");
	}
	

	public static void main(String[] args) {
		
		System.out.println("Hi");
		

	}

}
