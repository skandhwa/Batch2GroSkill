package MyPractice1;

public class AssignmentOperatorEx {

	public static void main(String[] args) {

          int b=10;
          
          b+=13;  // b=b+13
          
          System.out.println(b);
          
          
          int d=20;
          int e=100/5;
          
          if(d==e)
          {
        	  System.out.println("true");
          }
          else
          {
        	  System.out.println("false");
          }

	}

}
