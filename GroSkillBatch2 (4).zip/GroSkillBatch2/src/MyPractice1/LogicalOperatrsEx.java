package MyPractice1;

public class LogicalOperatrsEx {

	public static void main(String[] args) {
		
		/// &&
		
		// ||
		
		// !
		
		
		int a=20;
		int b=34;
		
		int c=56;
		
		if (!(a<b && b<c && c>a))
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("false");
		}
		
		
		
		

	}

}
