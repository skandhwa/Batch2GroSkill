package MyPractice1;

class T9
{
	int id;
	String name;
	boolean flag;
	
	
	T9(int i,boolean f)
	{
		id=i;
		flag=f;
	}

	T9(int i,String n)
	{
		id=i;
		name=n;
	}
	
	

  T9(int i,String n,boolean f)
  {
	  id=i;
	  name=n;
	  flag=f;
  }
  
  void display()
  {
	  System.out.println(id+"  "+name+"  "+flag);
  }

}

public class ParameterizedConstructorEx {

	public static void main(String[] args) {
		
		T9 obj=new T9(1234,"Saurabh",true);
		obj.display();
		
		T9 obj1=new T9(5234,"Gaurabh",false);
		obj1.display();
		
		T9 obj2=new T9(4567,"Mohan");
		obj2.display();
		
		T9 obj3=new T9(5678,false);
		obj3.display();
		
	

	}

}
