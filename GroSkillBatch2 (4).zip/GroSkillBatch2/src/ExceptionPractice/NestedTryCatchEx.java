package ExceptionPractice;

public class NestedTryCatchEx {

	public static void main(String[] args) {
		
		try
		{
			try
			{
				try
				{
					
				}
				
				catch(Exception e)
				{
					System.out.println("caught with "+e);
				}
			}
			
			catch(Exception e)
			{
				System.out.println("caught with "+e);
			}
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		

	}

}
