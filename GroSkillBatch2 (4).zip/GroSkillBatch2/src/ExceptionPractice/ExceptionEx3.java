package ExceptionPractice;

public class ExceptionEx3 {

	public static void main(String[] args) {
		
		try
		{
		
		int []x= {12,34,56,78};
		System.out.println(x[5]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		
		
		

	}

}
