package ExceptionPractice;

public class ExceptionEx4 {

	public static void main(String[] args) {
		
		try
		{
		String str="abc";
		int i=Integer.parseInt(str);
		System.out.println(i);
		
		}
		
		catch(NumberFormatException e)
		{
			System.out.println("caught with "+e);
		}
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
