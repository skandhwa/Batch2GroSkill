package DefaultEx1;

public class Example2 {

	public static void main(String[] args) {
		
		Example1 obj=new Example1();
		obj.display();
		

	}

}
