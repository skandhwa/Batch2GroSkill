package DefaultEx1;

class Example1 
{
	
	void display()
	{
		System.out.println("Hello Saurabh");
	}
	
	

	public static void main(String[] args) {
		
		Example1 obj=new Example1();
		obj.display();
		

	}

}
