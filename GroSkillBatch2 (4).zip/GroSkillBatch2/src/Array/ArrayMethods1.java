package Array;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		int []a= {92,34,56,77,88};
		
		int []b= {192,34,56,77,88};
		
		
	System.out.println(Arrays.compare(a,b));
	
System.out.println("Are both arrays equal "+Arrays.equals(a,b));

System.out.println(Arrays.toString(a));

Arrays.sort(a);

for(int z:a)
{
	System.out.println(z);
}


	
	
	
	//int x=Arrays.compare(a,b);
		
		

	}

}
