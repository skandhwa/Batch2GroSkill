package Array;

public class ArrayIteration {
	
	//int []d= {12,34};

	public static void main(String[] args) {
		
		int c[]= {23,56,77,99,107};
		
//		for(int i=0;i<c.length;i++)//i=0,0<5//i=1,1<5//i=2,2<5
//		{
//			System.out.println(c[i]);///c[0]=23//c[1]//c[2]
//		}
		
		
		for(int x:c)
		{
			System.out.println(x);
		}
		

	}

}
