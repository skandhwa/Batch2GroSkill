package Array;

public class ArrayEx1 {

	public static void main(String[] args) {
		
		int []a= {12,56,77,99};
		
		System.out.println(a[3]);
		
		
		int []b=new int [5];
		b[0]=13;
		b[1]=45;
		b[2]=57;
		b[3]=79;
		b[4]=88;
		
		
		
		
		
		

	}

}
