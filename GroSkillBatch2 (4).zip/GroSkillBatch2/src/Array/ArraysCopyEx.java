package Array;

import java.util.Arrays;

public class ArraysCopyEx {

	public static void main(String[] args) {
		
		int []a= {12,45,67,88,99};
		
		int []b=new int[a.length];
		
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5
		{
			b[i]=a[i];//b[0]=12//b[1]=45//b[2]=67
		}
		
		for(int x:b)
		{
			System.out.println(x);
		}
		
		
		

	}

}
