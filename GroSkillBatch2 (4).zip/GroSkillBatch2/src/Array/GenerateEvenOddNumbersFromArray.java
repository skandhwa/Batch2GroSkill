package Array;

public class GenerateEvenOddNumbersFromArray {

	public static void main(String[] args) {
		
		int a[]= {1,2,5,6,4,7,9,11};
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]+" "+"Is an even number ");
			}
		}
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				System.out.println(a[i]+" "+"Is an odd number ");
			}
		}
		
		

	}

}
