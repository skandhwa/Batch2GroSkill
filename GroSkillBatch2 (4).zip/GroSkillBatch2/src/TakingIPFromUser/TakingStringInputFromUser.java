package TakingIPFromUser;

import java.util.Scanner;

public class TakingStringInputFromUser {

	public static void main(String[] args) {
		
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String as Input");
		
		str=sc.nextLine();
		
		
		
	int x=	str.length();
	
	System.out.println("Length is  "+x);
		
		
		

	}

}
