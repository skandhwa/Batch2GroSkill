package LoopingandControlFlowStatements;

public class MaxBwThreeNumber {

	public static void main(String[] args) {
		
		int a=20000;
		int b=4000;
		int c=3500;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("Maximum is a");
			}
			else
			{
				System.out.println("Maximum is c");
			}
		}
		
		else
		{
			if(b>c)
			{
				System.out.println("Maximum is b");
			}
			else
			{
				System.out.println("Maximum is c");
			}
		}

	}

}
