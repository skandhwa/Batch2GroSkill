package LoopingandControlFlowStatements;

public class FactorialNumber {

	public static void main(String[] args) {
		
		double fact=1;
		double num=252343;
		
		
		for(double i=num;i>0;i--)///i=6, 6>0///5>0
		{
			fact=fact*i;///fact=1*6=6//fact=6*5=30
		}
		
		System.out.println(fact);

	}

}
