package LoopingandControlFlowStatements;

public class NestedForLoopExample {

	public static void main(String[] args) {
		
		for(int i=0;i<4;i++)////i=0,0<4//i=1,1<4
		{
			for(int j=0;j<4;j++)///j=0,0<4
			{
				System.out.println(i+"  "+j);//0...0//0..1//0..2//0...3//1..0
			}
		}
		

	}

}
