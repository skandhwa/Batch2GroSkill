package LoopingandControlFlowStatements;

public class OddorEvenEx {

	public static void main(String[] args) {
		
		
		int num=19;
		
		if(num%2==0)
		{
			System.out.println("Even Number");
		}
		else
		{
			System.out.println("Odd Number");
		}

	}

}
