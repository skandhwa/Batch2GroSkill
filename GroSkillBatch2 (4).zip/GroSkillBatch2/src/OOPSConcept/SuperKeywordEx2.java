package OOPSConcept;

class Mammal
{
	String colour="blue";
}


class Animal extends Mammal
{
	String colour="black";
}

class Dog extends Animal
{
	String colour="red";
	void display()
	{
		System.out.println(super.colour);
	}
	
}


public class SuperKeywordEx2 {

	public static void main(String[] args) {
		
		
		Dog obj=new Dog();
		obj.display();
		
		
		

	}

}
