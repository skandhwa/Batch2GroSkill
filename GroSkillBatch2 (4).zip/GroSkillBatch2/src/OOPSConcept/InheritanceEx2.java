package OOPSConcept;

class A4
{
	void test()
	{
		System.out.println("Hello");
	}
}

class A7 extends A4
{
	void display()
	{
		System.out.println("Hi");
	}
}


class A8 extends A7
{
	void message()
	{
		System.out.println("Welcome");
	}
}


public class InheritanceEx2 {

	public static void main(String[] args) {
		
		A8 obj=new A8();
		obj.message();
		obj.test();
		obj.display();
		

	}

}
