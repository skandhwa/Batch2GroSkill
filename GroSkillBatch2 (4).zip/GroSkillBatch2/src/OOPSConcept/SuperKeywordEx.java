package OOPSConcept;

class C3
{
	int id=5;
}


class C2 extends C3
{
	int id=3;
	
	String name;
	
	void display()
	{
		System.out.println(id);
		System.out.println(super.id);
	}
}





public class SuperKeywordEx {

	public static void main(String[] args) {
		
		C2 obj=new C2();
		obj.display();

	}

}
