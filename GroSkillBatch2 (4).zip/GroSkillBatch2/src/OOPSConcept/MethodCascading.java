package OOPSConcept;

public class MethodCascading {

	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	
	void message()
	{
		display();
		test();
		System.out.println("Welcome");
		
	}

	public static void main(String[] args) {
		
		
		
		MethodCascading obj=new MethodCascading();
		obj.message();
		

	}

}
