package OOPSConcept;

class A5////superclass
{
	void display()
	{
		System.out.println("Hello");
	}
}

class A6 extends A5 ///A6 is subclass
{
	void test()
	{
		System.out.println("Hi");
	}
}

public class InheritanceExample {

	public static void main(String[] args) {
		
		A6 obj=new A6();
		obj.display();
		obj.test();
		

	}

}
