package OOPSConcept;

class B10
{
	void eat()
	{
		System.out.println("eating");
	}
}

class B11 extends B10
{
	void eat()
	{
		System.out.println("New eating");
	}
	
	void display()
	{
		System.out.println("Hi");
	}
	
	void test()
	{
		System.out.println("hello");
	}
	
	void message()
	{
		super.eat();
		eat();
		display();
		test();
		
	}
}

public class SuperMethodsEx {

	public static void main(String[] args) {
		
		B11 obj=new B11();
		obj.message();
		

	}

}
