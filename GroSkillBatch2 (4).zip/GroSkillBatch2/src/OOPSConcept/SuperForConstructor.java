package OOPSConcept;

class Animal2
{
	Animal2(int x,int y)
	{
		
		System.out.println("Hello");
	}
	
	Animal2()
	{
		
	}
}

class Dog2 extends Animal2
{
	Dog2()
	{
		super(12, 34);
		
		
		System.out.println("Hi");
		
	}
	
	Dog2(int x,int y)
	{
		
	}
	
	Dog2(int x,int y,int z)
	{
		
	}
}



public class SuperForConstructor {

	public static void main(String[] args) {
		
		Dog2 obj=new Dog2(23,56);
		
		Dog2 obj1=new Dog2(23,56,87);
		
		
		
		

	}

}
