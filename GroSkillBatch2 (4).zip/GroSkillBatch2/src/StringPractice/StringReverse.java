package StringPractice;

public class StringReverse {

	public static void main(String[] args) {
		
		String str="   nation   ";
		
		System.out.println("Before trim "+str);
		
	str=	str.trim();
		
		System.out.println("After trim "+str);
		
		String str1=str;
		
		String revstr="";
	str=	str.toLowerCase();
	
	for(int i=str.length()-1;i>=0;i--)//i=4,4>=0//i=3,3>=0//i=2,2>=0
	{
		revstr=revstr+str.charAt(i);///revstr=""+a=a//revstr=a+i=ai
	}
	//revstr=ai+d=aid//aidni
		
	
	System.out.println(revstr);
	
	if(str1.equalsIgnoreCase(revstr))
	{
		System.out.println("It is a palindrome String");
	}
	
	else
	{
		System.out.println("Not a palindrome string");
	}

	}
	
	
	

}
