package StringPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
