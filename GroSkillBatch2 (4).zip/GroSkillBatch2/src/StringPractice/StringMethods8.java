package StringPractice;

public class StringMethods8 {

	public static void main(String[] args) {
		
		String str="india";
		str=str.toUpperCase();
		System.out.println(str);
		
		String str2="SAVA";
		String str1="JAVA";
		
//	boolean flag=	str1.equals(str2);
//	
//	System.out.println("Are two string equal "+flag);
//		
//boolean flag1=	str1.equalsIgnoreCase(str2);
//	
////	System.out.println("Are two string equal "+flag1);
////		
////	int x=	str1.compareTo(str2);
////	
////	System.out.println("Comparing two strings "+x);
//		
		
		String str3="Tom";
		String str4="Harry";
		
	str3=	str3.concat(str4);
	
	System.out.println(str3);

	}

}
