package StringPractice;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Nation";
		
		
	int x=	str.length();
	
	System.out.println("Length of string is  "+x);
		
		
	char ch=	str.charAt(5);
	
	System.out.println(ch);
		
	}

}
