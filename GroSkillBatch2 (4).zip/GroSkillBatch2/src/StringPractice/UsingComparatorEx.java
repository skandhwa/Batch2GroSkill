package StringPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

class Student
{
	int roll;
	String name;
	int age;
	Student(int roll,String name,int age)
	{
		this.roll=roll;
		this.name=name;
		this.age=age;
	}
	
}

class AgeComparator implements Comparator<Student>
{
	public int compare(Student s1,Student s2)
	{
		if(s1.age==s2.age)
		{
			return 0;
		}
		else if(s1.age>s2.age)
		{
			return 1;
		}
		
		else
		{
			return -1;
		}
	}
}


class NameComparator implements Comparator<Student>
{
	public int compare(Student s1,Student s2)
	{
		return s1.name.compareTo(s2.name);
	}
}




public class UsingComparatorEx {

	public static void main(String[] args) {
		
		ArrayList<Student> a1=new ArrayList<Student>();
		
		a1.add(new Student(1234,"Manish",32));
		a1.add(new Student(2234,"Harish",92));
		a1.add(new Student(3234,"Sarish",82));
		a1.add(new Student(9234,"Girish",42));
		System.out.println("Sorting by name");
		
		Collections.sort(a1,new NameComparator() );
		
		for(Student x:a1)
		{
			System.out.println(x.age+" "+x.name+" "+x.roll);
		}
		
System.out.println("Sorting by age");
		
		Collections.sort(a1,new AgeComparator() );
		
		for(Student y:a1)
		{
			System.out.println(y.age+" "+y.name+" "+y.roll);
		}

	}

}
