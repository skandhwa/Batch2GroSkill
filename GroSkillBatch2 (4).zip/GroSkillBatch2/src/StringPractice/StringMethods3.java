package StringPractice;

public class StringMethods3 {

	public static void main(String[] args) {
	
		String str="National";
		
//	str=	str.substring(4);
		
		System.out.println(str);
			String str1=	str.substring(3, 6);
	
	System.out.println(str1);
	
	
	
		
		
		
		

	}

}
