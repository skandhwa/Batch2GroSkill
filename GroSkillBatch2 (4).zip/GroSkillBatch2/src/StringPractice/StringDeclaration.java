package StringPractice;

public class StringDeclaration {

	public static void main(String[] args) {
		
		String str="India";///String literals
		
		
	str=	str.concat("Nation");
		
		System.out.println(str);
		
		//String str1="India";
		
		String str2=new String("Welcome");
		
		

	}

}
