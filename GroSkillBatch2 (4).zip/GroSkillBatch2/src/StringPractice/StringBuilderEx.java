package StringPractice;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Saurabh");
		sb.append("Kandhway");
		System.out.println(sb);
		
		sb.insert(2, "Java");
		System.out.println(sb);
		
		//replace
		//reverse
		
		//length
		//repeat
		

	}

}
