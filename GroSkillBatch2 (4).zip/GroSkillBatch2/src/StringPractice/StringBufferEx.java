package StringPractice;

public class StringBufferEx {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Saurabh");
		sb.append("Kandhway");
		
		System.out.println(sb);
		
		sb.insert(1, "Python");
		
		System.out.println(sb);
		
		
	System.out.println(sb.toString());	
	
	//replace
	///append
	//length
	//reverse
	
	
	
		

	}

}
