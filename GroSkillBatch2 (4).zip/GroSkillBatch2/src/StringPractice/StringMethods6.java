package StringPractice;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="India National Country ";
		
	String str1=	str.replaceAll("Country", "Religion");
	
	System.out.println(str1);
	
	
	
	String str2="Harry";
	str2=str2.replace('H', 'G');
	
	System.out.println(str2);
	
	
	
	
		
		
		
		
		

	}

}
