package StepDefinition8;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition8 {
	
	WebDriver driver;
	
	@Before
	public void beforeEx()
	{
		System.out.println("I will execute before every test");
	}
	
	@After
	public void afterTest()
	{
		System.out.println("I will execute after test");
	}
	
	@Before("@sanity")
	public void beforesanity()
	{
		System.out.println("I will execute before sanity");
	}
	
	@After("@smoke")
	public void afterSomke()
	{
		System.out.println("I will execute after smoke");
	}
	
	
	
	@Given("user opens the application in the browser")
	public void user_opens_the_application_in_the_browser() {
		
		System.out.println("Application launched");
		
		
	    
	}

	@Given("user enters the {string} in the username field")
	public void user_enters_the_in_the_username_field(String string) {
	    
		System.out.println("Username added");
		
		
	}

	@Given("user enters the {string} in the password field")
	public void user_enters_the_in_the_password_field(String string) {
	   
		System.out.println("Password added");
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	 
		System.out.println("Login button clicked");
		
	}

	@Then("user will be able to login into the application")
	public void user_will_be_able_to_login_into_the_application() {
	   
		System.out.println("Login successfull");
	}

	@Then("user selects a specific item in the application")
	public void user_selects_a_specific_item_in_the_application() {
	    
		System.out.println("Item selected");
		
	}

	@Then("user add that item in the cart")
	public void user_add_that_item_in_the_cart() {
		
		System.out.println("Item added");
	   
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
		System.out.println("submit button clicked");
	    
	}

	@Then("user will be navigated to the payment gateway")
	public void user_will_be_navigated_to_the_payment_gateway() {
		System.out.println("Navigated to Payment gateway");
	   
	}

	
	@Then("user will be nvaigated to home page of application")
	public void user_will_be_nvaigated_to_home_page_of_application() {
	    
		System.out.println("User navigated to home page");
	}
	
	@Given("user opens the demo website of guru99")
	public void user_opens_the_demo_website_of_guru99() {
	    
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		
	}

	@Given("user enters the following details")
	public void user_enters_the_following_details(io.cucumber.datatable.DataTable userdetails) {
	    
	List<List<String>> data=userdetails.asLists(String.class);
	driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
	driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
	driver.findElement(By.xpath("//textarea[@rows='3']")).sendKeys(data.get(1).get(2));
	
	
	
	
	
	
		
		
		
	}


	
	

}
