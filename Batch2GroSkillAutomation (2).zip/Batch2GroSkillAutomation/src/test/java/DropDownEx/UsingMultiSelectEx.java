package DropDownEx;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class UsingMultiSelectEx {

	public static void main(String[] args) throws InterruptedException {
		

		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
		
	Select oselect=new Select(ele);
	
if(	oselect.isMultiple()==true)
{
	oselect.selectByIndex(0);
	oselect.selectByIndex(1);
	oselect.selectByIndex(2);
	oselect.selectByIndex(3);
	Thread.sleep(4000);
	oselect.deselectByIndex(0);
	oselect.deselectByIndex(1);
	Thread.sleep(4000);
	
List<WebElement> li=	oselect.getAllSelectedOptions();

for(WebElement x:li)
{
	System.out.println(x.getText());
}
	

WebElement ele2=oselect.getFirstSelectedOption();

System.out.println("First Selected option is  "+ele2.getText());
	
	
}
	
		
		
		
		

	}

}
