package GroSkillAutomation.Batch2GroSkillAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
	String title=	driver.getTitle();
	
	System.out.println("Title of web page is "+title);
		
	String CurrentURL=	driver.getCurrentUrl();
	
	System.out.println("The current URL of page is  "+CurrentURL);
	
	String PageSource=driver.getPageSource();
	
	System.out.println("The page source is  "+PageSource);
	
	

	}

}
