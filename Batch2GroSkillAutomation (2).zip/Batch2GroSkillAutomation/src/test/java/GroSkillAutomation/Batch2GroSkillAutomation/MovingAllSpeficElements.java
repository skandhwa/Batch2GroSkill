package GroSkillAutomation.Batch2GroSkillAutomation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MovingAllSpeficElements {

	public static void main(String[] args) {
		
		int []a= {2,3,1,0,5,0,8,0,12,0};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(Integer x:a)
		{
			if(x==0)
			{
				li1.add(x);
			}
			
			else
			{
				li2.add(x);
			
			}
			
			Collections.sort(li2);
		}
		
		li1.addAll(li2);
		
		for(Integer y:li1)
		{
			System.out.print(y+" ");
		}

	}

}
