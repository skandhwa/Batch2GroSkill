package UsingJavaScriptExecutorEx;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JsEx4 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("history.go(0)");
		
	String title=	js.executeScript("return document.title;").toString();
		System.out.println("title of page is "+title);

	}

}
