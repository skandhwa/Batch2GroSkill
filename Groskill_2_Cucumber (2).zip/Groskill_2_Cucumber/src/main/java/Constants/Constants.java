package Constants;

public class Constants {
	
	public static final String URLValue="C:\\Users\\saura\\OneDrive\\Documents\\TestData21stFeb.xlsx";
	public static final String PropertyFilePath="src\\main\\java\\Constants\\Global.properties";
	
	

}
