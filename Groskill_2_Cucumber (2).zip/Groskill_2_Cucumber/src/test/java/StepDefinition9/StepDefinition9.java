package StepDefinition9;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageFactoryClasses.LoginPageGuru99;
import PageFactoryClasses.NewCustomerCreation10;
import Utilities.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition9 extends BaseClass {
	
	WebDriver driver=intializeDriver();
	LoginPageGuru99 obj=new LoginPageGuru99(driver);
	NewCustomerCreation10 obj1=new NewCustomerCreation10(driver);
	
	@Given("user loads the URL in the browser")
	public void user_loads_the_url_in_the_browser() throws IOException {
		
		System.out.println("Application launched");
		
		maximizeWindow();
		takeScreenshot();
		getTitle();
		
	    
	}

	@Given("user enters the username in uname field as {string}")
	public void user_enters_the_username_in_uname_field_as(String username) {
		
		obj.enterUserName(username);
	   
	}

	@Given("user enters the password in password field as {string}")
	public void user_enters_the_password_in_password_field_as(String password) {
		
		obj.enterPassword(password);
	    
	}

	@When("user clicks the login button in the application")
	public void user_clicks_the_login_button_in_the_application() {
		
		obj.clickLogin();
	   
	}

	@Then("user will be navigated to Guru99 demo applications homepage")
	public void user_will_be_navigated_to_guru99_demo_applications_homepage() {
		
		getTitle();
		//Assert.assertEquals(getTitle(),"Guru99 Bank Manager HomePage");
	    
	}
	
	
	@Then("User clicks on New Customer Creation link in the demoguru app")
	public void user_clicks_on_new_customer_creation_link_in_the_demoguru_app() {
		
		obj1.clickNewCustomer();
	    
	}

	@Then("user enters the customer name in the app as {string}")
	public void user_enters_the_customer_name_in_the_app_as(String Customer_name) {
	 
		
		obj1.enterCustomerName(Customer_name);
	}

	@Then("user selects the gender")
	public void user_selects_the_gender() {
		
		obj1.selectGender();
	   
	}

	@Then("user enters the date of birth in the field of DOB as {string}")
	public void user_enters_the_date_of_birth_in_the_field_of_dob_as(String date_of_birth) {
	   
		obj1.enterDOB(date_of_birth);
		
	}
	
	
	@Then("user completes the execution")
	public void user_completes_the_execution() throws InterruptedException {
	   
		closeBrowser();
		
	}

	
	
	
	
	
	
	
	
	

}
