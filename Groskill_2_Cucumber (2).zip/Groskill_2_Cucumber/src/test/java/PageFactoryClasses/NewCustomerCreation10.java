package PageFactoryClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utilities.BaseClass;

public class NewCustomerCreation10 extends BaseClass {
	
	 WebDriver driver;
     
     public NewCustomerCreation10(WebDriver driver)
     {
  	   this.driver=driver;
  	   PageFactory.initElements(driver,this);
     }
     
     @FindBy(xpath="//a[text()='New Customer']")
     WebElement newCustomerLink;
     
     @FindBy(xpath="//input[@name='name']")
     WebElement custName;
     
     @FindBy(xpath="//input[@value='m']")
     WebElement gender;
     
     @FindBy(xpath="//input[@id='dob']")
     WebElement DOB;
     
     
     public void clickNewCustomer()
     {
    	 newCustomerLink.click();
     }
     
     public void enterCustomerName(String cName)
     {
    	 custName.sendKeys(cName);
     }
     
     public void selectGender()
     {
    	 gender.click();
     }
     
     
     public void enterDOB(String doB)
     {
    	 DOB.sendKeys(doB);
     }
     
     
     
     

}
