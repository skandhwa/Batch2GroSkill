package Utilities;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {
	
	static String browsername;
	public static WebDriver driver;
	
	
	public static WebDriver intializeDriver()
	{
		try {
			browsername=FetchDataFromProperty.fetchDataFromProperty().getProperty("browser");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(browsername.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			
			try {
				driver.get(FetchDataFromExcel.getURL(1, 0));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
		if(browsername.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			
			try {
				driver.get(FetchDataFromExcel.getURL(1, 0));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		if(browsername.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			
			try {
				driver.get(FetchDataFromExcel.getURL(1, 0));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		return driver;
		
		
		
	}
	
	
	public static void getTitle()
	{
		String Title=driver.getTitle();
		System.out.println("The tite of page is "+Title);
	}
	
	public static void takeScreenshot() throws IOException
	{
		TakesScreenshot srcShot=(TakesScreenshot)driver;
		File srcFile=srcShot.getScreenshotAs(OutputType.FILE);
		File destFile=new File("C:\\Users\\saura\\OneDrive\\Pictures\\MyScreenshot1\\Mypic.jpeg");
		FileUtils.copyFile(srcFile, destFile);
		
	}
	
	
	public static void scrollDown() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,300)", "");
		Thread.sleep(3000);
	}
	
	public static void maximizeWindow()
	{
		driver.manage().window().maximize();
	}
	
	public static void addImplicitWait()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	
	public static void closeBrowser() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.quit();
	}
	
	
	
	
	
	

}
