package LoopingandControlFlowStatements;

public class WhileLoopEx {

	public static void main(String[] args) {
		
		int i=5;////assignment
		
		while(i<10)///5<10//6<10//7<10//8<10//9<10//10<10//Condition checking
			
		{
			
			System.out.print(i+"  ");//5//6//7//8//9
			//5++//6++//7++//8++//9++ ///Increment or decrement
			
			i++;
		}
		
		

	}

}
