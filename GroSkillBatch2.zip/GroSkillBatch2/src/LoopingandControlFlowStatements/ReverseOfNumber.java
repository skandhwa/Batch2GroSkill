package LoopingandControlFlowStatements;

public class ReverseOfNumber {

	public static void main(String[] args) {
		
		int num=-1123;////
		
		int t=num;
		
		int rev=0;
		
		int r=0;
		
		while(num!=0)///1!=0 ///0!=0
		{
			r=num%10;      ///123%10=3       /// 12%10=2   /// r=1
			rev=rev*10+r;  ///rev=0*10+3=3 ////3*10+2=32   /// rev=32*10+1=321
			num=num/10;  ///123/10=12      ///12/10=1  ///1/10=0
		}
		
		System.out.println(rev);
		
		
		if(t==rev)
		{
			System.out.println("It is a plaindrome number");
		}
		else
		{
			System.out.println("Not a Palindrome number");
		}
		
		

	}

}
