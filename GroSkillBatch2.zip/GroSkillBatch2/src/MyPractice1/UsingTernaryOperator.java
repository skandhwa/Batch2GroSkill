package MyPractice1;

public class UsingTernaryOperator {

	public static void main(String[] args) {
		
		int a=10;
		int b=50;
		int c=15;
		
		if(a>b)
		{
			System.out.println("max is a");
		}
		else
		{
			System.out.println("max is b");
		}
		
		
		//int max= a>b ?a:b;
		int max= a>b ? (a>c ?a:c) :  (b>c?b:c); 
		

	}

}
