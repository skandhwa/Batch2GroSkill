package MyPractice1;

class T8
{
	int id;
	boolean flag;
	
	T8()
	{
		
	}
	
	
//	T8()
//	{
//		System.out.println("Hi");
//	}
//	
	
	void test()
	{
		System.out.println(id+" "+flag);
	}
}


public class ConstructorEx {

	public static void main(String[] args) {
		
		T8 obj=new T8();
		obj.test();
		

	}

}
