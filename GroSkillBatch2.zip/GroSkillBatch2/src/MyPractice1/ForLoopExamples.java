package MyPractice1;

public class ForLoopExamples {

	public static void main(String[] args) {
		
	//	for(initialization;condition checking;increment/decrement)
		
		
		for(int i=1;i<=5;)//i=1, 1<=5//2<=5//3<=5//4<=5
		{
			System.out.println(i);///1///2//3//4//5
			i++;
			
		}
		

	}

}
