package MyPractice1;

public class Operators2 {

	public static void main(String[] args) {
		
		
		int d=1/10;
		System.out.println(d);
		
		int a=20;
		int b=40;
		int c=a+b;
		
		System.out.println(6<<4);///6*2pow4
		
		System.out.println(36>>3);/// 36/2pow3
		
		System.out.println(246>>4);

	}

}
