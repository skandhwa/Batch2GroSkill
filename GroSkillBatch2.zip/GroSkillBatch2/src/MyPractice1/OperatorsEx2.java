package MyPractice1;

public class OperatorsEx2 {

	public static void main(String[] args) {
		
//		int x=10;
//		
////		int y=x--;
////		
////		
////		int z= ++x;///++9
////		
////		System.out.println(y);
////		System.out.println(z);
//		
//		
//		int p= x-- - --x; /// 10 - (8)
//		
//		System.out.println(p);
		
		
		int a=10 ;//11
		int b=15; //14
		int c=5;//6
		
		int sum = a++ - b-- + c++ - --a - ++b + ++c;
		
		/// -19 , -18 , -16 ,-17 , -18 , -19 , -18 , -18 ,-18, -17  
		
		/// 10 - 15 + 5 - 10 - 15 + 7
		
		
		System.out.println(sum);
		
		
		
		
//		

	}

}
