package JavaPractice;

class MyTest18 {
	
	public static String display(String x,String y)
	{
		return x+y;
	}
	
	

}
