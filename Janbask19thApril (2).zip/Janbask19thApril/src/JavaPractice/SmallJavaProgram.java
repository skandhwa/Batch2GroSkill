package JavaPractice;

public class SmallJavaProgram {
	
	public void add()
	{
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
	}
	
	public void test()
	{
		for(int i=0;i<=20;i++)
		{
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		
		SmallJavaProgram object=new SmallJavaProgram();
		object.add();
		object.test();
		
		
		
		
		
		
		

	}

}
