package JavaPractice;

public class TestNew2 {
	
      static  int p=30;
	
	void display()
	{
		
		
	}
	
	int q=p+40;
	
	
	
	
	

	public static void main(String[] args) {
		
		int x=10,z=60;
		int y=20;
		
		
		
		if(x<y)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		
		

	}

}
