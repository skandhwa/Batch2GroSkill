package JavaPractice;

public class MyTest19 {

	public static void main(String[] args) {
		
	System.out.println(MyTest18.display("India","Republic"));	
		

	}

}
