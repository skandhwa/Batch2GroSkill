package JavaPractice;

public class UsingStaticKeyword {
	
	final float g=9.8f;
	
	
	static void display()
	{
		
		g=65.76f;
		System.out.println("Hello");
	}
	
	public static void main(String[] args) {
		
//		UsingStaticKeyword obj=new UsingStaticKeyword();
//		obj.display();
		
		UsingStaticKeyword.display();
		
		
		

	}

}
