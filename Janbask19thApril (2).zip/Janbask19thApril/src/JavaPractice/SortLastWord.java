package JavaPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortLastWord {

	public static void main(String[] args) {
		
		String str="I love java";
		
		String str1="I love";
		
		String str2="";
		
	    
		
		String []s=str.split(" ");
		
		
		
	    for(int i=2;i<s.length;i++)
	    {
	    	
	    	List<Character> li=new ArrayList<Character>();
	    	for(char y:s[i].toCharArray())
	    	{
	    		
	    		li.add(y);
	    		
	    		
	    	}
	    	
	    	Collections.reverse(li);
	    	str2=String.join(str2, s);
	    	
	    	
	    	
	    }
	    
	    
	    System.out.println(sb.toString());
	    
	    
	    
	    
	    
	    
	    
	    
		

	}

}
