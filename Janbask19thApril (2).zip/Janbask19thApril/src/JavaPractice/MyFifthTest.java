package JavaPractice;

public class MyFifthTest {
	
	public  void display5()
	{
		System.out.println("Hello");
	}
	
	
	
	
	

	public static void main(String[] args) {
		
		
		
		

	}

}
