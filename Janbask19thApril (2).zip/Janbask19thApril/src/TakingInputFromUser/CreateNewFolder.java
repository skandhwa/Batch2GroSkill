package TakingInputFromUser;

import java.io.File;

public class CreateNewFolder {

	public static void main(String[] args) {
		
		File fileobj=new File("D:\\Janbask30thApril\\MyPractice");
		//fileobj.mkdir();
		
	boolean flag=	fileobj.exists();
	System.out.println(flag);
	
	if(flag==true)
	{
		System.out.println("Folder exists");
	}
	else
	{
		System.out.println("Folder doesnot exist");
	}
	
	boolean result=fileobj.delete();
	System.out.println(result);
		
	
	}

}
