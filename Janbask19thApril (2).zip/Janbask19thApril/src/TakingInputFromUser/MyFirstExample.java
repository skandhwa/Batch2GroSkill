package TakingInputFromUser;

import java.util.Scanner;

public class MyFirstExample {

	public static void main(String[] args) {
		
//		int num1,num2;
		Scanner sc=new Scanner(System.in);
//		
//		System.out.println("Enter the first number");
//		
//		num1=sc.nextfloat();
//		
//System.out.println("Enter the second number");
//		
//		num2=sc.nextInt();
//		
//		int sum=num1+num2;
//		
//		System.out.println("The Sum of two numbers are  "+sum);
//		
		
		String str;
		System.out.println("Enter the String");
		str=sc.nextLine();
		
		int x=str.length();
		
		System.out.println("The length is "+x);
		
		
		
		
		
		
		
		

	}

}
