package TakingInputFromUser;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {

	public static void main(String[] args) throws IOException {
		
		File fileobj=new File("D:\\Janbask30thApril\\MyPractice4\\testnew2.txt");
//	boolean flag=	fileobj.createNewFile();
//	System.out.println(flag);
		
	boolean flag1=	fileobj.delete();
	System.out.println(flag1);
		
		

	}

}
