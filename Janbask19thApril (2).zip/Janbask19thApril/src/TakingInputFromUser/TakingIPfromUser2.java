package TakingInputFromUser;

import java.util.Scanner;

public class TakingIPfromUser2 {

	public static void main(String[] args) {
		
		long num;
		
		System.out.println("Enter a number which is in long format");
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextLong();
	
		System.out.println("Entered Mobile number is "+num);
		
		
		
		

	}

}
