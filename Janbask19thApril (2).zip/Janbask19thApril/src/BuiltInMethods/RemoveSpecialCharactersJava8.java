package BuiltInMethods;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee {
    int id;
    String name;
    String department;

    // Constructor
    public Employee(int id, String name, String department) {
        this.id = id;
        this.name = name;
        this.department = department;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                '}';
    }
}

public class RemoveSpecialCharactersJava8 {
    public static void main(String[] args) {
        // Create a list of employees with special characters in their fields
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "John@Doe", "IT*Support"));
        employees.add(new Employee(2, "Jane!Smith", "HR&Admin"));
        employees.add(new Employee(3, "Mark#Johnson", "Finance%Dept"));

        // Process employees using Java 8 Streams to remove special characters
        List<Employee> cleanedEmployees = employees.stream()
                .map(emp -> new Employee(
                        emp.id,
                        emp.name.replaceAll("[^a-zA-Z0-9 ]", ""),
                        emp.department.replaceAll("[^a-zA-Z0-9 ]", "")
                ))
                .collect(Collectors.toList());

        // Print the employees after cleaning
        System.out.println("Employees after removing special characters:");
        cleanedEmployees.forEach(System.out::println);
    }
}

