package BuiltInMethods;

public class StringComparisionEx {

	public static void main(String[] args) {
		
		
		String str1="java";
		String str2="Java";
		
		boolean flag=str1.equalsIgnoreCase(str2);
		System.out.println(flag);
		

	}

}
