package BuiltInMethods;

public class StringMethodsDetailed {

	public static void main(String[] args) {
		
		
		String str="India";
	String str1=	str.substring(2);
	System.out.println(str1);

	}

}
