package BuiltInMethods;

public class UsingStringMethods {

	public static void main(String[] args) {
		
		String str1="ASelenium";
		String str2="Selenium";
		
		System.out.println(str2.compareTo(str1));
		
		

	}

}
