package BuiltInMethods;

public class MyFirstExample {

	public static void main(String[] args) {
		
		String str1="Selenium";
		String str2="Selenium";
		
	System.out.println((str1.compareTo(str2)));
		

	}

}
