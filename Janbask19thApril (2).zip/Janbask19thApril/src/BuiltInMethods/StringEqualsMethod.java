package BuiltInMethods;

public class StringEqualsMethod {

	public static void main(String[] args) {
		
		String str1="Selenium";
		String str2="selenium";
		boolean flag= str1.equalsIgnoreCase(str2);
		System.out.println(flag);
		
		String str="    India     ";
		String str4=str.trim();
		System.out.println(str4);
		

	}

}
