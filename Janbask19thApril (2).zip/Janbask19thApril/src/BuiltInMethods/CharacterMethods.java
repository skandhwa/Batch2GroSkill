package BuiltInMethods;

import java.util.Arrays;

public class CharacterMethods {

	public static void main(String[] args) {
	
		char ch='A';
		char ch2='z';
		System.out.println(Character.isUpperCase(ch));
		System.out.println(Character.isUpperCase(ch2));
		
		String []charArray= {"Selenium","UFT","dotNet"};
		String str=Arrays.toString(charArray);
		System.out.println(str);
		
	boolean flag=	Arrays.asList(charArray).contains("Python");
	System.out.println(flag);
	    
		
		

	}

}
