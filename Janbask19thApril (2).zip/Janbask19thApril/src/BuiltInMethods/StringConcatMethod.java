package BuiltInMethods;

public class StringConcatMethod {

	public static void main(String[] args) {
		
		
		String str1="Saurabh";
		String str4="saurabh";
		
		boolean flag=str1.equalsIgnoreCase(str4);
		System.out.println(flag);
		
		String str2="Kandhway";
		
	str1=	str1.concat(str2);
	
	System.out.println(str1);
	
	String str3="Raghu";
	char ch=str3.charAt(2);
	System.out.println(ch);
	
		
		

	}

}
