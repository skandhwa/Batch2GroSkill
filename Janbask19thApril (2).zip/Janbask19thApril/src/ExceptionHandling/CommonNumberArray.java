package ExceptionHandling;

public class CommonNumberArray {

	public static void main(String[] args) {
		
		
		int []a= {5,5,5};
		int count=1,x=1;
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					x=count+1;
				}
			}
		}
		
		System.out.println(x);

	}

}
