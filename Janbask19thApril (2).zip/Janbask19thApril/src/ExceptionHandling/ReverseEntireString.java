package ExceptionHandling;

public class ReverseEntireString {

	public static void main(String[] args) {
		
		String str="My name is Ashwin I am an Engineer by Profession";
		
		String revstr="";
		
		String []ch=str.split(" ");
		
		for(int i=ch.length-1;i>=0;i--)
		{
			revstr=revstr+ch[i]+" ";
		}
		
		System.out.println(revstr);
		

	}

}
