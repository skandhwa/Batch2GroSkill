package ExceptionHandling;

public class ReverseEntireArray {

	public static void main(String[] args) {
		
		int []a= {23,45,67,88};
		
		int []b=new int[a.length];
		
		for(int i=a.length-1;i>=0;i--)
		{
			b[i]=a[i];
			System.out.print(b[i]+" ");
			
		}
		

	}

}
