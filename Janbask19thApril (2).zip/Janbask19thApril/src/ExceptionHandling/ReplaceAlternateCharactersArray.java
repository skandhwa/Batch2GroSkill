package ExceptionHandling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReplaceAlternateCharactersArray {

	public static void main(String[] args) {
		
		Object []a= {12,34,67,88,99,32};
		
		for(int i=1;i<a.length;i+=2)
		{
			a[i]='&';
		}
		
		System.out.println(Arrays.toString(a));
		

	}

}
