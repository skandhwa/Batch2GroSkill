package ExceptionHandling;

public class StringSorting {

	public static void main(String[] args) {
		
		String str="Saurabh";
		int x=str.length();
		String str1="";
		
		for(int i=0;i<x;i++)
		{
			for(int j=i+1;j<x;j++)
			{
				str1=str.substring(i,j);
				System.out.println(str1);
			}
		}
		
		
		
		
		
		
		
		
		
		

	}

}
