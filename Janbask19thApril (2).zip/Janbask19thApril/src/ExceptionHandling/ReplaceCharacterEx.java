package ExceptionHandling;

public class ReplaceCharacterEx {

	public static void main(String[] args) {
		
		String str="Zoho";
		String replacement="$";
		StringBuilder sb=new StringBuilder();
		int count=2;
		
		char toreplace='o';
		char []str1=str.toCharArray();
		
		for(char x:str1)
		{
			if(x==toreplace)
			{
				sb.append(replacement.repeat(count));
				count--;
				
			}
			
			else
			{
				sb.append(x);
			}
		}
		
		System.out.println(sb.toString());
		
		
		
		
		
		

	}

}
