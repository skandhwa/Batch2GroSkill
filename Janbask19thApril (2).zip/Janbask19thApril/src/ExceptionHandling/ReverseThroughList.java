package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseThroughList {

	public static void main(String[] args) {
		
		int[] a = {12, 45, 78, 43, 67, 99, 19, 51, 87};
		
		
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		ArrayList<Integer> li2=new ArrayList<Integer>();
		ArrayList<Integer> li3=new ArrayList<Integer>();
		
		for(int i=0;i<3;i++)//i=0,0<3
		{
			
				li.add(a[i]);///li.add
				
			
			
			
		}
		
		Collections.reverse(li);
		
		System.out.println(li);
		
		for(int i=3;i<6;i++)
		{
			
				li2.add(a[i]);
				
			
			
			
		}
		
		Collections.reverse(li2);
		
		for(int i=6;i<a.length;i++)
		{
			
				li3.add(a[i]);
				
			
			
			
		}
		
		Collections.reverse(li3);
		
		
		li.addAll(li2);
		
		li.addAll(li3);
		
		System.out.println(li);
		

	}

}
