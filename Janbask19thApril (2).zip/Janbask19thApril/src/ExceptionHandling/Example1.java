package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Example1 {

	public static void main(String[] args) {
		
		String str= "appe banana mango";
		String []s1=str.split(" ");
		String revstr="";
		for(int i=0;i<s1.length;i++)
		{
			String revword="";
			String s2=s1[i];
			for(int j=s2.length()-1;j>=0;j--)
			{
				revword=revword+s2.charAt(j);
			}
			
			revstr=revstr+revword+" ";
			
		}
		
		System.out.println(revstr);
		
		char []s3=revstr.toCharArray();
		List<Character> li=new ArrayList<Character>();
		
		
		for(char x:s3)
		{
			li.add(x);
		}
		
		System.out.println(li);
		
		Collections.sort(li);
		System.out.println(li);
		
		
		
		

	}

}
