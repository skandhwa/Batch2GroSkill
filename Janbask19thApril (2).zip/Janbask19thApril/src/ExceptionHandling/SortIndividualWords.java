package ExceptionHandling;

import java.util.ArrayList;
import java.util.List;

public class SortIndividualWords {

	public static void main(String[] args) {
		
		String str="apple banana mango";
		String revstr=" ";
		String []s1=str.split("");
		for(int i=0;i<s1.length-1;i++)
		{
			String s2=s1[i];
		   String revword="";
		   for(int j=s1.length-1;j>=0;j--)
		   {
			   
			   revword=revword+s2.charAt(j);
			   
			   
		   }
		   
		   revstr=revstr+revword+" "; 
		   
		  
			
		}
		
		
		 System.out.println(revstr);
		 
		 
		 String []s3=revstr.split(" ");
		 List<String> li=new ArrayList<String>();
		 for(String z:s3)
		 {
			 li.add(z);
		 }
		 
		 System.out.println(li);
		 
		 
		 
		
		

		 
		    }
		}