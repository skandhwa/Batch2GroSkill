package ExceptionHandling;

import java.util.HashSet;

public class StringPanagram {

	public static void main(String[] args) {
		
		
		String str="The brown fox jumps over the lazy dog";
		
		 HashSet<Character> letters = new HashSet<Character>();

	        // Add each alphabetic character to the set.
	        for (char ch : str.toCharArray()) {
	            if (ch >= 'a' && ch <= 'z') {
	                letters.add(ch);
	            }
	        }
	        
	        
	        if(letters.size()==26)
	        {
	        	System.out.println("String is Panagram");
	        }
	        
	        else
	        {
	        	System.out.println("String is Not Panagram");
	        }

	}

}
