package ExceptionHandling;

import java.util.Arrays;

public class ReverseEachInteger {
  
    public static int reverseInteger(int num) {
    	
    	
        int reversed = 0;

        while (num != 0) {
            int digit = num % 10; 
            reversed = reversed * 10 + digit; 
            num /= 10; 
        }

        return reversed;
    }

    
    public static int[] reverseEachElement(int[] array) {
        int[] reversedArray = new int[array.length];

        for (int i = 0; i < array.length; i++) {
            reversedArray[i] = reverseInteger(array[i]);
        }

        return reversedArray;
    }
    
    
    public static void main(String[] args) {
        
        int[] array = { 35,63,22,91,84 };

        
        int[] reversedArray = reverseEachElement(array);

       
        System.out.println("Original Array: " + Arrays.toString(array));
        System.out.println("Reversed Array: " + Arrays.toString(reversedArray));
        int []b=reversedArray;
        Arrays.sort(b);
        
     System.out.println("Sorted Array is "+Arrays.toString(b));   ;
        
        
        
    }
}