package ExceptionHandling;

import java.util.Arrays;

public class ReverseArrayByThirdIndex {

	public static void main(String[] args) {
		int[] a = {12, 45, 78, 43, 67, 99, 19, 51, 87};

       
        for (int i = 0; i < a.length; i+=3) 
        
        {
            
            if (i + 2 < a.length) {
               
                int temp = a[i];
                a[i] = a[i + 2];
                a[i + 2] = temp;
            }
        }

        System.out.println("Output Array: " + Arrays.toString(a));
    }

}
