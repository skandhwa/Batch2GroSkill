package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class StringSort {

	public static void main(String[] args) {
		
		String str="banana apple melon kiwi";
		String []s1=str.split(" ");
		
		ArrayList<String> li=new ArrayList<String>();
		
		for(String x:s1)
		{
			li.add(x);
		}
		Collections.sort(li);
		
		System.out.println(li);
		
		
		
		
		

	}

}
