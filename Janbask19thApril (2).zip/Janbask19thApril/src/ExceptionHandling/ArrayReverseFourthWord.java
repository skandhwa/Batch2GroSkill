package ExceptionHandling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayReverseFourthWord {

	public static void main(String[] args) {
		
		int []a= {12,45,67,88,92,49,76,54};
		
		System.out.println(a.toString());
		
		List li=new ArrayList<>(Arrays.asList(a));
		
		
		System.out.println(li.toString());
		
		
		
		Collections.rotate(li, 3);
		
		Object []b=li.toArray();
		
		for(Object x:b)
		{
			System.out.println(x);
		}
		
		
		
		
		
		for(int i=0;i<a.length;i=i+1)//i=0,0<8
		{
			if(i+2< a.length)///2<8
			{
				int temp=a[i];////
				a[i]=a[i+2];
				a[i+2]=temp;
			}
		}
		
		
		System.out.println(Arrays.toString(a));
		
		

	}

}
