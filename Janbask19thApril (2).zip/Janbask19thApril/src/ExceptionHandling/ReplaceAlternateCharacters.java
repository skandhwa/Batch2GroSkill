package ExceptionHandling;

public class ReplaceAlternateCharacters {

	public static void main(String[] args) {
		
		String str="Saurabh";
		StringBuilder sb=new StringBuilder(str);
		
		for(int i=1;i<str.length();i=i+2)
		{
			sb.setCharAt(i, '$');
		}
		
		System.out.println(sb.toString());
		
		

	}

}
