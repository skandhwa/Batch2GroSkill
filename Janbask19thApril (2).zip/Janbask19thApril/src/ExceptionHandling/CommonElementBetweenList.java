package ExceptionHandling;

import java.util.ArrayList;
import java.util.List;

public class CommonElementBetweenList {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(12);
		

	}

}
