package ExceptionHandling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseEachWord {

	public static void main(String[] args) {
		
		String str="Java is a programming language";
		str=str.toLowerCase();
		
		
		String []s=str.split(" ");
		String reverseString="";
		
		for(int i=0;i<s.length;i++)///i=0,0<5
		{
			String s2=s[i];///s2=s[0]
			String revword=" ";
			
			for(int j=s2.length()-1;j>=0;j--)//j=3,3>=0
			{
				revword=revword+s2.charAt(j);///revword=""+a
			}
			
			reverseString = reverseString + revword + " ";
			
			
		
		

	}
		
		System.out.println("Original String is  "+str);
		
		System.out.println("Reverse String is  "+reverseString);
		
		
//		List<String> li2=new ArrayList<String>();
//		String []s3=reverseString.split("  ");
//		
//		for(String y:s3)
//		{
//			li2.add(y);
//		}
//		
//		System.out.println(li2);
//		
//		Collections.sort(li2);
//		
//		System.out.println(li2);
		
		
		
		
		
	
		
		
		
		
		
	
		
		
		
		
		
	
		
		

}
}
