package ExceptionHandling;

public class FirstOccurenceandFinalOccurence {

	public static void main(String[] args) {
		
		int []a= {1,4,5,4,6,5,7,5,8,5};
		int fOccurence;
		int lOccurence;
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==5) 
			{
				fOccurence=i;
				System.out.println(i);
				break;
			}
			
			
		}
		
		for(int i=a.length-1;i>0;i--)
		{
			if(a[i]==5) 
			{
				lOccurence=i;
				System.out.println(i);
				break;
			}
			
			
		}
		
		
		

	}

}
