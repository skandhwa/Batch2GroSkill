package ExceptionHandling;

public class ReversefromSecond {
	

	public static void main(String[] args) {
		
		String str="India is my country";
		String []s=str.split(" ");
		String revstr=" ";
		
		for(int i=s.length-1;i>=0;i--)
		{
			revstr=revstr+s[i]+" ";
		}
		
		System.out.println(revstr+" ");
		
		
		
		
		
		

	}

}
