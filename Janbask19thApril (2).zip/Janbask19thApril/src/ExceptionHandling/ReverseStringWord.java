package ExceptionHandling;

public class ReverseStringWord {

	public static void main(String[] args) {
		
		String str="apple banana melon";
		String revstr="";
		String []s=str.split(" ");
		
		for(int i=0;i<s.length;i++)
		{
			String s1=s[i];
			String revword="";
			for(int j=s1.length()-1;j>=0;j--)
			{
			   revword=revword+str.charAt(j);
				
				
			}
			
			revstr=revstr+revword+" ";
			
			
		}
		
		
		System.out.println("Reverse of String is "+revstr);
		
		
		
		
		

	}

}
