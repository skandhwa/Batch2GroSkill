package ExceptionHandling;

import java.util.Arrays;

public class ArrayReverseEx2 {
	
	public static int revNum(int num)
	{
		int d,rev=0;
		while(num!=0)
		{
		
		d=num%10;
		rev=rev*10+d;
		num=num/10;
		
		}
		
		return rev;
		
		
	}
	
	public static int[] reverseNumber(int []a)
	{
		int []b=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			b[i]=revNum(a[i]);
		}
		
		return b;
	}
	
	
	
	
	
	

	public static void main(String[] args) {
		
		
		int []a= {35,63,22,91,84};
		
		System.out.println(Arrays.toString(a));
		
	System.out.println(Arrays.toString(reverseNumber(a)));	
	
	int []b=reverseNumber(a);
	
	Arrays.sort(b);
	
		System.out.println(Arrays.toString(b));
		
		

	}

}
