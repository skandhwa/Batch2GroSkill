package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PrintIndividualWords {

	public static void main(String[] args) {
		
		
		String str="abcd1234*^%$#";
		char []s1=str.toCharArray();
		
		List<Character> li=new  ArrayList<Character>();
		List<Character> li2=new  ArrayList<Character>();
		List<Character> li3=new  ArrayList<Character>();
		
		for(char x:s1)
		{
			if(Character.isDigit(x))
			{
				li.add(x);
			}
			else if (Character.isAlphabetic(x))
			{
				li2.add(x);
			}
			
			
			
			
			else
			{
				li3.add(x);
				Collections.sort(li3);
			}
		}
		
		System.out.println(li);
		
		System.out.println(li2);
		System.out.println(li3);
		
		li.addAll(li2);
		li.addAll(li3);
		
		System.out.println(li);
		
		
		
		
}
}
