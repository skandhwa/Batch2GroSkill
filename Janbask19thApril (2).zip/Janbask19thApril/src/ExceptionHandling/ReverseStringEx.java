package ExceptionHandling;

public class ReverseStringEx {

	public static void main(String[] args) {
		
		String str="I am enginner";
		
		String []str1=str.split(" ");
		
		String []str2=new String[str1.length];
		String revstr="";
		
		
		for(int i=0;i<str1.length;i++)
		{
			revstr=revstr+str.charAt(i);
		}
		
		
		System.out.println(revstr);

	}

}
