package ExceptionHandling;

import java.util.Arrays;

public class ReverseEachElementofArray {
	
	public static int reverse(int num)
	{
		int rev=0;
		while(num!=0)
		{
			int digit=num%10;
			rev=rev*10+digit;
			num=num/10;
		}
		
		return rev;
		
	}
	
	public static int[] reverseArray(int []b)
	{
		int []revarray=new int[b.length];
		for(int i=0;i<revarray.length;i++)
		{
			revarray[i]=reverse(b[i]);
		}
		
		return revarray;
	}
	
	public static void main(String[] args) {
		
		int []a= {35,63,22,91,84};
		
		System.out.println(Arrays.toString(a));
		
	int []c=	reverseArray(a);
	
	
	System.out.println(Arrays.toString(c));
	
	Arrays.sort(c);
	
	System.out.println(Arrays.toString(c));
	
	
		
		
		
		
		
		

	}

}
