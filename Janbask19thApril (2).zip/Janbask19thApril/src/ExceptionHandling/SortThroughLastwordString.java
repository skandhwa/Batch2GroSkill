package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortThroughLastwordString {
	
	public static void main(String[] args) {
		
		String str="apple banana kiwi melon";
		char []ch=str.toCharArray();
		
		List<Character> li=new ArrayList<Character>();
		
		for(Character x:ch)
		{
			li.add(x);
		}
		
		
		Collections.reverse(li);
		
		
		
		
		 StringBuilder sb=new StringBuilder();
		 for(char y:li)
		 {
			 sb.append(y);
		 }
		 
		
		
		
		
		
		
		
		
		
		
		

	}

}
