package ExceptionHandling;

public class ArrayProgram5 {

	public static void main(String[] args) {
		
		String str="MyNameIsAshwin";
		StringBuilder sb=new StringBuilder();
		
		for(int i=1;i<str.length();i++)
		{
			if(Character.isUpperCase(str.charAt(i)))
			{
				sb.append('_');
			}
			
			sb.append(str.charAt(i));
		}
		System.out.println(sb.toString());
		

	}

}
