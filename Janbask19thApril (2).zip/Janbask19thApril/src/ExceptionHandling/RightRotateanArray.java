package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RightRotateanArray {

	public static void main(String[] args) {
		
		int []a= {12,34,56,78,99,49};
		
		 
		 
		List<Integer>li=new ArrayList<Integer>();
		for(int x:a)
		{
			li.add(x);
		}
		
		Collections.rotate(li, -4);
		
		for(int y:li)
		{
			System.out.print(y+" ");
		}
		
		
		 ArrayList<String> list = new ArrayList<>();
	        list.add("Apple");
	        list.add("Banana");
	        list.add("Cherry");

	        // Convert ArrayList to array
	        String[] array = list.toArray(new String[0]);
		
		

	}

}
