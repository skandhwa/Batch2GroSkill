package ExceptionHandling;

public class PrintNextEvenNumbers {

	public static void main(String[] args) {
		
		int []b;
		
		for(int i=3;i<=15;i=i+1)
		{
			System.out.println(i);
		}

	}

}
