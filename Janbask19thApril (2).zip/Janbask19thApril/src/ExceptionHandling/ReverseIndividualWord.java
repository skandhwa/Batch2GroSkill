package ExceptionHandling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseIndividualWord {

	public static void main(String[] args) {
		
		String str="Java is a programming language";
		String []s=str.split(" ");
		String revstr="";
		
		
		for(int i=0;i<s.length;i++)
		{
			
			String s2=s[i];
			String revword="";
			
			for(int j=s2.length()-1;j>=0;j--)
			{
				revword=revword+s2.charAt(j);
			}
			
			revstr=revstr+revword+" ";
			
			
		}
		
		
		System.out.println("Original String is "+str);
		System.out.println("Reverse String is  "+revstr);
		
		
		ArrayList<String> li=new ArrayList<String>();
	    String []ch=revstr.split(" ");
	    for(String x:ch)
	    {
	    	li.add(x);
	    }
	    
	    System.out.println(li);
	    
	    Collections.sort(li);
	    
	    System.out.println(li);
	    
	   
	    
	    
	    
	    
		
		
		
		
		
		
		
		
		
		
		

	}

}
