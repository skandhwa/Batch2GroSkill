package ExceptionHandling;

public class MultipleException {

	public static void main(String[] args) {
		
		
		try
		{
		
        int a[]=new int[5];
		
		
		a[0]=13;
		a[1]=23;
		a[2]=33;
		a[3]=43;
		a[4]=53;
		a[5]=63;
		a[6]=73;
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		int x=10/0;
		System.out.println(x);
		
String str=null;
		
		int y=str.length();
		System.out.println(y);
		
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		int k=10;
		int b=20;
		int c=k+b;
		System.out.println("The Sum is "+c);
		
		
		
		

	}
		
		

}
