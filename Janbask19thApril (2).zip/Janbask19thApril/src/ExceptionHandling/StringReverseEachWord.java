package ExceptionHandling;

import java.util.ArrayList;
import java.util.Collections;

public class StringReverseEachWord {

	public static void main(String[] args) {
		
		String str="Java is a programming language";
	 str=	str.toLowerCase();
		String []ch=str.split(" ");
		ArrayList<String> li=new ArrayList<String>();
		
		
		
		for(String word:ch)
		{
			li.add(word);
		}
		
		
		for(String x:li)
		{
			System.out.print(x+" ");
		}
		
		System.out.println();
		Collections.reverse(li);
		
		for(String x:li)
		{
			System.out.print(x+" ");
		}
		
		System.out.println();
		Collections.sort(li);
		
		for(String x:li)
		{
			System.out.print(x+" ");
		}
		

	}

}
