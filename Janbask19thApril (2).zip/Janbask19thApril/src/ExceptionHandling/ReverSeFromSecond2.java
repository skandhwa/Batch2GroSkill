package ExceptionHandling;

import java.util.Arrays;

public class ReverSeFromSecond2 {
	
	public static int reverse(int num)
	{
		int rev=0;
		while(num!=0)
		{
			int r=num%10;
			rev=rev*10+r;
			num=num/10;
		}
		
		return rev;
	}
	
	
	public static int[] revarray(int []a)
	{
		int []b=new int [a.length];
		for(int i=0;i<b.length;i++)
		{
			b[i]=reverse(a[i]);
		}
		
		return b;
	}
	
	
	
	

	public static void main(String[] args) {
		
		int []b= {21,78,59,65,67,32};
		System.out.println(Arrays.toString(b));
		
		System.out.println(Arrays.toString(revarray(b)));
		
		int []c=revarray(b);
		
		
		System.out.println(Arrays.toString(c));
		
		Arrays.sort(c);
		System.out.println(Arrays.toString(c));

	}

}
