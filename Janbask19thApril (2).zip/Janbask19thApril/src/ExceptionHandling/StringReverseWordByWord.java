package ExceptionHandling;

public class StringReverseWordByWord {

	public static void main(String[] args) {
		
		String str="apple banana melon";
		String revstr="";
		
		String []word=str.split("");
		
		for(int i=0;i<word.length;i++)
		{
			String s1=word[i];
			String revword="";
			for(int j=s1.length()-1;j>=0;j--)
			{
				revword=revword+str.charAt(j);
			}
			
			revstr=revstr+revword+" ";
			
		}
		
		
		System.out.println(revstr);
		
		
		
		
		

	}

}
