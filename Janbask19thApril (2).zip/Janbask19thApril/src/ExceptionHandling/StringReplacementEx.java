package ExceptionHandling;

public class StringReplacementEx {

	public static void main(String[] args) {
		
		String str="apple banana";
		StringBuilder sb=new StringBuilder(str);
		
		char []ch=str.toCharArray();
		
		for(int i=0;i<ch.length-1;i++)
		{
			if(ch[i]=='a' || ch[i]=='e' || ch[i]=='o' || ch[i]=='u')
			{
				sb.setCharAt(i, '*');
			}
		}
		
		System.out.println(sb.toString());
		

	}

}
