package JavaStrings;

public class MySecondJavaProgram {

	public static void main(String[] args) {
		
		String str1="India";
		String str2="india";
		
		if(str1==str2)
		{
			System.out.println("This is pass ");
		}
		
		System.out.println(str1.equals(str2));
		

	}

}
