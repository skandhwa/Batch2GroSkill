package JavaStrings;

public class MyFirstStringProgram {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		String str1="1234";
		
		
		System.out.println("Selenium*+1234");
		
		String []mytools= {"UFT","Selenium","RFT"};
		
		for(String x:mytools)
		{
			System.out.println(x);
		}
		
		System.out.println(1+1+"Selenium1234");
		
		System.out.println("1"+1+"Selenium1234");
		
		

	}

}
