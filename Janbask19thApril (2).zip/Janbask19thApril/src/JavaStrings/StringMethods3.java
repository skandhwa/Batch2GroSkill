package JavaStrings;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str1="Saurabh";
		String str2="saurabh";
		
		
		System.out.println(str2.compareTo(str1));
		
		
		
		

	}

}
