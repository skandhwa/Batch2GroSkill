package JavaStrings;

public class ArrayCopyExamples {

	public static void main(String[] args) {
		
		int []a= {23,45,67,88};
		int []b=a;
		 
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		

	}

}
