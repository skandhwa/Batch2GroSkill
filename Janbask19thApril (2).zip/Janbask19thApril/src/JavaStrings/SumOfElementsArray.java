package JavaStrings;

public class SumOfElementsArray {

	public static void main(String[] args) {
		
		int []a= {34,56,72,54,89,15};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println("The Sum is  "+sum);
		

	}

}
