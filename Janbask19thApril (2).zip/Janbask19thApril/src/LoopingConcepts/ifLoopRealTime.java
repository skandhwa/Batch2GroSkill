package LoopingConcepts;

public class ifLoopRealTime {

	public static void main(String[] args) {
		
		int age=38;
		int poll=1;
		
		if(age>18)
		{
			if(poll==2)
			{
				System.out.println("You can cast vote");
			}
			else
			{
				System.out.println("You cannot poll more than one vote");
			}
		}
		
		else
		{
			System.out.println("You cannot vote");
		}
		
		
		

	}

}
