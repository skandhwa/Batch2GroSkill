package LoopingConcepts;

public class SwitchCaseEx {

	public static void main(String[] args) {
		
		
		char grade='J';
		
		switch(grade)
		{
		case 'A':
			System.out.println("Excellent");
			break;
			
		case 'B':
			System.out.println("VeryGood");
			break;
		case 'C':
			System.out.println("Satisfactory");
			break;
			
		case 'D':
			System.out.println("Fail");
			break;
			
			default:
				System.out.println("Unknown Value");
				
		
		
		
		}

	}

}
