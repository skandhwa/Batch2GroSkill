package LoopingConcepts;

public class forLoopExamples {

	public static void main(String[] args) {
		
		
		for(int i=5;i>0;)//5>0//4>0//3>0//2>0//1>0//0>0
		{
			System.out.println(i);//5//4//3//2//1
			i--;//4//3//3--//2--//1--
		}
		
		

	}

}
