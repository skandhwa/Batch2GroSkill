package LoopingConcepts;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int i=5;
		
		while(i<10)//5<10//6<10//7<10//8<10//10<10
		{
			System.out.println(i);//5//6//7//8//9
			i++;//6//7//8
		}
		
		
		

	}

}
