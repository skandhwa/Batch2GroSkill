package LoopingConcepts;

public class IfLoopEx {

	public static void main(String[] args) {
		
		int x=10;
		if(x>50)//10>50
		{
			System.out.println("Test Case Pass");
		}
		
		
		System.out.println("We have completed");

	}

}
