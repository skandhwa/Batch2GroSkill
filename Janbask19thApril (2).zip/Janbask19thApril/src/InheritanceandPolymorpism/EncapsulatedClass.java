package InheritanceandPolymorpism;


class Demo6
{
	private String name="Selenium";
	private String Address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	
}

public class EncapsulatedClass {

	public static void main(String[] args) {
		
		Demo6 obj=new Demo6();
	System.out.println(obj.getName());	
		
		
		

	}

}
