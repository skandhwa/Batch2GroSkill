package InheritanceandPolymorpism;

class G3
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static int add(int x,int y,int z)
	{
		return x+y+z;
	}
}

public class PolyMorphismExample2 {

	public static void main(String[] args) {
		
	System.out.println(G3.add(20, 45));	
	System.out.println(	G3.add(12, 27,98));
		
		
		

	}

}
