package InheritanceandPolymorpism;

interface Test
{
	void message();
	void test();
	
}

class Test2 implements Test
{
	public void message()
	{
		System.out.println("Hello");
	}
	
	public void test()
	{
		System.out.println("Hello how r u");
	}
}

public class InterfaceExamples {

	public static void main(String[] args) {
		
		Test2 obj=new Test2();
		obj.message();
		obj.test();
		
	}

}
