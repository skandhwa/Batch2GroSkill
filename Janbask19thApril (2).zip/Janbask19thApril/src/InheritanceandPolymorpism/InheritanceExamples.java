package InheritanceandPolymorpism;

class C5
{
	int add(int a,int b)
	{
		return a+b;
	}
}

class D5 extends C5
{
	int sub(int a,int b)
	{
		return a-b;
	}
}

class E5 extends D5
{
	int mul(int x,int y)
	{
		return x*y;
	}
}

public class InheritanceExamples {

	public static void main(String[] args) {
		
		E5 obj=new E5();
	System.out.println(obj.add(45, 20));	;
	System.out.println(	obj.sub(90, 40));
	System.out.println(	obj.mul(23, 14));
	

	}

}
