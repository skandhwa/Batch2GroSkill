package InheritanceandPolymorpism;

class A1

{
	void display()
	{
		System.out.println("Hello");
	}
}

class B1 extends A1
{
	void message()
	{
		System.out.println("New test");
	}
}

class C1 extends B1
{
	void test()
	{
		System.out.println("Test Method");
	}
}





public class FirstExample {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.display();
		obj.message();
		obj.test();
		

	}

}
