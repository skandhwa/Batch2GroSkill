package InheritanceandPolymorpism;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class AXIS extends Bank
{
	int getROI(int x,int y)
{
	return x+y;
}
	
}



public class MethodOverridingExamples {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
	System.out.println(obj.getROI(12, 13));	
		
		SBI obj1=new SBI();
		System.out.println(	obj1.getROI(45, 10));
		
		AXIS obj2=new AXIS();
		System.out.println	(obj2.getROI(5, 9));
		
		
		
		

	}

}
