package InheritanceandPolymorpism;

abstract class Demo
{
	void display()
	{
		System.out.println("Hello");
	}
	
	abstract void test();
	
}
class Demo3 extends Demo
{
	void test()
	{
		System.out.println("Hello i am new");
	}
}

public class AbstractClassExamples {

	public static void main(String[] args) {
		
		Demo3 obj=new Demo3();
		obj.test();
		obj.display();
		

	}

}
