package InheritanceandPolymorpism;

class F5
{
	void display(int x,int y)
	{
		System.out.println("Hello");
	}
	
	void display()
	{
		System.out.println("test");
	}
}

public class UsingPolyMorphism {
	
	
	
	

	public static void main(String[] args) {
		

	}

}
